









ViewpointFurniture = {}


local TITLES = { pickup = "IGUI_Pickup", place = "IGUI_Place", rotate = "IGUI_Rotate", scrap = "IGUI_Scrap",
                 repair = "IGUI_Repair" }



local function lists(player, sq)
    local playerNum = player:getPlayerNum()
    return setmetatable({ character = player, player = playerNum, currentSquare = sq,
                          canSeeCurrentSquare = sq ~= nil and sq:isCouldSee(playerNum), objectIndex = 1 },
                        { __index = ISMoveableCursor })
end



local function entry(tool, mode, object)
    if mode == "rotate" then
        local turned = tool:getRotateableObject()
        return turned and turned.object == object and turned or nil
    end
    local list = mode == "pickup" and tool:getObjectList() or mode == "scrap" and tool:getScrapObjectList()
        or mode == "repair" and tool:getRepairObjectList() or {}
    for _, e in ipairs(list) do
        if e.object == object and not e.isWall then return e end
    end
    return nil
end




local function can(player, mode, sq, e)
    local yes = true
    if mode == "pickup" then
        yes = e.moveProps:canPickUpMoveable(player, sq, e.object)
    elseif mode == "scrap" then
        yes = e.moveProps:canScrapObject(player).canScrap
    elseif mode == "repair" then
        yes = e.moveProps:canRepairObject(player).canRepair
    end
    return yes and true or false
end




local function tooltip(player, mode, sq, e)
    local info = e.moveProps:getInfoPanelDescription(sq, e.object, player, mode)
    local font = ISToolTip.GetFont()
    local column = 0
    for _, line in ipairs(info) do
        if #line == 2 then column = math.max(column, getTextManager():MeasureStringX(font, line[1].txt) + 10) end
    end
    local text = ""
    for _, line in ipairs(info) do
        local a, b = line[1], line[2]
        text = string.format("%s <RGB:%.2f,%.2f,%.2f> %s", text, a.r / 255, a.g / 255, a.b / 255, a.txt)
        if b then
            text = string.format("%s <SETX:%d> <INDENT:%d> <RGB:%.2f,%.2f,%.2f> %s", text, column, column,
                                 b.r / 255, b.g / 255, b.b / 255, b.txt)
        end
        text = text .. " <LINE> <INDENT:0> "
    end
    local tip = ISToolTip:new()
    tip:initialise()
    tip:setVisible(false)
    tip.description = text
    tip:setTexture(e.moveProps.spriteName)
    return tip
end




local function act(player, object, mode)
    local cursor = ISMoveableCursor:new(player)
    if mode == "rotate" then
        getCell():setDrag(cursor, cursor.player)
        cursor:setMoveableMode(mode)
        return
    end
    local sq = object:getSquare()
    if not sq then return end
    cursor:setMoveableMode(mode)
    cursor:isValid(sq)
    for i, e in ipairs(cursor.objectListCache or {}) do
        if e.object == object and not e.isWall then cursor.objectIndex = i end
    end
    if cursor:isValid(sq) and cursor.canCreate then cursor:tryBuild(sq:getX(), sq:getY(), sq:getZ()) end
    cursor:exitCursor()
end




function ViewpointFurniture.harvest(player, object, mode)
    local sq = object:getSquare()
    local list = {}
    local e = sq and ISMoveableCursor and entry(lists(player, sq), mode, object)
    if e then
        local name = ISWorldObjectContextMenu.getMoveableDisplayName(object) or getText(TITLES[mode])
        local enabled = can(player, mode, sq, e)
        table.insert(list, { name = name, fn = act, args = { player, object, mode }, n = 3, enabled = enabled,
                             tip = tooltip(player, mode, sq, e) })
    end
    ViewpointInteract.target = { square = sq, object = object }
    return ViewpointInteract.finish(list, getText(TITLES[mode]))
end



function ViewpointFurniture.place(player)
    local list = {}
    if ISMoveableCursor and ISMoveableContextMenu then
        for _, e in ipairs(lists(player, nil):getInventoryObjectList()) do
            table.insert(list, { name = e.object:getDisplayName(), fn = ISMoveableContextMenu.openMovableCursor,
                                 args = { e.object, player }, n = 2, enabled = true })
        end
    end
    ViewpointInteract.target = nil
    return ViewpointInteract.finish(list, getText(TITLES.place))
end








local POPUP = { "pickup", "place", "rotate", "scrap", "repair" }
local ICONS = { pickup = "movableIconPickup", place = "movableIconPlace", rotate = "movableIconRotate",
                scrap = "movableIconScrap", repair = "moveableIconRepair" }

local TEXT_X = 10

local wrapped = {}

local function viewOn()
    return Viewpoint and Viewpoint.Loot and Viewpoint.Loot.viewOn()
end


local function toolOut(playerNum)
    local drag = getCell():getDrag(playerNum)
    return drag and drag.isMoveableCursor and drag or nil
end



function ViewpointFurniture.putAway(player)
    local tool = toolOut(player:getPlayerNum())
    if tool then tool:exitCursor() end
end


local function ours(playerNum)
    if not viewOn() or toolOut(playerNum) then return nil end
    return Viewpoint.Loot.furnitureMode()
end


local function popupClick(onMouseUp)
    return function(self, x, y)
        if not viewOn() then return onMouseUp(self, x, y) end
        local tool = toolOut(self.owner.chr:getPlayerNum())
        if tool then tool:exitCursor() end
        Viewpoint.Loot.chooseFurnitureMode(POPUP[math.floor(x / (self.width / (#POPUP + 1)))])
        self:setVisible(false)
        return true
    end
end



local function popupShows(render)
    return function(self)
        render(self)
        local mode = ours(self.owner.chr:getPlayerNum())
        if not mode then return end
        local w = self.width / (#POPUP + 1)
        for i, m in ipairs(POPUP) do
            if m == mode then self:drawRectBorder(i * w, 0, w, self.height, 0.5, 1, 1, 1) end
        end
        if math.floor(self:getMouseX() / w) == 0 then
            self:drawRect(0, 0, w, self.height, 0.15, 1, 1, 1)
            self:drawText(getText("IGUI_Exit"), TEXT_X, self.height + 2, 1.0, 0.85, 0.05, 1.0, UIFont.Small)
        end
    end
end



local function buttonShows(prerender)
    return function(self)
        prerender(self)
        local mode = ours(self.chr:getPlayerNum())
        local button = self.movableBtn
        if mode and button:isVisible() and not button:isMouseOver() and not self.movablePopup:isMouseOver() then
            button:setImage(self[ICONS[mode]])
            self.movableTooltip:setVisible(true)
        end
    end
end



local function noteShows(render)
    return function(self)
        local mode = ours(0)
        if not mode then return render(self) end
        local key = Viewpoint.Loot.furnitureKey()
        self.subText = getText("IGUI_ToggleMode", key)
        self:setWidth(self.marginOffset + getTextManager():MeasureStringX(UIFont.Small, self.subText) + 20)
        ISPanel.render(self)
        local y = (self:getHeight() - self.fontheight * 2) / 2
        self:drawText(getText(TITLES[mode]), self.marginOffset + 5, y, 1.0, 0.85, 0.05, 1.0, UIFont.Small)
        if getJoypadData(0) == nil then
            self:drawText(self.subText, self.marginOffset + 5, y + self.fontheight, 0.75, 0.75, 0.75, 1.0, UIFont.Small)
        end
    end
end


local function wrapMethod(id, class, name, make)
    local f = class and class[name]
    if not f or f == wrapped[id] then return end
    wrapped[id] = make(f)
    class[name] = wrapped[id]
end

local function start()
    wrapMethod("popupClick", ISMoveablesIconPopup, "onMouseUp", popupClick)
    wrapMethod("popupShows", ISMoveablesIconPopup, "render", popupShows)
    wrapMethod("buttonShows", ISEquippedItem, "prerender", buttonShows)
    wrapMethod("noteShows", ISMoveablesIconToolTip, "render", noteShows)
end

Events.OnGameStart.Add(start)
