









require "RadioCom/ISRadioWindow"
require "Fluids/ISFluidTransferUI"




ViewpointInvDevice = ViewpointInvDevice or { wrapped = {} }
local V = ViewpointInvDevice

local PLAYER = 0

V.TAB = "device"


local equipping = false




local function opened(player, window)
    if not window or not player or player:getPlayerNum() ~= PLAYER then return end
    if V.window and V.window ~= window then V.close() end
    V.window = window
    if equipping or ViewpointInvScreen.isUp() or JoypadState.players[PLAYER + 1] then return end
    local loot = Viewpoint and Viewpoint.Loot
    if loot then loot.openScreen(V.TAB) end
end

local function activateWrapped(activate)
    return function(player, device, ...)
        local window = activate(player, device, ...)
        opened(player, window)

        return window
    end
end

local function openWrapped(open)
    return function(player, container, source)
        open(player, container, source)
        local entry = player and ISFluidTransferUI.players[player:getPlayerNum()]
        opened(player, entry and entry.instance)
    end
end

local function equipWrapped(equip)
    return function(player, item)
        equipping = true
        equip(player, item)
        equipping = false
    end
end

local function wrap(id, class, name, make)
    local f = class[name]
    if f == V.wrapped[id] then return false end
    V.wrapped[id] = make(f)
    class[name] = V.wrapped[id]

    return true
end


local function install()
    wrap("activate", ISRadioWindow, "activate", activateWrapped)
    wrap("open", ISFluidTransferUI, "OpenPanel", openWrapped)
    local equip = ISRadioWindow.onEquip
    if wrap("equip", ISRadioWindow, "onEquip", equipWrapped) then
        Events.OnEquipPrimary.Remove(equip)
        Events.OnEquipSecondary.Remove(equip)
        Events.OnEquipPrimary.Add(V.wrapped.equip)
        Events.OnEquipSecondary.Add(V.wrapped.equip)
    end
end



local function carry(on)
    if on and not V.layer then
        V.layer = ISUIElement:new(0, 0, 1, 1)
        V.layer:initialise()
        V.layer:instantiate()
        V.layer.render = function(ui)
            local screen = ViewpointInvScreen.instance
            if screen and screen.drag then screen:drawDrag(ui) end
        end
    end
    if on then
        if not V.carrying then V.layer:addToUIManager() end
        V.layer:bringToTop()
    elseif V.carrying then
        V.layer:removeFromUIManager()
    end
    V.carrying = on
end



local function letGo(w)
    local home = V.home
    V.home = nil
    carry(false)
    if not home then return end
    w:setX(home.x)
    w:setY(home.y)
    w.moveWithMouse = home.moves
    if home.pin == false then ISCollapsableWindow.collapse(w) end
    local entry = ISFluidTransferUI.players[PLAYER]
    if w.Type == "ISFluidTransferUI" and entry then entry.x, entry.y = home.x, home.y end
end



local function hold(c, w)
    if w.pin == false then ISCollapsableWindow.pin(w) end
    if w.isCollapsed then
        w.isCollapsed = false
        w:clearMaxDrawHeight()
    end
    w.moveWithMouse, w.moving = false, false
    w:setX(c.x + math.floor((c.w - w:getWidth()) / 2))
    w:setY(c.y)
end




function V.frame(screen)
    local w = V.window
    if w and not w:getIsVisible() then
        V.window = nil
        letGo(w)
        w = nil
    end
    if w and not V.home and not screen.padMode then
        V.home = { x = w:getX(), y = w:getY(), pin = w.pin, moves = w.moveWithMouse }
        w:bringToTop()
        screen:selectTab(V.TAB)
    end
    if not V.home then
        if screen.tabs.active == V.TAB then screen:selectTab("character") end
        return
    end
    hold(screen.centre, w)
    carry(screen.drag ~= nil)
end


function V.close()
    local w = V.window
    if not w then return end
    V.window = nil
    letGo(w)
    if w:getIsVisible() then w:close() end
end


function V.raise()
    if V.window then V.window:bringToTop() end
end


function V.over(x, y)
    local w = V.home and V.window
    if not w then return false end
    local wx, wy = w:getX(), w:getY()

    return x >= wx and y >= wy and x < wx + w:getWidth() and y < wy + w:getHeight()
end




function V.drag(screen, items)
    if items and V.home then
        ISMouseDrag.dragging, ISMouseDrag.draggingFocus = items, screen
    elseif ISMouseDrag.draggingFocus == screen then
        ISMouseDrag.dragging, ISMouseDrag.draggingFocus = nil, nil
    end
end

install()
Events.OnGameBoot.Add(install)
