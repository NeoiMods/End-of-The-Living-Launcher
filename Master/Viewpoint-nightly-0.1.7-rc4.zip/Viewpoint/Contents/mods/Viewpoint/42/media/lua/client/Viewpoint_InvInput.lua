




















require "Viewpoint_InvScreen"
require "Viewpoint_InvActions"

local Screen = ViewpointInvScreen
local A = ViewpointInvActions
local D = ViewpointInvData

local PLAYER = 0



local DRAG_PX, DRAG_FONT, DOUBLE_MS = 4, 0.25, 350

local function inside(r, mx, my)
    return r and mx >= r.x and mx < r.x + r.w and my >= r.y and my < r.y + r.h
end


function Screen:hit(mx, my)
    if ViewpointInvDevice.over(mx, my) then return { kind = "device" } end
    if inside(self.closeRect, mx, my) then return { kind = "close" } end
    local h = self.details and self.details:hit(mx, my)
    if h then return h end
    h = self.tabs:hit(mx, my) or self.bar:hit(mx, my) or self.gear:hit(mx, my) or self.nearby:hit(mx, my)
        or self.inventory:hit(mx, my)
    if h then return h end
    if self.tabs:isCharacter() then
        h = self.hands:hit(mx, my)
        if h then return h end
        if inside(self.avatarRect, mx, my) then return { kind = "avatar" } end
    end
    h = ViewpointInvBar.hotbarAt(self, mx, my)
    if h then return h end
    if inside(self.centre, mx, my) then return { kind = "centre" } end
    return { kind = "backdrop" }
end


local function copySelection(selection)
    local copy = {}
    for container, chosen in pairs(selection) do
        local keys = {}
        for key in pairs(chosen) do keys[key] = true end
        copy[container] = keys
    end
    return copy
end



local function selectedStacks(self, s)
    for _, other in ipairs(self.nearby.sections) do
        if other == s then return D.chosen(self.nearby, self.selected) end
    end
    return D.chosen(self.inventory, self.selected)
end



function Screen:itemsOf(h)
    if h.kind == "tile" then
        local chosen = self.selected[h.section.container]
        local group = h.stack.group
        if chosen and (chosen[h.stack.key] or group and chosen[group.key]) then
            return D.items(selectedStacks(self, h.section))
        end
        return D.items({ h.stack })
    end
    if (h.kind == "slot" or h.kind == "hand" or h.kind == "hotbar") and h.item then return { h.item } end
    return nil
end

local function weightOf(items)
    local weight = 0
    for _, item in ipairs(items) do weight = weight + item:getUnequippedWeight() end
    return weight
end

local function anyWearable(items)
    for _, item in ipairs(items) do
        if A.wearable(item) then return true end
    end
    return false
end



local function fits(d, s)
    if s.locked or s.equipped then return false end
    local _, n = A.fitting(d.items, s.container)
    return n > 0
end



local function bagOf(h, d)
    if h.kind ~= "tile" or not h.stack.item:IsInventoryContainer() then return nil end
    for _, item in ipairs(d.items) do
        if item == h.stack.item then return nil end
    end
    return h.stack.item:getInventory()
end


function Screen:judge(h)
    local d = self.drag
    h.into = bagOf(h, d)
    if h.into and d.bags[h.into] == nil then
        local _, n = A.fitting(d.items, h.into)
        d.bags[h.into] = n > 0
    end
    if h.section and d.fits[h.section] == nil then d.fits[h.section] = fits(d, h.section) end
    if h.kind == "hotbar" and d.attaches[h.index] == nil then
        d.attaches[h.index] = A.attachable(d.items, h.index) ~= nil
    end
end



function Screen:onFocus(x, y)
    if not ViewpointInvDevice.home then ISPanel.onFocus(self, x, y) end
end




function Screen:boxFrom(h, x, y, ctrl)
    if h.kind == "column" or h.kind == "section" then return inside(h.grid.body, x, y) and h.grid or nil end
    if not ctrl or h.kind ~= "tile" then return nil end
    for _, grid in ipairs({ self.nearby, self.inventory }) do
        if inside(grid.body, x, y) then return grid end
    end
    return nil
end



function Screen:onMouseDown(x, y)
    if not self.up then return true end
    for _, box in ipairs(self.searches) do
        if box:isFocused() then box:unfocus() end
    end
    for _, box in ipairs(self.searches) do
        if inside(box.target.searchRect, x, y) then
            box:focus()
            return true
        end
    end
    self:setCapture(true)
    if self.split then
        if self.split:press(x, y) then self.split = nil end
        return true
    end
    if self.filterMenu then
        if self.filterMenu:press(x, y) then self.filterMenu = nil end
        return true
    end
    local h = self:hit(x, y)
    self.press = { x = x, y = y, target = h, items = self:itemsOf(h), shift = isShiftKeyDown() }
    self.press.grid = self:boxFrom(h, x, y, isCtrlKeyDown())
    if self.press.grid then self.press.base = isShiftKeyDown() and copySelection(self.selected) or {} end
    return true
end



function Screen:selectBox(p, mx, my)
    local grid = p.grid
    local body = grid.body
    local x0, y0 = math.max(body.x, math.min(p.x, mx)), math.max(body.y, math.min(p.y, my))
    local x1, y1 = math.min(body.x + body.w, math.max(p.x, mx)), math.min(body.y + body.h, math.max(p.y, my))
    p.box = { x = x0, y = y0, w = math.max(0, x1 - x0), h = math.max(0, y1 - y0) }
    local selected = copySelection(p.base)
    for _, t in ipairs(grid:tilesIn(p.box)) do
        local chosen = selected[t.section.container] or {}
        selected[t.section.container] = chosen
        chosen[t.stack.key] = true
    end
    self.selected = selected
end



function Screen:onMouseMove(dx, dy)
    local mx, my = self:getMouseX(), self:getMouseY()
    if self.split then
        if self.split.sliding then self.split:slide(mx) end
        return
    end
    local p = self.press
    if not p or self.drag then return end
    local slop = math.max(DRAG_PX, math.floor(self.m.font * DRAG_FONT))
    local far = math.abs(mx - p.x) > slop or math.abs(my - p.y) > slop
    if p.base then
        if far or p.box then self:selectBox(p, mx, my) end
        return
    end
    if not p.items then return end
    if far then
        local split = p.shift and p.target.kind == "tile" and p.target.stack.count > 1
        local items = split and D.items({ p.target.stack }) or p.items
        self.drag = { items = items, weight = weightOf(items), fits = {}, bags = {}, attaches = {},
            wearable = anyWearable(items), split = split }
        ViewpointInvDevice.drag(self, items)
    end
end

Screen.onMouseMoveOutside = Screen.onMouseMove

function Screen:onMouseUp(x, y)
    self:setCapture(false)
    if self.split then
        self.split.sliding = false
        return true
    end
    local p, d = self.press, self.drag
    self.press, self.drag = nil, nil
    ViewpointInvDevice.drag(self, nil)
    if d then
        self:drop(d, self:hit(x, y), x, y)
    elseif p and not p.box then
        self:click(p.target)
    end
    return true
end

Screen.onMouseUpOutside = Screen.onMouseUp




function Screen:update()
    if (self.press or self.drag) and not isMouseButtonDown(0) then
        self.press, self.drag = nil, nil
        self:setCapture(false)
        ViewpointInvDevice.drag(self, nil)
    end
    local chosen = self.wornChosen
    if chosen then
        self.wornChosen = nil
        self:itemMenu({ chosen.item }, chosen.x, chosen.y)
        if chosen.pad then self:menuToPad() end
    end
end



function Screen:askAmount(d, h, x, y)
    local items, most, move = d.items, #d.items, A.drop
    local dest
    if h.section then
        if h.section.locked or h.section.equipped and not bagOf(h, d) then return true end
        dest = bagOf(h, d) or h.section.container
        if not h.section.mine then self.across = h.section.container end
    elseif h.kind == "column" then
        local s = h.grid.mine and { container = self.player:getInventory() } or h.grid:floor()
        if not s then return true end
        dest = s.container
    elseif not self:floorSpace(h) then
        return false
    end
    if dest then
        items, most = A.fitting(d.items, dest)
        move = function(list) A.move(list, dest) end
    end
    if most == 1 then move({ items[1] }) end
    if most > 1 then self.split = ViewpointInvSplit.new(items, most, move, x, y, self.m, self.width, self.height) end
    return true
end


function Screen:drop(d, h, x, y)
    local player = self.player
    if d.split and self:askAmount(d, h, x, y) then return end
    local bag = bagOf(h, d)
    if bag then
        A.move(d.items, bag)
        if not h.section.mine then self.across = h.section.container end
    elseif h.section then
        if d.fits[h.section] == nil then d.fits[h.section] = fits(d, h.section) end
        if d.fits[h.section] then A.move(d.items, h.section.container) end
        if not h.section.mine then self.across = h.section.container end
    elseif h.kind == "column" then
        local s = h.grid.mine and { container = player:getInventory() } or h.grid:floor()
        if s then A.move(d.items, s.container) end
    elseif h.kind == "slot" or h.kind == "slotDot" or h.kind == "slotStep" or h.kind == "avatar"
        or h.kind == "equipment" then
        for _, item in ipairs(d.items) do
            if A.wearable(item) and not player:isEquippedClothing(item) then return A.wear(item) end
        end
    elseif h.kind == "hand" then
        A.hold(d.items[1], h.primary)
    elseif h.kind == "hotbar" then
        A.attach(d.items, h.index)
    elseif h.kind == "part" then
        self.tabs:apply(h.part, d.items)
    elseif self:floorSpace(h) then
        A.drop(d.items)
    end
end


function Screen:floorSpace(h)
    return h.kind == "backdrop" or h.kind == "centre" and self.tabs:isCharacter()
end


local function identity(h)
    if h.kind == "tile" then return h.stack.item end
    if h.kind == "slot" then return h.slot end
    if h.kind == "hand" then return h.primary and "primary" or "secondary" end
    if h.kind == "hotbar" then return "hotbar" .. h.index end
    return nil
end

local function choose(self, s, stack, add)
    if not add then self.selected = {} end
    local chosen = self.selected[s.container] or {}
    self.selected[s.container] = chosen
    if add and chosen[stack.key] then chosen[stack.key] = nil else chosen[stack.key] = true end
end




function Screen:chooseInto(container)
    local page = getPlayerInventory(PLAYER)
    for _, button in ipairs(page and page.backpacks or {}) do
        if button.inventory == container then
            page:selectContainer(button)
            self.into = container
            return
        end
    end
end



function Screen:send(h)
    local items = self:itemsOf(h)
    if not h.section.mine then
        self.across = h.section.container
        A.take(items, self.into)
    elseif self.across then
        A.move(items, self.across)
    end
end

function Screen:clickTile(h, double)
    local s, stack = h.section, h.stack
    if not s.mine then self.across = s.container end
    if isCtrlKeyDown() then
        self:send(h)
    elseif isAltKeyDown() then
        A.equip(stack.item)
    elseif isShiftKeyDown() then
        choose(self, s, stack, true)
    else
        choose(self, s, stack, false)
        if double and s.mine then A.use(stack.item) end
        if double and not s.mine then A.take(self:itemsOf(h), self.into) end
    end
end

function Screen:click(h)
    local now, id = getTimestampMs(), identity(h)
    local last = self.lastClick
    local double = id ~= nil and last ~= nil and last.id == id and now - last.at < DOUBLE_MS
    self.lastClick = (not double) and { id = id, at = now } or nil
    local kind = h.kind
    if kind == "tile" then
        self:clickTile(h, double)
    elseif kind == "header" and h.section.mine then
        if not h.section.equipped then self:chooseInto(h.section.container) end
    elseif kind == "header" then
        self.across = h.section.container
    elseif kind == "fold" then
        h.section.folded = not h.section.folded
    elseif kind == "into" then
        h.grid.equipped = false
        self:chooseInto(h.section.container)
    elseif kind == "takeAll" then
        A.takeAll(h.section.container, h.stacks and D.items(h.stacks), self.into)
    elseif kind == "stackArrow" then
        self:openStack(h.section, h.stack)
    elseif kind == "slotDot" then
        self.gear:show(h.slot, h.index)
    elseif kind == "slotStep" then
        self.gear:step(h.slot, h.dir)
    elseif kind == "order" then
        h.grid:nextOrder()
    elseif kind == "filter" then
        self.filterMenu = ViewpointInvFilter.menu(h.grid.filter, h.grid.filterRect, self.m, self.width, self.height)
    elseif kind == "tab" then
        self:selectTab(h.id)
    elseif kind == "detailsClose" then
        self:closeDetails()
    elseif kind == "close" then
        ViewpointInventory.close()
    elseif (kind == "slot" or kind == "hand") and h.item and (double or isAltKeyDown()) then
        A.unequip(h.item)
    elseif kind == "hotbar" then
        local hotbar = getPlayerHotbar(PLAYER)
        if hotbar and hotbar:isAllowedToActivateSlot() then hotbar:activateSlot(h.index) end
    elseif kind == "backdrop" or kind == "column" or kind == "section" or kind == "clearSelected" then
        self.selected = {}
    elseif kind == "sendSelected" then
        local items = D.items(D.chosen(h.grid, self.selected))
        if h.grid.mine then A.drop(items) else A.take(items, self.into) end
        self.selected = {}
    elseif h.view then
        h.view:click(h)
    end
end

function Screen:onRightMouseDown(x, y)
    return true
end


function Screen.markJunk(items, junk, player)
    local v = Viewpoint and Viewpoint.Inventory
    if not v then return end
    for _, item in ipairs(items) do v.setJunk(item, player, junk) end
end



function Screen:junkOption(menu, items)
    local v = Viewpoint and Viewpoint.Inventory
    if not v then return end
    local kinds, all = {}, true
    for _, item in ipairs(items) do
        if item:getScriptItem() then
            table.insert(kinds, item)
            all = all and v.isJunk(item, self.player)
        end
    end
    if #kinds == 0 then return end
    menu:addOption(all and "Remove from junk" or "Add to junk", kinds, Screen.markJunk, not all, self.player)
end



function Screen:openStack(s, stack)
    local group = stack.group or stack
    s.open[group.key] = not stack.group or nil
    s.count = -1
end


function Screen:itemMenu(items, x, y)
    local menu = A.menu(items, self:getAbsoluteX() + x, self:getAbsoluteY() + y)
    if menu then
        self:junkOption(menu, items)
        menu:addOptionOnTop(getText("UI_Details"), self, Screen.inspect, items[1])
    end
    return menu
end



function Screen:wornMenu(h, x, y, pad)
    local menu = ISContextMenu.get(PLAYER, self:getAbsoluteX() + x, self:getAbsoluteY() + y)
    for i = #h.items, 1, -1 do
        menu:addOption(h.items[i]:getDisplayName(), self, Screen.chooseWorn, h.items[i], x, y, pad)
    end
end



function Screen:chooseWorn(item, x, y, pad)
    self.wornChosen = { item = item, x = x, y = y, pad = pad }
end

function Screen:onRightMouseUp(x, y)
    if not self.up or self.drag then return true end
    if self.split or self.filterMenu then
        self.split, self.filterMenu = nil, nil
        return true
    end
    local h = self:hit(x, y)
    self:tooltip(nil)
    local ax, ay = self:getAbsoluteX() + x, self:getAbsoluteY() + y
    if h.kind == "tile" or ((h.kind == "slot" or h.kind == "hand") and h.item) then
        self:itemMenu(self:itemsOf(h), x, y)
    elseif h.kind == "into" then


        local item = h.section.container:getContainingItem()
        if item then self:itemMenu({ item }, x, y) end
    elseif h.kind == "order" then
        h.grid:reverseOrder()
    elseif h.kind == "hotbar" then
        local hotbar = getPlayerHotbar(PLAYER)
        if hotbar then hotbar:doMenu(h.index) end
    elseif h.kind == "part" then
        self.tabs:menu(h.part, ax, ay)
    end
    return true
end

function Screen:onMouseWheel(del)
    local mx, my = self:getMouseX(), self:getMouseY()
    if self.split then
        self.split:wheel(del)
    elseif self.tabs:wheel(mx, my, del) or self.gear:wheel(mx, my, del) then
        return true
    elseif self.nearby:contains(mx, my) then
        self.nearby:wheel(del)
    elseif self.inventory:contains(mx, my) then
        self.inventory:wheel(del)
    end
    return true
end

local function isEscape(key)
    return key == Keyboard.KEY_ESCAPE or getCore():isKey(KeybindId.MAIN_MENU, key)
end

local function isEnter(key)
    return key == Keyboard.KEY_RETURN or key == Keyboard.KEY_NUMPADENTER
end


function Screen:isKeyConsumed(key)
    return isEscape(key) or (self.split ~= nil and isEnter(key))
end



function Screen:onKeyRelease(key)
    if not self.up then return end
    if self.split then
        if isEnter(key) then self.split:confirm() end
        if isEnter(key) or isEscape(key) then self.split = nil end
    elseif isEscape(key) and self.filterMenu then
        self.filterMenu = nil
    elseif isEscape(key) and self.details then
        self:closeDetails()
    elseif isEscape(key) then
        ViewpointInventory.close()
    end
end
