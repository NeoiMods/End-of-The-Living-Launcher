











require "ISUI/ISPanel"
require "ISUI/ISTextEntryBox"
require "ISUI/ISToolTip"
require "ISUI/ISToolTipInv"
require "Viewpoint_InvStyle"
require "Viewpoint_InvData"
require "Viewpoint_InvGrid"
require "Viewpoint_InvGear"
require "Viewpoint_InvHands"
require "Viewpoint_InvTabs"
require "Viewpoint_InvBar"
require "Viewpoint_InvSplit"
require "Viewpoint_InvFilter"
require "Viewpoint_InvDetails"
require "Viewpoint_InvDevice"

ViewpointInvScreen = ISPanel:derive("ViewpointInvScreen")
local Screen = ViewpointInvScreen
local S = ViewpointInvStyle
local D = ViewpointInvData

local PLAYER = 0

local RESTACK_MS = 1000

local cross = getTexture("media/ui/inventoryPanes/Button_Close.png")
local CROSS = 20

local BOX_INSET = 2

function Screen:new()
    local o = ISPanel.new(self, 0, 0, getCore():getScreenWidth(), getCore():getScreenHeight())
    o:noBackground()
    o.moveWithMouse = false

    o.disableJoypadNavigation = true
    o.nearby = ViewpointInvGrid.new("Vicinity", false, true)
    o.inventory = ViewpointInvGrid.new(getText("IGUI_InventoryTooltip"), true)
    o.gear = ViewpointInvGear.new()
    o.hands = ViewpointInvHands.new()
    o.tabs = ViewpointInvTabs.new()
    o.bar = ViewpointInvBar.new()
    o.selected = {}
    o.config = {}
    o.refreshed = 0
    return o
end




local function drawField(box)
    local r = box.target.searchRect
    if not r then return end
    local x, y = r.x - box:getX(), r.y - box:getY()
    box.fade:setFadeIn(box:isMouseOver() or box:isFocused())
    box.fade:update()
    local fill, edge = box.backgroundColor, box.borderColor
    local lit = 0.2 * box.fade:fraction()
    box:drawRectStatic(x, y, r.w, r.h, fill.a, fill.r, fill.g, fill.b)
    box:drawRectBorderStatic(x, y, r.w, r.h, edge.a, math.min(edge.r + lit, 1), math.min(edge.g + lit, 1),
        math.min(edge.b + lit, 1))
end



local function searchBox(screen, grid)
    local box = ISTextEntryBox:new("", 0, 0, 100, 20)
    box:initialise()
    box:instantiate()
    box:setClearButton(true)
    box:setPlaceholderText(getText("IGUI_FilterSearch"))
    box.target = grid
    box.prerender = drawField
    box.onTextChangeFunction = function(g, b) g.query = string.lower(b:getInternalText()) end
    box.onCommandEntered = function(b) b:unfocus() end
    box.onOtherKey = function(b, key) b:unfocus() end
    screen:addChild(box)
    return box
end

function Screen:createChildren()
    self.avatar = ViewpointInvAvatar:new(0, 0, 64, 128)
    self.avatar:initialise()
    self:addChild(self.avatar)
    self.searches = { searchBox(self, self.nearby), searchBox(self, self.inventory) }
end


function Screen:clearSearches()
    for _, box in ipairs(self.searches) do
        if box:isFocused() then box:unfocus() end
        if not self.config.keepSearches then
            box:setText("")
            box.target.query = ""
        end
    end
end


function Screen:paintSearches()
    for _, box in ipairs(self.searches) do
        box.backgroundColor = { r = S.field[1], g = S.field[2], b = S.field[3], a = S.field[4] }
        box.borderColor = { r = S.panelEdge[1], g = S.panelEdge[2], b = S.panelEdge[3], a = S.panelEdge[4] }
    end
end





function Screen:configure()
    local v = Viewpoint and Viewpoint.Inventory
    if not v then return end
    local c = self.config
    c.lastTab, c.keepSearches, c.chosenAlone = v.opensOnLastTab(), v.keepSearches(), v.chosenAlone()
    c.controls = v.controls()
    local junk = v.junkChanges()
    if junk ~= c.junk then c.junk, self.dirty = junk, true end
    local look = v.look()
    if look ~= c.look then
        c.look, self.arranged = look, false
        S.useLook(look)
        self:paintSearches()
    end
    S.panel[4], S.backdrop[4] = v.panelOpacity(), v.backdrop()
    S.useAccent(v.accent())
    S.tints = v.tints()
    S.useTypes(v.typeColours(), v.typeStrength(), v.typeColour, D.JUNK)
    local fits = v.columnsFit()
    self.nearby.grows, self.inventory.grows = fits, fits
    local scale = v.tileScale()
    if scale ~= c.tileScale then c.tileScale, self.arranged = scale, false end
    local swap = v.swapSides()
    if swap ~= c.swap then c.swap, self.arranged = swap, false end
    local order = v.order()
    if order ~= c.order then
        c.order = order
        local chosen = D.ORDERS[order + 1] or D.ORDERS[1]
        self.nearby.order, self.inventory.order = chosen, chosen
    end
    self.nearby:listFrom(v)
    self.inventory:listFrom(v)
    local avatar = v.avatar()
    if avatar ~= c.avatar then
        c.avatar = avatar
        self:showAvatar()
    end
end



function Screen:showAvatar()
    self.avatar:setVisible(self.tabs:isCharacter() and not self.details and self.config.avatar ~= false)
end


function Screen:selectTab(id)
    if id ~= ViewpointInvDevice.TAB then ViewpointInvDevice.close() end
    self.tabs:select(id)
    self:showAvatar()
end

function Screen:inspect(item)
    if self.details then self.details:close() end
    self.details = ViewpointInvDetails.new(item, self, self.player)
    self:selectTab("character")
end

function Screen:closeDetails()
    if not self.details then return end
    self.details:close()
    self.details = nil
    self:showAvatar()
end









function Screen:arrange()
    local m = S.metrics(self.config.tileScale)
    self.m = m
    local margin = m.pad * 3
    local barH = m.unit + m.pad * 2
    local bodyH = self.height - margin * 2 - barH - m.pad
    local cell = m.unit + m.gap
    local cells = math.max(1, math.min(12, math.floor((self.width * 0.31 - m.pad * 2 + m.gap) / cell)))
    local sideW = cells * cell - m.gap + m.pad * 2
    local rightX = self.width - margin - sideW
    local cx = margin + sideW + m.pad * 2
    local cw = rightX - m.pad * 2 - cx
    local footH = self.height - margin * 2
    local nearX, mineX, nearH, mineH = margin, rightX, bodyH, footH
    if self.config.swap then nearX, mineX, nearH, mineH = rightX, margin, footH, bodyH end
    self.nearby:layout(nearX, margin, sideW, nearH, m)
    local equipH = self.gear:layout(mineX, margin, sideW, m)
    self.inventory:layout(mineX, margin + equipH + m.pad, sideW, mineH - equipH - m.pad, m)
    local top = margin + m.title + m.pad
    self.centre = { x = cx, y = top, w = cw, h = margin + bodyH - top }
    self.tabs:layout(cx, margin, cw, self.centre, m)
    local handsH = ViewpointInvHands.height(m)
    self.hands:layout(cx, margin + bodyH - handsH, cw, m)
    self.avatarRect = { x = cx, y = top, w = cw, h = self.centre.h - handsH - m.pad }
    local barY = self.height - margin - barH
    self.bar:layout(margin, barY, self.width - margin * 2, barH, m, sideW)
    self.detailsRect = self.centre
    local a = self.avatarRect
    self.avatar:setX(a.x)
    self.avatar:setY(a.y)
    self.avatar:setWidth(a.w)
    self.avatar:setHeight(a.h)
    local inX = m.pad - BOX_INSET
    for _, box in ipairs(self.searches) do
        local r = box.target.searchRect
        box:setX(r.x + inX)
        box:setY(r.y + math.floor((r.h - m.font) / 2) - BOX_INSET)
        box:setWidth(r.w - inX * 2)
        box:setHeight(m.font + BOX_INSET * 2)
    end
    self.arranged = true
end


local function listed(sections, container)
    for _, s in ipairs(sections) do
        if s.container == container then return true end
    end
    return false
end





function Screen:refresh(player)
    if player:isInvPageDirty() then
        player:setInvPageDirty(false)
        ISInventoryPage.renderDirty = true
    end
    if ISInventoryPage.renderDirty then
        ISInventoryPage.renderDirty = false
        ISInventoryPage.dirtyUI()
        self.dirty = true
    end
    local loot, inventory = getPlayerLoot(PLAYER), getPlayerInventory(PLAYER)
    if not D.same(loot, self.nearby.sections, self.focus) then
        self.nearby.sections = D.sections(loot, player, false, self.nearby.sections, self.focus)
    end
    if self.across and not listed(self.nearby.sections, self.across) then self.across = nil end
    if not self.across then
        local floor = self.nearby:floor()
        self.across = floor and floor.container
    end
    local now = getTimestampMs()
    local every = self.dirty or now - self.refreshed > RESTACK_MS
    if every or not self.bags then self.bags = D.bags(inventory) end
    if not D.same(inventory, self.inventory.sections, nil, self.bags) then
        self.inventory.sections = D.sections(inventory, player, true, self.inventory.sections, nil, self.bags)
        self.inventory:addEquipped(player)
    end

    local chosen = inventory and inventory.inventory
    self.into = listed(self.inventory.sections, chosen) and chosen or nil
    self.inventory.alone = self.config.chosenAlone and self.into or nil
    D.restack(self.nearby.sections, player, every)
    D.restack(self.inventory.sections, player, every)
    if every then
        self.refreshed, self.dirty = now, false
        self.gear:refresh(player)
    end
end


local function place(tip, pointer)
    tip.followMouse = pointer == nil
    if pointer then
        tip:setX(pointer.x + 24)
        tip:setY(pointer.y + 24)
    end
end


function Screen:tooltip(item, weight)
    local menu = getPlayerContextMenu(PLAYER)
    if self.drag or (menu and menu:isAnyVisible()) then item = nil end
    if item == nil then
        if self.tip and self.tipShown then
            self.tip:removeFromUIManager()
            self.tip:setVisible(false)
        end
        self.tipShown, self.tipItem = false, nil
        return
    end
    if self.tip then place(self.tip, self.pointer) end
    if self.tipShown and item == self.tipItem and weight == self.tipWeight then return end
    if not self.tip then
        self.tip = ISToolTipInv:new(item)
        self.tip:initialise()
        self.tip:setOwner(self)
        self.tip:setCharacter(self.player)
    else
        self.tip:setItem(item)
    end
    place(self.tip, self.pointer)
    self.tip.tooltip:setWeightOfStack(weight or 0)
    if not self.tipShown then self.tip:addToUIManager() end
    self.tip:setVisible(true)
    self.tip:bringToTop()
    self.tipShown, self.tipItem, self.tipWeight = true, item, weight
end



function Screen:noteTip(note)
    if note == nil or self.drag then
        if self.note and self.noteShown then
            self.note:removeFromUIManager()
            self.note:setVisible(false)
        end
        self.noteShown, self.noteText = false, nil
        return
    end
    if self.note then place(self.note, self.pointer) end
    if self.noteShown and note == self.noteText then return end
    if not self.note then
        self.note = ISToolTip:new()
        self.note:initialise()
        self.note:setOwner(self)
        place(self.note, self.pointer)
    end
    self.note.description = note
    if not self.noteShown then self.note:addToUIManager() end
    self.note:setVisible(true)
    self.note:bringToTop()
    self.noteShown, self.noteText = true, note
end


function Screen:slotHint(h)
    if h.kind == "slot" and not h.item then
        self.hint = { h.slot.label }
    elseif h.kind == "hotbar" and not h.item then
        self.hint = { ViewpointInvBar.slotName(h.slot) }
    end
end


function Screen:track()
    local mx, my = self:getMouseX(), self:getMouseY()
    self.hint = nil
    if self.split or self.filterMenu then
        self.hover = nil
        self:noteTip(nil)
        return self:tooltip(nil)
    end
    local focus = self.padMode and self.padRect
    self.pointer = focus and { x = focus.x + focus.w - 12, y = focus.y + focus.h - 12 } or nil
    if self.padMode then
        self.hover = focus and focus.target
    else
        self.hover = self:hit(mx, my)
    end
    local h = self.hover
    self:noteTip(h and h.note)
    if self.drag and h then self:judge(h) end
    if not h then return self:tooltip(nil) end
    if h.kind == "tile" then return self:tooltip(h.stack.item, h.stack.count > 1 and h.stack.weight or 0) end
    local k = h.kind
    if k == "slot" or k == "slotDot" or k == "hand" or k == "hotbar" or k == "attachment" then
        self:slotHint(h)
        return self:tooltip(h.item, 0)
    end
    if h.label then self.hint = { h.label } end
    self:tooltip(nil)
end

function Screen:prerender()
    local player = getSpecificPlayer(PLAYER)
    if not player then return end
    self.player = player
    self:configure()
    local w, h = getCore():getScreenWidth(), getCore():getScreenHeight()
    if w ~= self.width or h ~= self.height then
        self:setWidth(w)
        self:setHeight(h)
        self.arranged = false
    end
    if not self.arranged then self:arrange() end
    self:hideStandIns()
    self:refresh(player)
    self.padMode = Screen.onPad()
    if self.padMode then self:padFrame() end
    ViewpointInvDevice.frame(self)
    if self.redress then
        self.redress = false
        self.avatar:bind(player)
    end
    if self.details and self.details:gone() then self:closeDetails() end
    self:track()
    S.rect(self, 0, 0, self.width, self.height, S.backdrop)
    self.nearby:render(self, self)
    self.gear:render(self, self)
    self:closeCross()
    self.inventory:render(self, self)
    self.tabs:render(self, self)
    if self.tabs:isCharacter() then self.hands:render(self, self) end
    self.bar:render(self, self)
end




function Screen:closeCross()
    local m = self.m
    local g = self.config.swap and self.nearby or self.gear
    local size = math.min(CROSS, m.title - 4)
    local x, y = g.x + g.w - m.pad - size, g.y + math.floor((m.title - size) / 2)
    local over = self.hover and self.hover.kind == "close"
    S.icon(self, cross, x, y, size, over and 1 or 0.6)
    self.closeRect = { x = x - 3, y = y - 3, w = size + 6, h = size + 6 }
end



function Screen:drawDrag(ui)
    local m = self.m
    local mx, my = self:getMouseX(), self:getMouseY()
    if self.pointer then mx, my = self.pointer.x, self.pointer.y end
    ViewpointInvGrid.tile(ui, m, mx - m.tile / 2, my - m.tile / 2, m.tile, self.drag.items[1], #self.drag.items,
        { hover = true })
end



function Screen:render()
    local m = self.m
    if not m then return end
    local mx, my = self:getMouseX(), self:getMouseY()
    if self.details then self.details:render(self, m, self.detailsRect, self.hover) end
    local box = self.press and self.press.box
    if box then S.selectionBox(self, box.x, box.y, box.w, box.h) end
    local focus = self.padMode and not self.split and self.padRect
    if focus then S.focusRing(self, focus.x, focus.y, focus.w, focus.h) end
    if self.pointer then mx, my = self.pointer.x, self.pointer.y end
    if self.drag and not ViewpointInvDevice.carrying then self:drawDrag(self) end
    if self.hint then
        local tm = getTextManager()
        local width = 0
        for _, line in ipairs(self.hint) do width = math.max(width, tm:MeasureStringX(UIFont.Small, line)) end
        local bw, bh = width + m.pad * 2, #self.hint * m.font + m.pad * 2
        local bx = math.min(mx + 18, self.width - bw - 4)
        local by = math.min(my + 18, self.height - bh - 4)
        S.rect(self, bx, by, bw, bh, S.panel, 0.96)
        S.edge(self, bx, by, bw, bh, S.panelEdge)
        for i, line in ipairs(self.hint) do
            S.text(self, line, bx + m.pad, by + m.pad + (i - 1) * m.font, i == 1 and S.bright or S.muted)
        end
    end
    if self.filterMenu then
        self.filterMenu:render(self, self.padMode and self.filterMenu.at or self.filterMenu:hit(mx, my))
    end
    if self.split then self.split:render(self, self.split:hit(mx, my)) end
end



function Screen:hideStandIns()
    for _, ui in ipairs({ getPlayerInventory(PLAYER), getPlayerLoot(PLAYER) }) do
        if ui and self.hidden[ui] == nil then
            self.hidden[ui] = ui:getIsVisible()
            ui:setVisible(false)
        end
    end
end



function Screen.show(focus, kept)
    local player = getSpecificPlayer(PLAYER)
    if not player then return false end
    local s = Screen.instance
    if not s then
        s = Screen:new()
        s:initialise()
        s:instantiate()
        Screen.instance = s
    end
    s:configure()
    s.focus, s.across = focus, focus
    s.dirty, s.arranged = true, false
    if not s:isVisible() or not s.up then
        if not kept then s:clearSearches() end
        s.tabs:own(player)
        s.hidden, s.into, s.padAt, s.padRect = {}, nil, nil, nil
        s:hideStandIns()
        s:addToUIManager()
        s:setVisible(true)
        s:setWantKeyEvents(true)
        s.avatar:bind(player)
        s:showAvatar()
        s.up = true
    end
    s:bringToTop()
    ViewpointInvDevice.raise()
    return true
end



function Screen.hide(kept)
    local s = Screen.instance
    if not s or not s.up then return end
    s.up = false
    s.drag, s.press, s.split, s.filterMenu = nil, nil, nil, nil
    ViewpointInvDevice.drag(s, nil)
    ViewpointInvDevice.close()
    s:setCapture(false)
    if kept then
        for _, box in ipairs(s.searches) do
            if box:isFocused() then box:unfocus() end
        end
    else
        s:clearSearches()
    end
    s:closeDetails()
    if not kept and not s.config.lastTab then s:selectTab("character") end
    s:tooltip(nil)
    s:noteTip(nil)
    local menu = getPlayerContextMenu(PLAYER)
    if menu then menu:hideAndChildren() end
    s:setVisible(false)
    s:removeFromUIManager()
    s:padRelease()
    for ui, shown in pairs(s.hidden or {}) do ui:setVisible(shown) end
    s.hidden = nil
end

function Screen.isUp()
    return Screen.instance ~= nil and Screen.instance.up == true
end


function Screen.focusOn(container)
    if Screen.instance then
        Screen.instance.focus, Screen.instance.across = container, container
        Screen.instance.dirty = true
    end
end


local function changed()
    if Screen.isUp() then Screen.instance.dirty = true end
end



local function dressed(player)
    changed()
    if Screen.isUp() and player == getSpecificPlayer(PLAYER) then Screen.instance.redress = true end
end

Events.OnClothingUpdated.Add(dressed)
Events.OnEquipPrimary.Add(changed)
Events.OnEquipSecondary.Add(changed)
Events.OnContainerUpdate.Add(changed)
Events.OnGameStart.Add(function() Screen.instance = nil end)
