









require "Viewpoint_InvStyle"
require "Viewpoint_InvData"

ViewpointInvList = {}
local L = ViewpointInvList
local S = ViewpointInvStyle
local D = ViewpointInvData

local folded = getTexture("media/ui/inventoryPanes/Button_TreeCollapsed.png")
local unfolded = getTexture("media/ui/inventoryPanes/Button_TreeExpanded.png")
local favourite = getTexture("media/ui/FavoriteStar.png")
local broken = getTexture("media/ui/icon_broken.png")


local ROW_EXTRA, TILE_IN, ICON_IN, ROW_ROUND, TILE_ROUND = 18, 3, 4, 4, 3

local TILE_LINE, TILE_FILL = { 0.24, 0.22, 0.2, 1.0 }, { 0.13, 0.12, 0.11, 1.0 }
local CONDITION_LINE = 2
local TRACK = { 1.0, 1.0, 1.0, 0.08 }

local ARROW, ARROW_REACH, MARK = 10, 2, 11

local BAR_WIDTH, CATEGORY = 1.8, 0.26

local widths, widthCount = {}, 0

local function width(text, font)
    font = font or UIFont.Small
    local key = text .. "\0" .. tostring(font)
    local w = widths[key]
    if w then return w end
    if widthCount > 400 then widths, widthCount = {}, 0 end
    w = getTextManager():MeasureStringX(font, text)
    widths[key], widthCount = w, widthCount + 1
    return w
end

local function hit(grid, x, y, w, h, target)
    table.insert(grid.hits, { x = x, y = y, w = w, h = h, target = target })
end



function L.layout(grid)
    local m = grid.m
    local l = { row = m.font + ROW_EXTRA }
    l.tile = l.row - TILE_IN * 2
    local left, right = grid.x + m.pad, grid.x + grid.w - m.pad
    l.arrowX = left + 2
    l.tileX = l.arrowX + ARROW + m.pad
    l.nameX = l.tileX + l.tile + m.pad + 4
    l.weightRight = right - m.pad
    l.weightX = l.weightRight - width("000.00")
    l.catW = math.floor((right - left) * CATEGORY)
    l.catX = l.weightX - m.pad * 2 - l.catW
    grid.lm = l
end


local function glyph(ui, r, list, c)
    local g = math.max(3, math.floor(r.h * 0.18))
    local side = g * 2 + 2
    local x, y = r.x + math.floor((r.w - side) / 2), r.y + math.floor((r.h - side) / 2)
    if not list then
        for i = 0, 3 do S.rect(ui, x + (i % 2) * (g + 2), y + math.floor(i / 2) * (g + 2), g, g, c) end
        return
    end
    local line = math.max(1, math.floor(g / 2))
    local step = math.floor((side - line) / 2)
    for i = 0, 2 do S.rect(ui, x, y + i * step, side, line, c) end
end



function L.switch(grid, ui, view)
    for _, r in ipairs({ grid.gridRect, grid.listRect }) do
        local list = r == grid.listRect
        local on = grid.list == list
        local over = view.hover and view.hover.kind == "layout" and view.hover.grid == grid and view.hover.list == list
        S.segment(ui, r.x, r.y, r.w, r.h, on, over)
        glyph(ui, r, list, (on or over) and S.bright or S.muted)
    end
end


local function rowCount(stacks)
    local n, group = #stacks, nil
    for _, stack in ipairs(stacks) do
        if stack.group and stack.group ~= group then n = n + 1 end
        group = stack.group
    end
    return n
end


function L.height(grid, stacks)
    local m = grid.m
    if #stacks == 0 then return m.font + m.gap * 2 end
    return m.gap + rowCount(stacks) * grid.lm.row
end




local function tile(grid, ui, stack, tx, ty, state)
    local l, look = grid.lm, stack.look
    local condition = not state.selected and S.condition(look.condition, look.broken)
    local line = condition and CONDITION_LINE or 1
    S.soft(ui, tx, ty, l.tile, l.tile, TILE_ROUND, state.selected and S.accent or condition or TILE_LINE)
    S.soft(ui, tx + line, ty + line, l.tile - line * 2, l.tile - line * 2, TILE_ROUND - line, TILE_FILL)
    local kind = S.typeTint(look.junk and D.JUNK or look.type)
    if kind then S.rect(ui, tx + 2, ty + 2, l.tile - 4, l.tile - 4, kind) end
    local icon = l.tile - ICON_IN * 2
    ui.javaObject:DrawItemIcon(stack.item, tx + ICON_IN, ty + ICON_IN, state.dim and 0.45 or 1.0, icon, icon)
    if stack.slot then S.text(ui, tostring(stack.slot), tx + 2, ty, S.accent) end
end



local function words(grid, ui, stack, x, y, limit, child, dim)
    local m, l, look = grid.m, grid.lm, stack.look
    local cy = y + math.floor((l.row - m.font) / 2)
    local count = not child and stack.count > 1 and (" (" .. stack.count .. ")") or ""
    local name = child and (stack.name .. " #" .. stack.index) or stack.name
    local barW = look.amount and math.floor(m.font * BAR_WIDTH) or 0
    local mark = look.broken and broken or (look.favourite and favourite or nil)
    local extras = (barW > 0 and barW + m.pad or 0) + (mark and MARK + m.pad or 0)
    local shown = S.fit(name, math.max(m.font * 3, limit - x - extras - width(count))) .. count
    S.text(ui, shown, x, cy, dim and S.dim or S.bright)
    x = x + width(shown) + m.pad
    if barW > 0 and x + barW <= limit then
        S.soft(ui, x, y + math.floor((l.row - 3) / 2), barW, 3, 1, TRACK)
        S.soft(ui, x, y + math.floor((l.row - 3) / 2), math.max(1, math.floor(barW * look.amount)), 3, 1, S.amount)
        x = x + barW + m.pad
    end
    if mark and x + MARK <= limit then S.icon(ui, mark, x, y + math.floor((l.row - MARK) / 2), MARK) end
end




local function row(grid, ui, s, stack, y, state, arrow, arrowStack, child)
    local m, l = grid.m, grid.lm
    local x, w, h = grid.x + m.pad, grid.w - m.pad * 2, l.row
    if state.selected then
        S.rowSelected(ui, x, y, w, h)
    elseif state.hover then
        S.soft(ui, x, y, w, h, ROW_ROUND, S.wash, 0.06)
    end
    if state.job and state.job > 0 then S.soft(ui, x, y, math.floor(w * state.job), h, ROW_ROUND, S.job) end
    if state.edge then S.edge(ui, x, y, w, h, state.edge) end
    hit(grid, x, y, w, h, { kind = "tile", section = s, stack = stack })
    if arrow then
        local ay = y + math.floor((h - ARROW) / 2)
        S.icon(ui, arrow, l.arrowX, ay, ARROW)
        local reach = ARROW + ARROW_REACH * 2
        hit(grid, l.arrowX - ARROW_REACH, ay - ARROW_REACH, reach, reach,
            { kind = "stackArrow", section = s, stack = arrowStack })
    end
    tile(grid, ui, stack, l.tileX + (child and m.pad or 0), y + TILE_IN, state)
    local nameX = l.nameX + (child and m.pad or 0)
    words(grid, ui, stack, nameX, y, l.catX - m.pad, child, state.dim)
    local cy = y + math.floor((h - m.font) / 2)
    S.text(ui, S.fit(stack.cat, l.catW), l.catX, cy, state.dim and S.dim or S.muted)
    S.textRight(ui, string.format("%.2f", stack.weight), l.weightRight, cy, state.dim and S.dim or S.muted)
end


local function stateOf(view, chosen, stack, working)
    local hover = view.hover and view.hover.stack == stack
    local state = { hover = hover, selected = chosen[stack.key] or (stack.group and chosen[stack.group.key]),
        dim = stack.unwanted, job = working and D.job(stack) or nil }
    local into = hover and view.drag and view.hover.into
    if into then state.edge = view.drag.bags[into] and S.drop or S.refuse end
    return state
end



function L.rows(grid, ui, s, stacks, top, bottomEdge, view)
    local m, l = grid.m, grid.lm
    if #stacks == 0 then
        if not s.locked then S.text(ui, getText("Fluid_Empty"), l.nameX, top + m.gap, S.dim) end
        return L.height(grid, stacks)
    end
    local chosen = view.selected[s.container] or {}
    local working = not view.player:getCharacterActions():isEmpty()
    local y, group = top + m.gap, nil
    local function shows(at)
        return at + l.row >= grid.bodyTop and at <= bottomEdge
    end
    for _, stack in ipairs(stacks) do
        if stack.group and stack.group ~= group then
            if shows(y) then
                row(grid, ui, s, stack.group, y, stateOf(view, chosen, stack.group, working), unfolded, stack)
            end
            y = y + l.row
        end
        group = stack.group
        if shows(y) then
            local arrow = not stack.group and stack.count > 1 and folded or nil
            row(grid, ui, s, stack, y, stateOf(view, chosen, stack, working), arrow, stack, stack.group ~= nil)
        end
        y = y + l.row
    end
    return y - top
end
