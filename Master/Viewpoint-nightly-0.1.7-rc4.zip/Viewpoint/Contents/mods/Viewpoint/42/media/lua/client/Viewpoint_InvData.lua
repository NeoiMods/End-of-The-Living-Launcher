






ViewpointInvData = {}
local D = ViewpointInvData

local PLAYER = 0



local function name(item, player)
    local itemName = item:getName(player)
    local herbal = item:IsFood() and item:getHerbalistType()
    if not herbal or herbal == "" then return itemName end
    local poison = item:getPoisonPower() > 0
    if player:isRecipeActuallyKnown("Herbalist") then
        if herbal == "Berry" then itemName = poison and getText("IGUI_PoisonousBerry") or getText("IGUI_Berry") end
        if herbal == "Mushroom" then itemName = poison and getText("IGUI_PoisonousMushroom") or getText("IGUI_Mushroom") end
    else
        if herbal == "Berry" then itemName = getText("IGUI_UnknownBerry") end
        if herbal == "Mushroom" then itemName = getText("IGUI_UnknownMushroom") end
    end
    if itemName ~= item:getDisplayName() then item:setName(itemName) end
    return item:getName(player)
end



local function isJunk(item, player)
    local v = Viewpoint and Viewpoint.Inventory
    return v ~= nil and v.isJunk(item, player)
end


local function hotbarSlots()
    local slots = {}
    local hotbar = getPlayerHotbar(PLAYER)
    if hotbar and hotbar.attachedItems then
        for slot, item in pairs(hotbar.attachedItems) do slots[item] = slot end
    end
    return slots
end



local function carried(player, shown)
    local skip = {}
    local worn = player:getWornItems()
    for i = 0, worn:size() - 1 do skip[worn:get(i):getItem()] = true end
    if player:getPrimaryHandItem() then skip[player:getPrimaryHandItem()] = true end
    if player:getSecondaryHandItem() then skip[player:getSecondaryHandItem()] = true end
    local items = player:getInventory():getItems()
    for i = 0, items:size() - 1 do
        local item = items:get(i)
        if item:IsInventoryContainer() and shown[item:getInventory()] then skip[item] = true end
    end
    return skip
end


local function equipped(player)
    local list, seen = {}, {}
    local function add(item)
        if item and not seen[item] then
            seen[item] = true
            table.insert(list, item)
        end
    end
    local worn = player:getWornItems()
    for i = 0, worn:size() - 1 do add(worn:get(i):getItem()) end
    add(player:getPrimaryHandItem())
    add(player:getSecondaryHandItem())
    local hotbar = getPlayerHotbar(PLAYER)
    for _, item in pairs(hotbar and hotbar.attachedItems or {}) do add(item) end
    return list
end



local categories = {}

function D.category(item)
    local cat = tostring(item:getDisplayCategory() or item:getCategory())
    if not categories[cat] then categories[cat] = getTextOrNull("IGUI_ItemCat_" .. cat) or cat end
    return categories[cat]
end





D.TYPES = {
    { "Weapon", "WeaponCrafted", "WeaponImprovised", "WeaponPart", "Explosives", "BrokenWeapon", "SportsWeapon",
        "InstrumentWeapon" },
    { "Ammo" },
    { "Clothing", "ProtectiveGear", "Accessory", "Bag", "Container", "Memento" },
    { "FirstAid", "FirstAidWeapon", "Bandage", "Wound" },
    { "Food", "Water", "WaterContainer", "Cooking", "CookingWeapon" },
    { "Tool", "ToolWeapon", "Gardening", "GardeningWeapon", "Fishing", "FishingWeapon", "Trapping", "Camping",
        "VehicleMaintenance", "VehicleMaintenanceWeapon", "LightSource", "FireSource", "Electronics", "Communications",
        "Security", "Household", "HouseholdWeapon", "Paint" },
    { "Material", "MaterialWeapon", "Junk", "JunkWeapon", "AnimalPart", "AnimalPartWeapon" },
    { "Literature", "SkillBook", "RecipeResource", "Cartography" },
}


D.JUNK = #D.TYPES + 1
local typeOf, typed = {}, {}
for i, cats in ipairs(D.TYPES) do
    for _, cat in ipairs(cats) do typeOf[cat] = i end
end


function D.type(item)
    local cat = item:getDisplayCategory()
    if not cat then return nil end
    cat = tostring(cat)
    local t = typed[cat]
    if t == nil then
        t = typeOf[cat] or (string.find(cat, "Weapon$") and 1) or false
        typed[cat] = t
    end
    return t or nil
end

local function byLabel(a, b)
    if a.name ~= b.name then return a.name < b.name end
    return a.key < b.key
end

local function byName(a, b)
    if (a.slot ~= nil) ~= (b.slot ~= nil) then return a.slot ~= nil end
    return byLabel(a, b)
end

local function byCategory(a, b)
    if a.cat ~= b.cat then return a.cat < b.cat end
    return byLabel(a, b)
end

local function byWeight(a, b)
    if a.weight ~= b.weight then return a.weight > b.weight end
    return byLabel(a, b)
end




D.ORDERS = {
    { label = getText("IGUI_invpanel_Type"), less = byName, up = true },
    { label = getText("IGUI_invpanel_Category"), less = byCategory, up = true },
    { label = getText("IGUI_invpanel_weight"), less = byWeight, up = false },
}


for _, order in ipairs(D.ORDERS) do
    local less = order.less
    order.flip = { label = order.label, less = function(a, b) return less(b, a) end, up = not order.up, flip = order,
        back = true }
end



local function opened(list, player, slots, open)
    local out = {}
    for _, stack in ipairs(list) do
        if open[stack.key] and stack.count > 1 then
            for i, item in ipairs(stack.items) do
                local look = D.look(item)
                look.junk = stack.junk
                table.insert(out, { key = stack.key .. "#" .. item:getID(), name = stack.name, cat = stack.cat,
                    find = stack.find, items = { item }, item = item, count = 1, weight = item:getUnequippedWeight(),
                    slot = slots and slots[item], look = look, unwanted = item:isUnwanted(player), junk = stack.junk,
                    group = stack, index = i })
            end
        else
            open[stack.key] = nil
            table.insert(out, stack)
        end
    end
    return out
end



local function stackUp(list, index, item, player, slots, prefix)
    local itemName = name(item, player)
    local slot = slots and slots[item]
    local key = slot and ("hotbar:" .. itemName) or (prefix .. itemName)
    local stack = index[key]
    if not stack then
        local cat = D.category(item)
        local look, junk = D.look(item), isJunk(item, player)
        look.junk = junk
        stack = { key = key, name = itemName, cat = cat, find = string.lower(itemName .. "\n" .. cat), items = {},
            item = item, count = 0, weight = 0, slot = slot, look = look, unwanted = item:isUnwanted(player),
            junk = junk }
        index[key] = stack
        table.insert(list, stack)
    end
    table.insert(stack.items, item)
    stack.count = stack.count + 1
    stack.weight = stack.weight + item:getUnequippedWeight()
end






function D.stacks(container, player, skip, slots, open)
    local list, index = {}, {}
    local items = container:getItems()
    for i = 0, items:size() - 1 do
        local item = items:get(i)
        if not item:isHidden() and not (skip and skip[item]) then stackUp(list, index, item, player, slots, "") end
    end
    return open and opened(list, player, slots, open) or list
end



function D.equippedStacks(player, slots, open)
    local list, index = {}, {}
    for _, item in ipairs(equipped(player)) do
        if not item:isHidden() then stackUp(list, index, item, player, slots, "equipped:") end
    end
    return open and opened(list, player, slots, open) or list
end



local function grouped(less)
    return function(a, b)
        local ga, gb = a.group or a, b.group or b
        if ga ~= gb then
            if less(ga, gb) then return true end
            if less(gb, ga) then return false end
            return ga.key < gb.key
        end
        return (a.index or 0) < (b.index or 0)
    end
end




function D.shown(s, query, order, filter)
    local v = s.shown
    if v and v.stacks == s.stacks and v.query == query and v.order == order and v.filter == filter.key then
        return v.list
    end
    local list = {}
    for _, stack in ipairs(s.stacks) do
        if (query == "" or string.find(stack.find, query, 1, true)) and filter:passes(stack) then
            table.insert(list, stack)
        end
    end
    table.sort(list, grouped(order.less))
    s.shown = { stacks = s.stacks, query = query, order = order, filter = filter.key, list = list }
    return list
end




function D.chosen(grid, selected)
    local list = {}
    local narrowed = grid:narrowed()
    for _, s in ipairs(grid.sections) do
        local keys = selected[s.container]
        if keys and grid:lists(s) and (narrowed or not s.folded) then
            for _, stack in ipairs(D.shown(s, grid.query, grid.order, grid.filter)) do
                if keys[stack.key] or stack.group and keys[stack.group.key] then table.insert(list, stack) end
            end
        end
    end
    return list
end



local function keyRing(container)
    local item = container:getContainingItem()
    return item ~= nil and (item:isItemType(ItemType.KEY_RING) or item:hasTag(ItemTag.KEY_RING))
end

local function walkBags(container, listed, bags)
    local items = container:getItems()
    for i = 0, items:size() - 1 do
        local item = items:get(i)
        local inside = item:IsInventoryContainer() and item:getInventory()
        if inside and not listed[inside] then
            listed[inside] = true
            bags.inside[container] = bags.inside[container] or {}
            table.insert(bags.inside[container], { inventory = inside, name = item:getName(), image = item:getTex() })
            bags.count = bags.count + 1
            walkBags(inside, listed, bags)
        end
    end
end






function D.bags(page)
    local listed, bags = {}, { inside = {}, count = 0 }
    local buttons = page and page.backpacks or {}
    for _, button in ipairs(buttons) do
        if button.inventory then listed[button.inventory] = true end
    end
    for _, button in ipairs(buttons) do
        if button.inventory then walkBags(button.inventory, listed, bags) end
    end
    return bags
end


local function section(button, player, mine)
    local container = button.inventory
    return {
        container = container,
        title = button.name or "",
        icon = button.image,
        tint = button.textureColor,
        lock = button.textureOverride,
        locked = container:isLockedToCharacter(player),
        floor = container:getType() == "floor",
        main = container == player:getInventory(),
        keyRing = keyRing(container),
        mine = mine,
        stacks = {},
        open = {},
        count = -1,
        weight = -1,
    }
end



local function addBags(list, kept, bags, container, within, player, mine)
    for _, bag in ipairs(bags and bags.inside[container] or {}) do
        local s = kept[bag.inventory] or section(bag, player, mine)
        s.title, s.icon, s.bag, s.within = bag.name, bag.image, true, within
        s.locked = s.container:isLockedToCharacter(player)
        table.insert(list, s)
        addBags(list, kept, bags, bag.inventory, within, player, mine)
    end
end





function D.sections(page, player, mine, held, focus, bags)
    local list, kept = {}, {}
    for _, s in ipairs(held or {}) do
        if not s.equipped then kept[s.container] = s end
    end
    for _, button in ipairs(page and page.backpacks or {}) do
        if button.inventory then
            local s = kept[button.inventory] or section(button, player, mine)
            s.title, s.icon, s.lock = button.name or s.title, button.image, button.textureOverride
            s.locked = s.container:isLockedToCharacter(player)
            if s.container == focus then table.insert(list, 1, s) else table.insert(list, s) end
            addBags(list, kept, bags, button.inventory, button.inventory, player, mine)
        end
    end
    return list
end



function D.same(page, sections, focus, bags)
    local buttons = page and page.backpacks or {}
    local shown, count = {}, 0
    for _, s in ipairs(sections) do
        if not s.equipped then shown[s.container], count = true, count + 1 end
    end
    if #buttons + (bags and bags.count or 0) ~= count then return false end
    for _, button in ipairs(buttons) do
        if not shown[button.inventory] then return false end
    end
    for _, inside in pairs(bags and bags.inside or {}) do
        for _, bag in ipairs(inside) do
            if not shown[bag.inventory] then return false end
        end
    end
    return focus == nil or not shown[focus] or sections[1].container == focus
end




function D.restack(sections, player, every)
    local shown = {}
    for _, s in ipairs(sections) do
        if not s.bag then shown[s.container] = true end
    end
    local slots, skip
    for _, s in ipairs(sections) do
        local items = s.container:getItems()
        local count, weight = items:size(), s.container:getContentsWeight()
        if every or count ~= s.count or math.abs(weight - s.weight) > 0.001 then
            s.count, s.weight = count, weight
            slots = slots or hotbarSlots()
            if s.locked then
                s.stacks = {}
            elseif s.equipped then
                s.stacks = D.equippedStacks(player, slots, s.open)
            else
                if s.main then skip = skip or carried(player, shown) end
                s.stacks = D.stacks(s.container, player, s.main and skip or nil, s.mine and slots or nil, s.open)
            end
        end
    end
end



function D.load(s, player)
    if s.equipped then
        local load = 0
        for _, stack in ipairs(s.stacks) do load = load + stack.weight end
        return load, 0
    end
    if s.main then return player:getInventoryWeight(), player:getMaxWeight() end
    if s.floor then return s.container:getCapacityWeight(), 0 end
    return s.container:getCapacityWeight(), s.container:getEffectiveCapacity(player)
end


function D.condition(item)
    local most = item:getConditionMax()
    if most <= 0 then return nil end
    local now = item:getCondition()
    if instanceof(item, "HandWeapon") or instanceof(item, "Clothing") or now < most then return now / most end
    return nil
end


function D.amount(item)
    if item:IsDrainable() then return item:getCurrentUsesFloat() end
    local fluid = item:getFluidContainer()
    if fluid then return fluid:getFilledRatio() end
    return nil
end



function D.look(item)
    return { type = D.type(item), condition = D.condition(item), broken = item:isBroken(), amount = D.amount(item),
        favourite = item:isFavorite() }
end



local JOB_ITEMS = 16


function D.job(stack)
    local job = 0
    for i = 1, math.min(#stack.items, JOB_ITEMS) do job = math.max(job, stack.items[i]:getJobDelta()) end
    return job
end


function D.items(stacks)
    local list, seen = {}, {}
    for _, stack in ipairs(stacks) do
        for _, item in ipairs(stack.items) do
            if not seen[item] then
                seen[item] = true
                table.insert(list, item)
            end
        end
    end
    return list
end
