








require "Viewpoint_InvStyle"
require "Viewpoint_InvData"

ViewpointInvFilter = {}
local F = ViewpointInvFilter
F.__index = F
local S = ViewpointInvStyle
local D = ViewpointInvData

local JUNK = "junk"
local ALL = "all"


local ENTRIES = {}
for i = 1, #D.TYPES do ENTRIES[i] = i end
table.insert(ENTRIES, JUNK)


F.WIDEST = "Filter (" .. #ENTRIES .. ")"

function F.new()
    local filter = setmetatable({ ticked = {}, count = 0, key = "" }, F)
    filter:all(true)
    return filter
end


function F:narrows()
    return self.count < #ENTRIES
end


function F:passes(stack)
    if not self:narrows() then return true end
    if stack.junk then return self.ticked[JUNK] == true end
    local t = stack.look and stack.look.type
    return t ~= nil and self.ticked[t] == true
end


local function rekey(self)
    local names = {}
    for _, e in ipairs(ENTRIES) do
        if self.ticked[e] then table.insert(names, tostring(e)) end
    end
    self.count, self.key = #names, table.concat(names, ",")
end

function F:toggle(entry)
    self.ticked[entry] = not self.ticked[entry] or nil
    rekey(self)
end


function F:all(on)
    self.ticked = {}
    if on then
        for _, e in ipairs(ENTRIES) do self.ticked[e] = true end
    end
    rekey(self)
end


function F:label()
    return self:narrows() and ("Filter (" .. self.count .. ")") or "Filter"
end


local function nameOf(entry)
    if entry == ALL then return getText("UI_All") end
    if entry == JUNK then return "Junk" end
    local v = Viewpoint and Viewpoint.Inventory
    local name = v and v.typeLabel(entry - 1)
    return (name and name ~= "") and name or D.TYPES[entry][1]
end


local Menu = {}
Menu.__index = Menu



function F.menu(filter, r, m, width, height)
    local rows = { ALL }
    for _, e in ipairs(ENTRIES) do table.insert(rows, e) end
    local widest = 0
    for _, e in ipairs(rows) do widest = math.max(widest, getTextManager():MeasureStringX(UIFont.Small, nameOf(e))) end
    local rowH = m.font + m.pad
    local w = math.max(r.w, widest + m.font + m.pad * 4)
    local h = #rows * rowH + m.pad * 2
    local x = math.max(4, math.min(r.x, width - w - 4))
    local y = r.y + r.h + 2
    if y + h > height - 4 then y = math.max(4, r.y - h - 2) end
    return setmetatable({ filter = filter, rows = rows, m = m, rowH = rowH, x = x, y = y, w = w, h = h, at = 1 }, Menu)
end


function Menu:ticked(entry)
    if entry == ALL then return not self.filter:narrows() end
    return self.filter.ticked[entry] == true
end


function Menu:render(ui, hover)
    local m = self.m
    S.rect(ui, self.x, self.y, self.w, self.h, S.panel, 0.98)
    S.edge(ui, self.x, self.y, self.w, self.h, S.modern and S.selected or S.panelEdge)
    local box = m.font - 4
    for i, entry in ipairs(self.rows) do
        local ry = self.y + m.pad + (i - 1) * self.rowH
        if hover == i then S.rowHover(ui, self.x + 1, ry, self.w - 2, self.rowH) end
        local bx, by = self.x + m.pad, ry + math.floor((self.rowH - box) / 2)
        local on = self:ticked(entry)
        S.rect(ui, bx, by, box, box, S.field)
        S.edge(ui, bx, by, box, box, S.panelEdge)
        if on then S.rect(ui, bx + 2, by + 2, box - 4, box - 4, S.accent) end
        local ty = ry + math.floor((self.rowH - m.font) / 2)
        S.text(ui, nameOf(entry), bx + box + m.pad, ty, (on or hover == i) and S.bright or S.muted)
    end
end


function Menu:hit(mx, my)
    if mx < self.x or mx >= self.x + self.w or my < self.y or my >= self.y + self.h then return nil end
    local i = math.floor((my - self.y - self.m.pad) / self.rowH) + 1
    if i >= 1 and i <= #self.rows then return i end
    return "panel"
end


function Menu:choose(i)
    local entry = self.rows[i]
    if entry == ALL then
        self.filter:all(self.filter:narrows())
    elseif entry then
        self.filter:toggle(entry)
    end
end


function Menu:press(mx, my)
    local h = self:hit(mx, my)
    if h == nil then return true end
    if h ~= "panel" then self:choose(h) end
    return false
end


function Menu:step(dy)
    self.at = math.max(1, math.min(#self.rows, self.at + dy))
end
