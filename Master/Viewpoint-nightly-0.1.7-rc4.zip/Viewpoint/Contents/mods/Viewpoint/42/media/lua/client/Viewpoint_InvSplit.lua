




require "Viewpoint_InvStyle"
require "Viewpoint_InvGrid"

ViewpointInvSplit = {}
local P = ViewpointInvSplit
P.__index = P
local S = ViewpointInvStyle



function P.new(items, most, move, x, y, m, width, height)
    local w = math.max(m.unit * 6, 260)
    local h = m.pad * 4 + m.unit + m.header * 2
    return setmetatable({
        items = items, most = most, move = move, n = math.max(1, math.floor(most / 2)), m = m, hits = {},
        x = math.floor(math.max(4, math.min(x - w / 2, width - w - 4))),
        y = math.floor(math.max(4, math.min(y - h / 2, height - h - 4))),
        w = w, h = h,
    }, P)
end

function P:set(n)
    self.n = math.max(1, math.min(self.most, math.floor(n + 0.5)))
end


function P:slide(mx)
    local t = self.track
    local f = math.max(0, math.min(1, (mx - t.x) / math.max(1, t.w)))
    self:set(1 + f * (self.most - 1))
end

function P:wheel(del)
    self:set(self.n - del)
end


function P:confirm()
    local list = {}
    for i = 1, self.n do list[i] = self.items[i] end
    self.move(list)
end

local function region(self, x, y, w, h, kind)
    table.insert(self.hits, { x = x, y = y, w = w, h = h, kind = kind })
end

local function button(self, ui, label, x, y, w, kind, hover, strong)
    S.button(ui, self.m, x, y, w, self.m.header, label, hover == kind, false, strong)
    region(self, x, y, w, self.m.header, kind)
end



function P:slider(ui, top, hover)
    local m = self.m
    local t = { x = self.x + m.pad + 6, w = self.w - m.pad * 2 - 12 }
    self.track = t
    local mid = top + math.floor(m.header / 2)
    local f = self.most > 1 and (self.n - 1) / (self.most - 1) or 1
    local kx = t.x + math.floor(t.w * f)
    local held = hover == "track" or self.sliding
    if S.modern then
        S.rect(ui, t.x, mid - 2, t.w, 4, S.track)
        S.rect(ui, t.x, mid - 2, kx - t.x, 4, S.accent)
        S.rect(ui, kx - 5, top + 2, 10, m.header - 4, held and S.bright or S.accent)
    else
        S.rect(ui, t.x, mid - 3, t.w, 6, S.track)
        S.edge(ui, t.x, mid - 3, t.w, 6, S.panelEdge)
        S.rect(ui, t.x + 1, mid - 2, kx - t.x - 1, 4, S.accent)
        S.rect(ui, kx - 5, top + 2, 10, m.header - 4, held and S.headerHover or S.buttonFill)
        S.edge(ui, kx - 5, top + 2, 10, m.header - 4, S.lightEdge)
    end
    region(self, self.x + m.pad, top, self.w - m.pad * 2, m.header, "track")
end


function P:render(ui, hover)
    local m = self.m
    self.hits = {}
    local x, y, w = self.x, self.y, self.w
    S.rect(ui, x, y, w, self.h, S.panel, 0.98)
    S.edge(ui, x, y, w, self.h, S.modern and S.selected or S.panelEdge)
    ViewpointInvGrid.tile(ui, m, x + m.pad, y + m.pad, m.unit, self.items[1], self.most, {})
    local tx = x + m.pad * 2 + m.unit
    S.text(ui, S.fit(self.items[1]:getDisplayName(), x + w - m.pad - tx), tx, y + m.pad, S.bright)
    S.text(ui, getText("IGUI_PlayerStats_Amount"), tx, y + m.pad + m.font + m.gap, S.muted)
    local number = S.modern and S.accent or S.bright
    S.textRight(ui, self.n .. " / " .. self.most, x + w - m.pad, y + m.pad + m.font, number, nil, UIFont.Medium)
    local top = y + m.pad * 2 + m.unit
    self:slider(ui, top, hover)
    local by = top + m.header + m.pad
    local bw = math.floor((w - m.pad * 4) / 3)
    button(self, ui, getText("UI_All"), x + m.pad, by, bw, "all", hover)
    button(self, ui, getText("UI_Cancel"), x + m.pad * 2 + bw, by, bw, "cancel", hover)
    button(self, ui, getText("UI_Ok"), x + m.pad * 3 + bw * 2, by, bw, "ok", hover, true)
end


function P:hit(mx, my)
    for _, h in ipairs(self.hits) do
        if mx >= h.x and mx < h.x + h.w and my >= h.y and my < h.y + h.h then return h.kind end
    end
    if mx >= self.x and mx < self.x + self.w and my >= self.y and my < self.y + self.h then return "panel" end
    return nil
end


function P:press(mx, my)
    local kind = self:hit(mx, my)
    if kind == "track" then
        self.sliding = true
        self:slide(mx)
    elseif kind == "all" then
        self.n = self.most
    elseif kind == "ok" then
        self:confirm()
        return true
    elseif kind ~= "panel" then
        return true
    end
    return false
end
