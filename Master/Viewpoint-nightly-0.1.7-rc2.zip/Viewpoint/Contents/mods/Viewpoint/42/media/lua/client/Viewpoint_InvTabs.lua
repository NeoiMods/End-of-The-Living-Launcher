





require "Viewpoint_InvStyle"
require "Viewpoint_InvTabInfo"
require "Viewpoint_InvTabSkills"
require "Viewpoint_InvTabHealth"
require "Viewpoint_InvTabProtection"
require "Viewpoint_InvTabTemperature"

ViewpointInvTabs = {}
local T = ViewpointInvTabs
T.__index = T
local S = ViewpointInvStyle


local TABS = {
    { id = "character", key = "SurvivalGuide_character_title" },
    { id = "info", key = "IGUI_XP_Info", make = ViewpointInvTabInfo.new },
    { id = "skills", key = "IGUI_XP_Skills", make = ViewpointInvTabSkills.new },
    { id = "health", key = "IGUI_XP_Health", make = ViewpointInvTabHealth.new },
    { id = "protection", key = "IGUI_XP_Protection", make = ViewpointInvTabProtection.new },
    { id = "temperature", key = "IGUI_XP_ClothingIns", make = ViewpointInvTabTemperature.new },
}

local byId = {}
for _, tab in ipairs(TABS) do byId[tab.id] = tab end

function T.new()
    return setmetatable({ active = "character", views = {}, buttons = {} }, T)
end

function T:isCharacter()
    return self.active == "character"
end


function T:shown()
    return self.views[self.active]
end



function T:layout(x, y, w, area, m)
    self.m, self.area = m, area
    local text = 0
    for _, tab in ipairs(TABS) do
        tab.label = S.caps(getText(tab.key))
        tab.width = S.labelWidth(m, tab.label)
        text = text + tab.width
    end
    local side = math.max(4, math.min(m.pad * 2, math.floor((w - text - m.gap * (#TABS - 1)) / (#TABS * 2))))
    local total = text + side * 2 * #TABS + m.gap * (#TABS - 1)
    local bx = x + math.floor((w - total) / 2)
    self.buttons = {}
    for i, tab in ipairs(TABS) do
        self.buttons[i] = { tab = tab, x = bx, y = y, w = tab.width + side * 2, h = m.title }
        bx = bx + tab.width + side * 2 + m.gap
    end
    for _, pane in pairs(self.views) do pane:layout(area, m) end
end


function T:own(player)
    if self.owner == player then return end
    self:select("character")
    self.views, self.owner = {}, player
end

function T:select(id)
    self.active = id
    local tab = byId[id]
    if tab.make and not self.views[id] then
        self.views[id] = tab.make()
        if self.area then self.views[id]:layout(self.area, self.m) end
    end
end



function T:along(delta)
    for i, tab in ipairs(TABS) do
        if tab.id == self.active then return TABS[(i - 1 + delta + #TABS) % #TABS + 1].id end
    end
    return TABS[1].id
end


function T:render(ui, screen)
    for _, b in ipairs(self.buttons) do
        local on = b.tab.id == self.active
        local over = screen.hover and screen.hover.kind == "tab" and screen.hover.id == b.tab.id
        S.tab(ui, self.m, b.x, b.y, b.w, b.h, b.tab.label, on, over)
    end
    local shown = self:shown()
    if shown then shown:render(ui, screen) end
end


function T:hit(mx, my)
    for _, b in ipairs(self.buttons) do
        if mx >= b.x and mx < b.x + b.w and my >= b.y and my < b.y + b.h then return { kind = "tab", id = b.tab.id } end
    end
    local shown = self:shown()
    return shown and shown:hit(mx, my)
end


function T:wheel(mx, my, del)
    local shown = self:shown()
    return shown ~= nil and shown.wheel ~= nil and shown:wheel(mx, my, del)
end


function T:apply(part, items)
    if self.views.health then self.views.health:apply(part, items) end
end


function T:menu(part, x, y)
    if self.views.health then self.views.health:menu(part, x, y) end
end
