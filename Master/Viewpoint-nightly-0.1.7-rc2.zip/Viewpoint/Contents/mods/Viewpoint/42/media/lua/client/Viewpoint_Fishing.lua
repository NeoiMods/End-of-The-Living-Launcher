










local CAST_DELAY = 85




local ARC_FROM, ARC_TO = -66, 66
local TAUT, BREAKING = 22, 46


local BAR_WIDTH, BAR_LENGTH, EDGE, NEEDLE, NEEDLE_PAST = 10, 118, 2, 3, 3
local TAN = { 0.863, 0.714, 0.486 }
local RED = { 0.820, 0.325, 0.325 }
local NEEDLE_GREY = 0.816

local function fishing()
    return Viewpoint and Viewpoint.Fishing
end

local function ours(player)
    return player ~= nil and player:isLocalPlayer() and player:getPlayerNum() == 0
end

local function wrapAim()
    local utils = Fishing and Fishing.Utils
    if not utils or utils.viewpointWrapped then return end
    local getAimCoords = utils.getAimCoords
    utils.getAimCoords = function(player, ...)
        local f = fishing()
        if f and ours(player) and f.aims() then
            return f.aimX(), f.aimY()
        end
        return getAimCoords(player, ...)
    end


    local facePlayerToAim = utils.facePlayerToAim
    utils.facePlayerToAim = function(player, ...)
        local f = fishing()
        if not (f and ours(player) and f.aims()) then return facePlayerToAim(player, ...) end
        if player:isSitOnGround() or player:isSittingOnFurniture() then player:faceLocationF(f.aimX(), f.aimY()) end
    end
    utils.viewpointWrapped = true
end



local function triggersReel(rod)
    local f = fishing()
    return f and rod.joypad and rod.joypad >= 0 and ours(rod.player) and f.aims()
end

local function wrapReel()
    local rod = Fishing and Fishing.FishingRod
    if not rod or rod.viewpointWrapped then return end
    local isReel, isReleaseLine = rod.isReel, rod.isReleaseLine
    function rod:isReel()
        if not triggersReel(self) then return isReel(self) end
        return isJoypadRTPressed(self.joypad) and not isJoypadLTPressed(self.joypad)
    end
    function rod:isReleaseLine()
        if not triggersReel(self) then return isReleaseLine(self) end
        return isJoypadLTPressed(self.joypad)
    end
    rod.viewpointWrapped = true
end

local function pixels(size, scale)
    return math.max(1, math.floor(size * scale + 0.5))
end



local function bar(self, f)
    local scale = f.gaugeScale()
    local width, length = pixels(BAR_WIDTH, scale), pixels(BAR_LENGTH, scale)
    local x = math.floor(f.gaugeX() - self:getAbsoluteX() - width / 2 + 0.5)
    local y = math.floor(f.gaugeY() - self:getAbsoluteY() - length / 2 + 0.5)
    return x, y, width, length, scale
end


local function across(y, length, angle)
    return math.floor(y + length * (ARC_TO - angle) / (ARC_TO - ARC_FROM) + 0.5)
end

local function wrapGauge()
    local gauge = Fishing and Fishing.ISTensionUI
    if not gauge or gauge.viewpointWrapped then return end
    local prerender, render = gauge.prerender, gauge.render
    function gauge:prerender()
        local f = fishing()
        if f and self.playerIndex == 0 and not f.gaugeShown() then return end
        if not (f and self.playerIndex == 0 and f.gauge()) then return prerender(self) end
        local x, y, width, length, scale = bar(self, f)
        local edge = pixels(EDGE, scale)
        local taut, breaking = across(y, length, TAUT), across(y, length, BREAKING)
        self:drawRect(x - edge, y - edge, width + 2 * edge, length + 2 * edge, 1, 1, 1, 1)
        self:drawRect(x, taut, width, y + length - taut, 1, 0, 0, 0)
        self:drawRect(x, breaking, width, taut - breaking, 1, TAN[1], TAN[2], TAN[3])
        self:drawRect(x, y, width, breaking - y, 1, RED[1], RED[2], RED[3])
    end

    function gauge:render()
        local f = fishing()
        if f and self.playerIndex == 0 and not f.gaugeShown() then return end
        if not (f and self.playerIndex == 0 and f.gauge()) then return render(self) end
        local x, y, width, length, scale = bar(self, f)
        local thick, past = pixels(NEEDLE, scale), pixels(EDGE + NEEDLE_PAST, scale)
        local at = across(y, length, self.val) - math.floor(thick / 2)
        self:drawRect(x - past - 1, at - 1, width + 2 * past + 2, thick + 2, 1, 0, 0, 0)
        self:drawRect(x - past, at, width + 2 * past, thick, 1, NEEDLE_GREY, NEEDLE_GREY, NEEDLE_GREY)
    end
    gauge.viewpointWrapped = true
end

local function stageOf(manager)
    for name, state in pairs(manager.states) do
        if state == manager.state then return name end
    end
    return "None"
end



local traced = ""

local function trace(player, manager, stage)
    local queue = ISTimedActionQueue.getTimedActionQueue(player)
    local gauge = manager.tensionUI
    local bobber = manager.fishingRod and manager.fishingRod.bobber
    local away = bobber and math.floor(IsoUtils.DistanceTo(player:getX(), player:getY(), bobber:getX(), bobber:getY()))
    local line = string.format("stage %s, gauge %s, fishing state %s, aiming %s, FishingStage %s, FishingFinished %s,"
            .. " actions %d, rod %s, bobber %s", stage, tostring(gauge ~= nil and gauge:isVisible()),
        tostring(player:isCurrentState(FishingState.instance())), tostring(player:isAiming()),
        tostring(player:getVariableString("FishingStage")), tostring(player:getVariableBoolean("FishingFinished")),
        queue and queue.queue and #queue.queue or 0, tostring(manager.fishingRod ~= nil),
        bobber and string.format("%d squares off, on ground %s", away, tostring(bobber:isOnGround())) or "none")
    if line ~= traced then
        traced = line
        print("[Viewpoint] fishing: " .. line)
    end
end


local function feed()
    local f = fishing()
    if not f then return end
    local player = getSpecificPlayer(0)
    local managers = Fishing and Fishing.ManagerInstances
    local manager = managers and ours(player) and managers[isMultiplayer() and player:getUsername() or 0]
    if not manager or not manager.state then return f.none() end
    local stage = stageOf(manager)
    if f.traced() then trace(player, manager, stage) end
    local rod = manager.fishingRod

    local bobber = stage ~= "PickupFish" and rod and rod.bobber or nil
    local tension = bobber and rod.lineLen and rod:getTension() or 0
    local timer = rod and rod.spawnBobberDelayTimer or 0
    local gone = timer > 0 and 1 - timer / CAST_DELAY or 0
    f.update(stage, bobber ~= nil, bobber and bobber:getX() or 0, bobber and bobber:getY() or 0,
        bobber ~= nil and bobber.fish ~= nil, tension, gone, rod and rod.spawnBobberX or 0, rod and rod.spawnBobberY or 0)
end

local function wrap()
    wrapAim()
    wrapReel()
    wrapGauge()
end

Events.OnGameStart.Add(wrap)
Events.OnTick.Add(feed)
