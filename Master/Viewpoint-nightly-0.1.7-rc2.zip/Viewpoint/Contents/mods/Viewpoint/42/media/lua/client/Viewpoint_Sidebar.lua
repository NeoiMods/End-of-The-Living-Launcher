






require "ISUI/ISEquippedItem"



local PARTS = {
    { field = "mainHand", part = 0 }, { field = "offHand", part = 0 }, { field = "invBtn", part = 1 },
    { field = "healthBtn", part = 2 }, { field = "craftingBtn", part = 3 }, { field = "buildBtn", part = 4 },
    { field = "movableBtn", part = 5 }, { field = "searchBtn", part = 6 }, { field = "zoneBtn", part = 7 },
    { field = "mapBtn", part = 8 }, { field = "debugBtn", part = 9 }, { field = "arfBtn", part = 10 },
    { field = "safetyBtn" }, { field = "clientBtn" }, { field = "adminBtn" }, { field = "warManagerBtn" },
}
local HANDS, FURNITURE = 0, 5


local RIDERS = { { "movableBtn", "movableTooltip" }, { "movableBtn", "movablePopup" }, { "mapBtn", "mapPopup" },
    { "safetyBtn", "radialIcon" } }

local SPACING = 15


local NOWHERE = {
    getX = function() return -100000 end, getY = function() return -100000 end,
    getWidth = function() return 0 end, getHeight = function() return 0 end,
}

local wrapped = {}

local hiddenWhole = nil

local function off(hidden, part)
    return part ~= nil and math.floor(hidden / 2 ^ part) % 2 == 1
end


local function handTips(self, home, off)
    local tips = self.mouseOverList
    if off and tips and tips[2] and not home.tips then
        home.tips = { tips[1].object, tips[2].object }
        tips[1].object, tips[2].object = NOWHERE, NOWHERE
    elseif not off and home.tips then
        tips[1].object, tips[2].object = home.tips[1], home.tips[2]
        home.tips = nil
    end
end





local function arrange(self, hidden)
    local home = self.viewpointHome or { hid = {} }
    self.viewpointHome = home
    local y = 0
    for _, p in ipairs(PARTS) do
        local e = self[p.field]
        if e then
            home[p.field] = home[p.field] or e:getY()
            if off(hidden, p.part) then
                e:setVisible(false)
                home.hid[p.field] = true
            else
                if home.hid[p.field] then
                    e:setVisible(true)
                    home.hid[p.field] = nil
                end
                if p.part or e:isVisible() then
                    e:setY(y)
                    y = e:getBottom() + SPACING
                end
            end
        end
    end
    for _, r in ipairs(RIDERS) do
        local button, rider = self[r[1]], self[r[2]]
        if button and rider then
            home[r[2]] = home[r[2]] or rider:getY()
            rider:setY(home[r[2]] + button:getY() - home[r[1]])
        end
    end
    if off(hidden, FURNITURE) and self.movableTooltip then self.movableTooltip:setVisible(false) end
    handTips(self, home, off(hidden, HANDS))
    self:setHeight(math.max(0, y - SPACING))
end


local function restore(self)
    local home = self.viewpointHome
    for _, p in ipairs(PARTS) do
        local e = self[p.field]
        if e and home[p.field] then
            e:setY(home[p.field])
            if home.hid[p.field] then e:setVisible(true) end
        end
    end
    for _, r in ipairs(RIDERS) do
        local rider = self[r[2]]
        if rider and home[r[2]] then rider:setY(home[r[2]]) end
    end
    handTips(self, home, false)
    self.viewpointHome = nil
    self:shrinkWrap()
end


local function prerenders(prerender)
    return function(self)
        prerender(self)
        local sidebar = Viewpoint and Viewpoint.Sidebar
        if not sidebar or self.chr:getPlayerNum() ~= 0 then return end
        local hidden = sidebar.hidden()
        if hidden ~= 0 then
            arrange(self, hidden)
        elseif self.viewpointHome then
            restore(self)
        end
    end
end



local function renders(render)
    return function(self)
        local hand = self.offHand
        if not (self.viewpointHome and hand and not hand:isVisible()) then return render(self) end
        local core = getCore()
        self:setStencilRect(0, hand:getBottom() + 1, core:getScreenWidth(), core:getScreenHeight())
        render(self)
        self:clearStencilRect()
    end
end



local function wholeSidebar()
    local sidebar = Viewpoint and Viewpoint.Sidebar
    local data = sidebar and getPlayerData(0)
    local equipped = data and data.equipped
    if not equipped then return end
    local shown = sidebar.shown()
    if not shown and equipped:isVisible() then
        equipped:setVisible(false)
        for _, f in ipairs({ "movablePopup", "mapPopup", "toolRender" }) do
            if equipped[f] then equipped[f]:setVisible(false) end
        end
        equipped:doToolTip(false)
        hiddenWhole = equipped
    elseif shown and hiddenWhole then
        if hiddenWhole == equipped then equipped:setVisible(true) end
        hiddenWhole = nil
    end
end


local function wrapMethod(id, class, name, make)
    local f = class and class[name]
    if not f or f == wrapped[id] then return end
    wrapped[id] = make(f)
    class[name] = wrapped[id]
end

local function start()
    wrapMethod("prerenders", ISEquippedItem, "prerender", prerenders)
    wrapMethod("renders", ISEquippedItem, "render", renders)
end

Events.OnGameStart.Add(start)
Events.OnPreUIDraw.Add(wholeSidebar)
