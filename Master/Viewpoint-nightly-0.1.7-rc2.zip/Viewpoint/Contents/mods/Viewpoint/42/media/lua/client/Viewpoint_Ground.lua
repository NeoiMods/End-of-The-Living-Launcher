







ViewpointGround = {}



local GROUND_MENUS = { "ContextMenu_Gardening", "ContextMenu_Shovel", "ContextMenu_Rake" }

local function tagged(tag)
    return function(item) return not item:isBroken() and item:hasTag(tag) end
end



local function tools(player)
    local inv = player:getInventory()
    local function has(tag) return inv:getFirstEvalRecurse(tagged(tag)) ~= nil end
    local body = player:getBodyDamage()
    local hands = not body:getBodyPart(BodyPartType.Hand_L):HasInjury()
        and not body:getBodyPart(BodyPartType.Hand_R):HasInjury()
    local counts = ISShovelGroundCursor.GetEmptyItemCounts(player)
    return { dig = hands or ISFarmingMenu.getShovel(player) ~= nil, cut = has(ItemTag.CUT_PLANT),
             scythe = has(ItemTag.SCYTHE), dung = has(ItemTag.TAKE_DUNG), grave = has(ItemTag.DIG_GRAVE),
             stump = has(ItemTag.REMOVE_STUMP), dirt = has(ItemTag.TAKE_DIRT) and counts, }
end


local function workableObject(o, t)
    local sprite = o:getSprite()
    local props = sprite and sprite:getProperties()
    if props and props:has(IsoFlagType.canBeRemoved) then return true end
    if t.cut and props and props:has(IsoFlagType.canBeCut) then return true end
    if t.stump and o:isStump() then return true end
    if t.grave and o:getName() == "EmptyGraves" then return true end
    local attached = t.cut and o:getAttachedAnimSprite()
    for n = 1, attached and attached:size() or 0 do
        local parent = attached:get(n - 1) and attached:get(n - 1):getParentSprite()
        if parent and parent:getName() and luautils.stringStarts(parent:getName(), "f_wallvines_") then return true end
    end
    return false
end


local function workable(sq, t)
    if t.dig and ISFarmingMenu.canDigHereSquare(sq) then return true end
    if t.scythe and sq:checkHaveGrass() or t.dung and sq:checkHaveDung() then return true end
    local floor = sq:getFloor()
    if t.grave and sq:getZ() == 0 and floor and ISEmptyGraves.canDigHere({ floor }) then return true end
    if t.dirt then
        local ground = ISShovelGroundCursor.GetDirtGravelSand(sq)
        if ground and (t.dirt[ground] or 0) + t.dirt.empty > 0 then return true end
    end
    local objects = sq:getObjects()
    for i = 0, objects:size() - 1 do
        if workableObject(objects:get(i), t) then return true end
    end
    return false
end



function ViewpointGround.squares(player, reach)
    local here = player:getCurrentSquare()
    if not here or not ISFarmingMenu or not ISShovelGroundCursor or not ISEmptyGraves then return {} end
    local t, out, playerNum = tools(player), {}, player:getPlayerNum()
    local cell, z = getCell(), here:getZ()
    for y = here:getY() - reach, here:getY() + reach do
        for x = here:getX() - reach, here:getX() + reach do
            local sq = cell:getGridSquare(x, y, z)
            if sq and sq:isCouldSee(playerNum) and workable(sq, t) then
                out[#out + 1] = x
                out[#out + 1] = y
            end
        end
    end
    return out
end


local function objectsOf(sq)
    local objects, out = sq:getObjects(), {}
    for i = 0, objects:size() - 1 do
        local o = objects:get(i)
        if not instanceof(o, "IsoWorldInventoryObject") then out[#out + 1] = o end
    end
    return out
end



local function gather(context, list, state)
    local names, shovel = {}, getText("ContextMenu_Shovel")
    for _, key in ipairs(GROUND_MENUS) do names[getText(key)] = true end
    for i = 1, context.numOptions - 1 do
        local o = context.options[i]
        local sub = o and o.subOption and names[o.name] and context:getSubMenu(o.subOption)
        if sub and not sub:isEmpty() then
            local before = #list
            ViewpointInteract.collect(sub, 1, nil, list, state)
            for k = before + 1, #list do list[k].group = o.name end
        elseif o and o.onSelect == ISInventoryBuildMenu.onTakeThing then
            local before = #list
            ViewpointInteract.collect({ numOptions = 2, options = { o } }, 1, nil, list, state)
            if #list > before then list[#list].group = shovel end
        end
    end
end



function ViewpointGround.harvest(player, sq)
    local playerNum = player:getPlayerNum()
    local open, why = ViewpointInteract.menu(playerNum)
    if not open then return { why = why } end
    local worldobjects = objectsOf(sq)
    if #worldobjects == 0 then return { why = "nothing on the square" } end
    local ok, context = ViewpointInteract.build(playerNum, worldobjects, sq)
    local list, state = {}, ViewpointInteract.state(nil, worldobjects)
    state.everything = true
    if ok and type(context) == "table" then gather(context, list, state) end
    local title = getText("ContextMenu_Gardening")
    for _, a in ipairs(list) do a.name = ViewpointInteract.label(a, title) end
    open:hideAndChildren()
    if not ok then error(context) end
    if type(context) ~= "table" then return { why = "the game built no menu (" .. tostring(context) .. ")" } end
    ViewpointInteract.target = { square = sq, ground = true }
    return ViewpointInteract.finish(list, title, state.seen or 0)
end
