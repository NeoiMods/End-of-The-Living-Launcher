



ViewpointLoot = {}



function ViewpointLoot.explore(player, container)
    ISInventoryPage.checkExplored(nil, container, player)
end



local function fromGround(item, playerNum)
    if item:getWorldItem() == nil then return end
    local floor = ISInventoryPage.GetFloorContainer(playerNum)
    if not floor:contains(item) then floor:AddItem(item) end
end




local function withoutBar(queue)
    local add = ISTimedActionQueue.add
    ISTimedActionQueue.add = function(action)
        action.useProgressBar = false
        return add(action)
    end
    local ok, err = pcall(queue)
    ISTimedActionQueue.add = add
    if not ok then error(err) end
end



function ViewpointLoot.take(player, item)
    if item:isHumanCorpse() and player:getVehicle() then return end
    local playerNum = player:getPlayerNum()
    fromGround(item, playerNum)
    withoutBar(function()
        if isForceDropHeavyItem(item) then
            ISInventoryPaneContextMenu.equipHeavyItem(player, item)
        elseif luautils.walkToContainer(item:getContainer(), playerNum) then
            local into = getPlayerInventory(playerNum).inventory
            local from = item:getContainer()
            ISTimedActionQueue.add(ISInventoryTransferUtil.newInventoryTransferAction(player, item, from, into))
        end
    end)
end




function ViewpointLoot.place(player, item)
    fromGround(item, player:getPlayerNum())
    ISInventoryPaneContextMenu.onPlaceItemOnGround({ item }, player)
end


function ViewpointLoot.takeAll(player, items)
    local playerNum = player:getPlayerNum()
    local list, heavy = {}, nil
    for i = 0, items:size() - 1 do
        local item = items:get(i)
        fromGround(item, playerNum)
        if not item:isUnwanted(player) then
            if isForceDropHeavyItem(item) then heavy = item else table.insert(list, item) end
        end
    end
    withoutBar(function()
        if #list == 0 then
            if heavy then ISInventoryPaneContextMenu.equipHeavyItem(player, heavy) end
        elseif luautils.walkToContainer(list[1]:getContainer(), playerNum) then
            getPlayerLoot(playerNum).inventoryPane:transferItemsByWeight(list, getPlayerInventory(playerNum).inventory)
        end
    end)
end



function ViewpointLoot.select(player, container)
    local playerNum = player:getPlayerNum()
    local loot = getPlayerLoot(playerNum)
    if not loot then return end
    loot:refreshBackpacks()
    local wanted = container or ISInventoryPage.GetFloorContainer(playerNum)
    ViewpointInventory.focus(wanted)
    for _, button in ipairs(loot.backpacks) do
        if button.inventory == wanted then
            loot:selectContainer(button)
            break
        end
    end


    local joypadData = JoypadState.players[playerNum + 1]
    if joypadData and not ViewpointInvScreen.isUp() then
        joypadData.focus = loot
        updateJoypadFocus(joypadData)
    end
end
