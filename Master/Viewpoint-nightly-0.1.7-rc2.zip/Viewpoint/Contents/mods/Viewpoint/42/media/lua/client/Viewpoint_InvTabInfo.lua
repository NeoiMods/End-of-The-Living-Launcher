






require "Viewpoint_InvStyle"
require "Viewpoint_InvView"

ViewpointInvTabInfo = {}
local T = ViewpointInvTabInfo
T.__index = T
local S = ViewpointInvStyle
local V = ViewpointInvView

local PLAYER = 0

local TRAIT_TEXT_W = 150

local trendUp = getTexture("media/ui/chevron_up.png")
local trendUpLot = getTexture("media/ui/chevron_double.png")
local trendDown = getTexture("media/ui/chevron_down.png")


local function model()
    local info = getPlayerInfoPanel(PLAYER)
    return info and info.charScreen
end


local function traits(player)
    local list = {}
    local known = player:getCharacterTraits():getKnownTraits()
    for i = 0, known:size() - 1 do
        local trait = CharacterTraitDefinition.getCharacterTraitDefinition(known:get(i))
        if trait and trait:getTexture() then table.insert(list, trait) end
    end
    return list
end

local function traitColour(trait)
    if trait:getCost() > 0 then return S.good end
    if trait:getCost() < 0 then return S.bad end
    return S.bright
end


local function favourite(player)
    local best, swings = nil, 0
    for key, count in pairs(player:getModData()) do
        for name in string.gmatch(key, "^Fav:(.+)") do
            if count > swings then best, swings = name, count end
        end
    end
    return best
end


local function hair(player)
    local styles = getHairStylesInstance()
    local id = player:getHumanVisual():getHairModel()
    local style = player:isFemale() and styles:FindFemaleStyle(id) or styles:FindMaleStyle(id)
    local named = style and style:getName() ~= ""
    local name = named and getText("IGUI_Hair_" .. style:getName()) or getText("IGUI_Hair_Bald")
    return name, isDebugEnabled() or (style ~= nil and style:getLevel() > 0)
end

local function beard(player)
    local style = getBeardStylesInstance():FindStyle(player:getHumanVisual():getBeardModel())
    local named = style and style:getName() ~= ""
    local name = named and getText("IGUI_Beard_" .. style:getName()) or getText("IGUI_Beard_None")
    return name, isDebugEnabled() or (style ~= nil and style:getLevel() > 0)
end

function T.new()
    return setmetatable({ scroll = 0, hits = {} }, T)
end

function T:layout(area, m)
    self.area, self.m = area, m
    local tm = getTextManager()
    self.medium = tm:getFontHeight(UIFont.Medium)
    self.large = tm:getFontHeight(UIFont.Large)
    self.row = self.medium + m.pad
    self.box = { x = area.x + m.pad * 2, y = area.y + m.pad * 2, w = area.w - m.pad * 4, h = area.h - m.pad * 4 }
    self.icon = self.large + self.medium
    local change = tm:MeasureStringX(UIFont.Small, getText("IGUI_PlayerStats_Change")) + m.pad * 4
    self.change = math.max(change, m.tile)
end


function T:identity(ui, player, x, y, w)
    local m = self.m
    local descriptor = player:getDescriptor()
    local profession, icon
    local kind = descriptor and descriptor:getCharacterProfession()
    local definition = kind and CharacterProfessionDefinition.getCharacterProfessionDefinition(kind)
    if definition then profession, icon = definition:getUIName(), definition:getTexture() end
    local tx = x
    if icon then
        S.rect(ui, x, y, self.icon, self.icon, S.tile)
        S.edge(ui, x, y, self.icon, self.icon, S.panelEdge)
        S.icon(ui, icon, x + 2, y + 2, self.icon - 4)
        tx = x + self.icon + m.pad * 2
    end
    local name = descriptor:getForename() .. " " .. descriptor:getSurname()
    S.text(ui, S.fit(name, x + w - tx, UIFont.Large), tx, y, S.bright, nil, UIFont.Large)
    if profession then
        S.text(ui, S.fit(profession, x + w - tx, UIFont.Medium), tx, y + self.large, S.accent, nil, UIFont.Medium)
    end
    return self.icon
end


function T:stat(ui, x, y, w, label, value, trend)
    local m = self.m
    S.text(ui, label, x, y + math.floor((self.row - m.font) / 2), S.muted)
    S.textRight(ui, value, x + w, y + math.floor(m.pad / 2), S.bright, nil, UIFont.Medium)
    if trend then
        local vw = getTextManager():MeasureStringX(UIFont.Medium, value)
        local ty = y + math.floor((self.row - m.font) / 2)
        S.icon(ui, trend, x + w - vw - m.pad - m.font, ty, m.font, 1, 0.8, 0.8, 0.8)
    end
    S.rect(ui, x, y + self.row - 1, w, 1, S.panelEdge)
    return self.row
end

function T:stats(ui, player, x, y, w)
    local nutrition = player:getNutrition()
    local trend = nil
    if nutrition:isIncWeightLot() then
        trend = trendUpLot
    elseif nutrition:isIncWeight() then
        trend = trendUp
    elseif nutrition:isDecWeight() then
        trend = trendDown
    end
    local top = y
    y = y + self:stat(ui, x, y, w, getText("IGUI_char_Weight"), tostring(round(nutrition:getWeight(), 0)), trend)
    y = y + self:stat(ui, x, y, w, getText("IGUI_char_Zombies_Killed"), tostring(player:getZombieKills()))
    local clock = UIManager.getClock()
    if clock and clock:isDateVisible() then
        y = y + self:stat(ui, x, y, w, getText("IGUI_char_Survived_For"), player:getTimeSurvived())
    end
    local weapon = favourite(player)
    if weapon then y = y + self:stat(ui, x, y, w, getText("IGUI_char_Favourite_Weapon"), weapon) end
    return y - top
end


function T:traits(ui, player, x, y, w, view)
    local m, list = self.m, traits(player)
    if #list == 0 then return 0 end
    V.header(ui, m, x, y, w, getText("IGUI_char_Traits"))
    y = y + m.header + m.pad
    local size = self.medium + 2
    local cols = w >= (size + TRAIT_TEXT_W) * 2 + m.pad and 2 or 1
    local cw = math.floor((w - m.pad * (cols - 1)) / cols)
    for i, trait in ipairs(list) do
        local col, row = (i - 1) % cols, math.floor((i - 1) / cols)
        local cx, cy = x + col * (cw + m.pad), y + row * (size + m.gap)
        local over = V.over(view.hover, "trait", i)
        if over then S.rowHover(ui, cx, cy, cw, size) end
        S.icon(ui, trait:getTexture(), cx, cy, size)
        S.text(ui, S.fit(trait:getUIName(), cw - size - m.pad, UIFont.Medium), cx + size + m.pad, cy + 1,
            traitColour(trait), nil, UIFont.Medium)
        V.addClipped(self, self.box, cx, cy, cw, size,
            { kind = "trait", id = i, note = trait:getLabel() .. " <LINE> " .. trait:getDescription() })
    end
    return m.header + m.pad + math.ceil(#list / cols) * (size + m.gap)
end


function T:style(ui, x, y, w, label, name, id, can, view)
    local m = self.m
    S.text(ui, label, x, y + math.floor((self.row - m.font) / 2), S.muted)
    local bx = x + w - self.change
    S.textRight(ui, S.fit(name, w * 0.6), bx - m.pad * 2, y + math.floor(m.pad / 2), S.bright, nil, UIFont.Medium)
    local r = { x = bx, y = y + 2, w = self.change, h = self.row - 4 }
    local target = { kind = id, id = id, view = self, rect = r }
    if not can then target.note = getText(id == "hair" and "Tooltip_NoHair" or "Tooltip_NoBeard") end
    V.button(ui, self, r, getText("IGUI_PlayerStats_Change"), target, view.hover, not can)
    S.rect(ui, x, y + self.row - 1, w, 1, S.panelEdge)
    return self.row
end

function T:appearance(ui, player, x, y, w, view)
    local m = self.m
    local top = y
    V.header(ui, m, x, y, w, getText("IGUI_ItemCat_Appearance"))
    y = y + m.header + m.pad
    local name, can = hair(player)
    y = y + self:style(ui, x, y, w, getText("IGUI_char_HairStyle"), name, "hair", can, view)
    if not player:isFemale() then
        name, can = beard(player)
        y = y + self:style(ui, x, y, w, getText("IGUI_char_BeardStyle"), name, "beard", can, view)
    end
    y = y + m.pad
    local r = { x = x, y = y, w = w, h = self.row }
    V.button(ui, self, r, getText("IGUI_LiteratureUI_Title"), { kind = "literature", id = "literature", view = self },
        view.hover)
    return y + self.row - top
end


function T:render(ui, view)
    local m, b = self.m, self.box
    self.hits = {}
    if not m then return end
    V.panel(ui, self, self.content)
    local player = getSpecificPlayer(PLAYER)
    if not player then return end
    ui:setStencilRect(b.x, b.y, b.w, b.h)
    local y = b.y - self.scroll
    y = y + self:identity(ui, player, b.x, y, b.w) + m.pad * 2
    y = y + self:stats(ui, player, b.x, y, b.w) + m.pad * 2
    local traitsH = self:traits(ui, player, b.x, y, b.w, view)
    if traitsH > 0 then y = y + traitsH + m.pad * 2 end
    y = y + self:appearance(ui, player, b.x, y, b.w, view)
    ui:clearStencilRect()
    self.content = y + self.scroll - b.y
    V.scroll(ui, self, b, self.content)
end

function T:hit(mx, my)
    return V.hit(self, mx, my)
end

function T:wheel(mx, my, del)
    if not V.inside(self.box, mx, my) then return false end
    V.wheel(self, del * self.row * 2)
    return true
end


function T:click(h)
    local screen = model()
    if not screen or h.note then return end
    if h.kind == "literature" then
        ISCharacterScreen.onShowLiterature(screen)


        if JoypadState.players[PLAYER + 1] and screen.literatureUI then setJoypadFocus(PLAYER, screen.literatureUI) end
        return
    end
    local r = h.rect
    local anchor = {
        getAbsoluteX = function() return r.x end,
        getAbsoluteY = function() return r.y end,
        getHeight = function() return r.h end,
    }
    if h.kind == "hair" then ISCharacterScreen.hairMenu(screen, anchor) end
    if h.kind == "beard" then ISCharacterScreen.beardMenu(screen, anchor) end
end
