





require "ISUI/ISUI3DModel"
require "Viewpoint_InvStyle"
require "Viewpoint_InvData"

ViewpointInvGear = {}
local Gear = ViewpointInvGear
Gear.__index = Gear
local S = ViewpointInvStyle

local TITLE = "Equipment"

local ROW = 6


local SLOTS = {
    { id = "head", key = "UI_ClothingType_Hat", names = { "Hat", "FullHat", "FullSuitHead", "FullSuitHeadSCBA" } },
    { id = "face", key = "UI_ClothingType_Mask", names = { "Mask", "MaskEyes", "MaskFull", "Eyes", "LeftEye", "RightEye",
        "Nose", "Ears", "EarTop" } },
    { id = "neck", key = "UI_ClothingType_Neck", names = { "Neck", "Necklace", "Necklace_Long", "Scarf", "Gorget" } },
    { id = "jacket", key = "UI_ClothingType_Jacket", names = { "Jacket", "Jacket_Down", "Jacket_Bulky", "JacketHat",
        "JacketHat_Bulky", "JacketSuit", "FullSuit", "Boilersuit", "BathRobe", "FullRobe", "FullTop", "Sweater",
        "SweaterHat", "Jersey", "TorsoExtra", "TorsoExtraVest", "TorsoExtraVestBullet", "Cuirass", "SCBA",
        "SCBAnotank", "BodyCostume" } },
    { id = "shirt", key = "UI_ClothingType_Shirt", names = { "Shirt", "ShortSleeveShirt", "Tshirt", "TankTop", "Torso1",
        "Torso1Legs1", "Dress", "LongDress", "UnderwearTop" } },
    { id = "hands", key = "UI_ClothingType_Hands", names = { "Hands", "HandsLeft", "HandsRight", "LeftWrist",
        "RightWrist", "Right_MiddleFinger", "Left_MiddleFinger", "Left_RingFinger", "Right_RingFinger", "RightArm",
        "LeftArm", "ForeArm_Left", "ForeArm_Right", "Elbow_Left", "Elbow_Right" } },
    { id = "back", key = "UI_ClothingType_Back", names = { "Back", "Satchel" } },
    { id = "belt", key = "UI_ClothingType_Belt", names = { "Belt", "BeltExtra", "FannyPackFront", "FannyPackBack",
        "Webbing", "AmmoStrap", "ShoulderHolster", "AnkleHolster" } },
    { id = "legs", key = "UI_ClothingType_Pants", names = { "Pants", "Pants_Skinny", "PantsExtra", "ShortPants",
        "ShortsShort", "Skirt", "LongSkirt", "Legs1", "Legs5", "UnderwearBottom", "Underwear", "UnderwearExtra1",
        "UnderwearExtra2", "Codpiece" } },
    { id = "feet", key = "UI_ClothingType_Shoes", names = { "Shoes", "Socks", "Gaiter_Right", "Gaiter_Left" } },
    { id = "pads", label = "Pads", names = { "Knee_Left", "Knee_Right", "Calf_Left", "Calf_Right", "Thigh_Left",
        "Thigh_Right", "ShoulderpadRight", "ShoulderpadLeft", "SportShoulderpad", "SportShoulderpadOnTop" } },
    { id = "other", label = "Other", names = {} },
}


local HIDDEN = { bandage = true, wound = true, zeddmg = true, bellybutton = true }

local slotOf = {}
for _, slot in ipairs(SLOTS) do
    slot.label = slot.label or getText(slot.key)
    for _, n in ipairs(slot.names) do slotOf[string.lower(n)] = slot end
end


ViewpointInvAvatar = ISUI3DModel:derive("ViewpointInvAvatar")

function ViewpointInvAvatar:new(x, y, w, h)
    return ISUI3DModel.new(self, x, y, w, h)
end

function ViewpointInvAvatar:bind(player)
    self:setState("idle")
    self:setDirection(IsoDirections.S)
    self:setIsometric(false)
    self:setCharacter(player)
end

function Gear.new()
    return setmetatable({ worn = {}, hits = {}, x = 0, y = 0, w = 0, h = 0 }, Gear)
end


function Gear:refresh(player)
    local worn = {}
    local items = player:getWornItems()
    for i = 0, items:size() - 1 do
        local entry = items:get(i)
        local name = string.lower(entry:getLocation():getTranslationName())
        if not HIDDEN[name] and not string.find(name, "^makeup") and not string.find(name, "_texture$") then
            local slot = slotOf[name] or SLOTS[#SLOTS]
            worn[slot.id] = worn[slot.id] or {}
            table.insert(worn[slot.id], entry:getItem())
        end
    end
    self.worn = worn
end



function Gear:layout(x, y, w, m)
    self.x, self.y, self.w, self.m = x, y, w, m
    local rows = math.ceil(#SLOTS / ROW)
    local inner = w - m.pad * 2 - m.gap * (ROW - 1)
    local size = math.min(math.floor(inner / ROW), math.floor(m.tile * 1.2))
    self.size = size
    local x0, y0 = x + m.pad, y + m.title + m.pad
    self.places = {}
    for i, slot in ipairs(SLOTS) do
        local col, row = (i - 1) % ROW, math.floor((i - 1) / ROW)

        local left = x0 + math.floor(inner * col / ROW) + col * m.gap
        local right = x0 + math.floor(inner * (col + 1) / ROW) + col * m.gap
        self.places[i] = { slot = slot, x = left, y = y0 + row * (size + m.gap), w = right - left }
    end
    self.h = m.title + m.pad * 2 + rows * size + (rows - 1) * m.gap
    return self.h
end



local function slotBox(ui, m, x, y, w, h, item, label, more, hover, drop)
    S.slotBox(ui, x, y, w, h, hover, drop and (drop.ok and S.drop or S.refuse), false, not item)
    local inset = m.inset
    local damage = item and S.damage(ViewpointInvData.condition(item), item:isBroken())
    if damage then S.rect(ui, x + inset, y + inset, w - inset * 2, h - inset * 2, damage) end
    if not item then
        local cx, cy = x + math.floor(w / 2), y + math.floor((h - m.font) / 2)
        S.textCentre(ui, S.fit(label, w - inset * 2), cx, cy, S.dim)
        return
    end
    local icon = math.floor(h * 0.68)
    ui.javaObject:DrawItemIcon(item, x + math.floor((w - icon) / 2), y + math.floor((h - icon) / 2), 1.0, icon, icon)
    if more > 0 then
        S.textRight(ui, "+" .. more, x + w - inset - 1, y + inset, S.modern and S.accent or S.bright)
    end
end

function Gear:render(ui, view)
    local m = self.m
    self.hits = { { x = self.x, y = self.y, w = self.w, h = self.h, target = { kind = "equipment" } } }
    S.window(ui, m, self.x, self.y, self.w, self.h, TITLE)
    local hover, drag = view.hover, view.drag
    for _, place in ipairs(self.places) do
        local items = self.worn[place.slot.id]
        local top = items and items[#items]
        local over = hover and hover.kind == "slot" and hover.slot == place.slot
        local drop = drag and over and { ok = drag.wearable }
        slotBox(ui, m, place.x, place.y, place.w, self.size, top, place.slot.label, items and #items - 1 or 0, over,
            drop)
        table.insert(self.hits, { x = place.x, y = place.y, w = place.w, h = self.size,
            target = { kind = "slot", slot = place.slot, items = items or {}, item = top } })
    end
end

function Gear:hit(mx, my)
    for i = #self.hits, 1, -1 do
        local h = self.hits[i]
        if mx >= h.x and mx < h.x + h.w and my >= h.y and my < h.y + h.h then return h.target end
    end
    return nil
end
