












require "Viewpoint_InvScreen"
require "Viewpoint_InvActions"

local Screen = ViewpointInvScreen
local A = ViewpointInvActions
local D = ViewpointInvData

local PLAYER = 0



local DRAG_PX, DRAG_FONT, DOUBLE_MS = 4, 0.25, 350

local function inside(r, mx, my)
    return r and mx >= r.x and mx < r.x + r.w and my >= r.y and my < r.y + r.h
end


function Screen:hit(mx, my)
    if inside(self.closeRect, mx, my) then return { kind = "close" } end
    local h = self.details and self.details:hit(mx, my)
    if h then return h end
    h = self.tabs:hit(mx, my) or self.bar:hit(mx, my) or self.gear:hit(mx, my) or self.nearby:hit(mx, my)
        or self.inventory:hit(mx, my)
    if h then return h end
    if self.tabs:isCharacter() then
        h = self.hands:hit(mx, my)
        if h then return h end
        if inside(self.avatarRect, mx, my) then return { kind = "avatar" } end
    end
    h = ViewpointInvBar.hotbarAt(self, mx, my)
    if h then return h end
    if inside(self.centre, mx, my) then return { kind = "centre" } end
    return { kind = "backdrop" }
end


local function copySelection(selection)
    local copy = {}
    for container, chosen in pairs(selection) do
        local keys = {}
        for key in pairs(chosen) do keys[key] = true end
        copy[container] = keys
    end
    return copy
end


local function selectedStacks(self, s)
    local grid = self.inventory
    for _, other in ipairs(self.nearby.sections) do
        if other == s then grid = self.nearby end
    end
    local list = {}
    for _, section in ipairs(grid.sections) do
        local chosen = self.selected[section.container]
        if chosen then
            for _, stack in ipairs(section.stacks) do
                if chosen[stack.key] then table.insert(list, stack) end
            end
        end
    end
    return list
end


function Screen:itemsOf(h)
    if h.kind == "tile" then
        local chosen = self.selected[h.section.container]
        if chosen and chosen[h.stack.key] then return D.items(selectedStacks(self, h.section)) end
        return D.items({ h.stack })
    end
    if (h.kind == "slot" or h.kind == "hand" or h.kind == "hotbar") and h.item then return { h.item } end
    return nil
end

local function weightOf(items)
    local weight = 0
    for _, item in ipairs(items) do weight = weight + item:getUnequippedWeight() end
    return weight
end

local function anyWearable(items)
    for _, item in ipairs(items) do
        if A.wearable(item) then return true end
    end
    return false
end



local function fits(d, s)
    if s.locked then return false end
    local _, n = A.fitting(d.items, s.container)
    return n > 0
end


function Screen:judge(h)
    local d = self.drag
    if h.section and d.fits[h.section] == nil then d.fits[h.section] = fits(d, h.section) end
    if h.kind == "hotbar" and d.attaches[h.index] == nil then
        d.attaches[h.index] = A.attachable(d.items, h.index) ~= nil
    end
end


function Screen:onMouseDown(x, y)
    if not self.up then return true end
    for _, box in ipairs(self.searches) do
        if box:isFocused() then box:unfocus() end
    end
    self:setCapture(true)
    if self.split then
        if self.split:press(x, y) then self.split = nil end
        return true
    end
    local h = self:hit(x, y)
    self.press = { x = x, y = y, target = h, items = self:itemsOf(h), shift = isShiftKeyDown() }
    if h.kind == "column" and inside(h.grid.body, x, y) then
        self.press.base = isShiftKeyDown() and copySelection(self.selected) or {}
    end
    return true
end



function Screen:selectBox(p, mx, my)
    local grid = p.target.grid
    local body = grid.body
    local x0, y0 = math.max(body.x, math.min(p.x, mx)), math.max(body.y, math.min(p.y, my))
    local x1, y1 = math.min(body.x + body.w, math.max(p.x, mx)), math.min(body.y + body.h, math.max(p.y, my))
    p.box = { x = x0, y = y0, w = math.max(0, x1 - x0), h = math.max(0, y1 - y0) }
    local selected = copySelection(p.base)
    for _, t in ipairs(grid:tilesIn(p.box)) do
        local chosen = selected[t.section.container] or {}
        selected[t.section.container] = chosen
        chosen[t.stack.key] = true
    end
    self.selected = selected
end



function Screen:onMouseMove(dx, dy)
    local mx, my = self:getMouseX(), self:getMouseY()
    if self.split then
        if self.split.sliding then self.split:slide(mx) end
        return
    end
    local p = self.press
    if not p or self.drag then return end
    local slop = math.max(DRAG_PX, math.floor(self.m.font * DRAG_FONT))
    local far = math.abs(mx - p.x) > slop or math.abs(my - p.y) > slop
    if p.base then
        if far or p.box then self:selectBox(p, mx, my) end
        return
    end
    if not p.items then return end
    if far then
        local split = p.shift and p.target.kind == "tile" and p.target.stack.count > 1
        local items = split and D.items({ p.target.stack }) or p.items
        self.drag = { items = items, weight = weightOf(items), fits = {}, attaches = {},
            wearable = anyWearable(items), split = split }
    end
end

Screen.onMouseMoveOutside = Screen.onMouseMove

function Screen:onMouseUp(x, y)
    self:setCapture(false)
    if self.split then
        self.split.sliding = false
        return true
    end
    local p, d = self.press, self.drag
    self.press, self.drag = nil, nil
    if d then
        self:drop(d, self:hit(x, y), x, y)
    elseif p and not p.box then
        self:click(p.target)
    end
    return true
end

Screen.onMouseUpOutside = Screen.onMouseUp



function Screen:askAmount(d, h, x, y)
    local items, most, move = d.items, #d.items, A.drop
    local dest
    if h.section then
        if h.section.locked then return true end
        dest = h.section.container
        if not h.section.mine then self.across = dest end
    elseif h.kind == "column" then
        local s = h.grid.mine and { container = self.player:getInventory() } or h.grid:floor()
        if not s then return true end
        dest = s.container
    elseif h.kind ~= "backdrop" then
        return false
    end
    if dest then
        items, most = A.fitting(d.items, dest)
        move = function(list) A.move(list, dest) end
    end
    if most == 1 then move({ items[1] }) end
    if most > 1 then self.split = ViewpointInvSplit.new(items, most, move, x, y, self.m, self.width, self.height) end
    return true
end


function Screen:drop(d, h, x, y)
    local player = self.player
    if d.split and self:askAmount(d, h, x, y) then return end
    if h.section then
        if d.fits[h.section] == nil then d.fits[h.section] = fits(d, h.section) end
        if d.fits[h.section] then A.move(d.items, h.section.container) end
        if not h.section.mine then self.across = h.section.container end
    elseif h.kind == "column" then
        local s = h.grid.mine and { container = player:getInventory() } or h.grid:floor()
        if s then A.move(d.items, s.container) end
    elseif h.kind == "slot" or h.kind == "avatar" or h.kind == "equipment" then
        for _, item in ipairs(d.items) do
            if A.wearable(item) and not player:isEquippedClothing(item) then return A.wear(item) end
        end
    elseif h.kind == "hand" then
        A.hold(d.items[1], h.primary)
    elseif h.kind == "hotbar" then
        A.attach(d.items, h.index)
    elseif h.kind == "part" then
        self.tabs:apply(h.part, d.items)
    elseif h.kind == "backdrop" then
        A.drop(d.items)
    end
end


local function identity(h)
    if h.kind == "tile" then return h.stack.item end
    if h.kind == "slot" then return h.slot end
    if h.kind == "hand" then return h.primary and "primary" or "secondary" end
    if h.kind == "hotbar" then return "hotbar" .. h.index end
    return nil
end

local function choose(self, s, stack, add)
    if not add then self.selected = {} end
    local chosen = self.selected[s.container] or {}
    self.selected[s.container] = chosen
    if add and chosen[stack.key] then chosen[stack.key] = nil else chosen[stack.key] = true end
end



function Screen:send(h)
    local items = self:itemsOf(h)
    if not h.section.mine then
        self.across = h.section.container
        A.take(items, self.into)
    elseif self.across then
        A.move(items, self.across)
    end
end

function Screen:clickTile(h, double)
    local s, stack = h.section, h.stack
    if not s.mine then self.across = s.container end
    if isCtrlKeyDown() then
        self:send(h)
    elseif isAltKeyDown() then
        A.equip(stack.item)
    elseif isShiftKeyDown() then
        choose(self, s, stack, true)
    else
        choose(self, s, stack, false)
        if double and s.mine then A.use(stack.item) end
        if double and not s.mine then A.take(self:itemsOf(h), self.into) end
    end
end

function Screen:click(h)
    local now, id = getTimestampMs(), identity(h)
    local last = self.lastClick
    local double = id ~= nil and last ~= nil and last.id == id and now - last.at < DOUBLE_MS
    self.lastClick = (not double) and { id = id, at = now } or nil
    local kind = h.kind
    if kind == "tile" then
        self:clickTile(h, double)
    elseif kind == "header" then
        h.section.folded = not h.section.folded
        if not h.section.mine then self.across = h.section.container end
    elseif kind == "takeAll" then
        A.takeAll(h.section.container, h.stacks and D.items(h.stacks), self.into)
    elseif kind == "order" then
        h.grid:nextOrder()
    elseif kind == "tab" then
        self:selectTab(h.id)
    elseif kind == "detailsClose" then
        self:closeDetails()
    elseif kind == "close" then
        ViewpointInventory.close()
    elseif (kind == "slot" or kind == "hand") and h.item and (double or isAltKeyDown()) then
        A.unequip(h.item)
    elseif kind == "hotbar" then
        local hotbar = getPlayerHotbar(PLAYER)
        if hotbar and hotbar:isAllowedToActivateSlot() then hotbar:activateSlot(h.index) end
    elseif kind == "backdrop" or kind == "column" then
        self.selected = {}
    elseif h.view then
        h.view:click(h)
    end
end

function Screen:onRightMouseDown(x, y)
    return true
end


function Screen:itemMenu(items, x, y)
    local menu = A.menu(items, self:getAbsoluteX() + x, self:getAbsoluteY() + y)
    if menu then menu:addOptionOnTop(getText("UI_Details"), self, Screen.inspect, items[1]) end
    return menu
end

function Screen:onRightMouseUp(x, y)
    if not self.up or self.drag then return true end
    if self.split then
        self.split = nil
        return true
    end
    local h = self:hit(x, y)
    self:tooltip(nil)
    local ax, ay = self:getAbsoluteX() + x, self:getAbsoluteY() + y
    if h.kind == "tile" or ((h.kind == "slot" or h.kind == "hand") and h.item) then
        self:itemMenu(self:itemsOf(h), x, y)
    elseif h.kind == "hotbar" then
        local hotbar = getPlayerHotbar(PLAYER)
        if hotbar then hotbar:doMenu(h.index) end
    elseif h.kind == "part" then
        self.tabs:menu(h.part, ax, ay)
    end
    return true
end

function Screen:onMouseWheel(del)
    local mx, my = self:getMouseX(), self:getMouseY()
    if self.split then
        self.split:wheel(del)
    elseif self.tabs:wheel(mx, my, del) then
        return true
    elseif self.nearby:contains(mx, my) then
        self.nearby:wheel(del)
    elseif self.inventory:contains(mx, my) then
        self.inventory:wheel(del)
    end
    return true
end

local function isEscape(key)
    return key == Keyboard.KEY_ESCAPE or getCore():isKey(KeybindId.MAIN_MENU, key)
end

local function isEnter(key)
    return key == Keyboard.KEY_RETURN or key == Keyboard.KEY_NUMPADENTER
end


function Screen:isKeyConsumed(key)
    return isEscape(key) or (self.split ~= nil and isEnter(key))
end


function Screen:onKeyRelease(key)
    if not self.up then return end
    if self.split then
        if isEnter(key) then self.split:confirm() end
        if isEnter(key) or isEscape(key) then self.split = nil end
    elseif isEscape(key) and self.details then
        self:closeDetails()
    elseif isEscape(key) then
        ViewpointInventory.close()
    end
end
