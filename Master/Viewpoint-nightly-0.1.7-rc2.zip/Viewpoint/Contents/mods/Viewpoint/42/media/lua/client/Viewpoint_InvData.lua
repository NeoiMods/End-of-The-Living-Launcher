





ViewpointInvData = {}
local D = ViewpointInvData

local PLAYER = 0



local function name(item, player)
    local itemName = item:getName(player)
    local herbal = item:IsFood() and item:getHerbalistType()
    if not herbal or herbal == "" then return itemName end
    local poison = item:getPoisonPower() > 0
    if player:isRecipeActuallyKnown("Herbalist") then
        if herbal == "Berry" then itemName = poison and getText("IGUI_PoisonousBerry") or getText("IGUI_Berry") end
        if herbal == "Mushroom" then itemName = poison and getText("IGUI_PoisonousMushroom") or getText("IGUI_Mushroom") end
    else
        if herbal == "Berry" then itemName = getText("IGUI_UnknownBerry") end
        if herbal == "Mushroom" then itemName = getText("IGUI_UnknownMushroom") end
    end
    if itemName ~= item:getDisplayName() then item:setName(itemName) end
    return item:getName(player)
end


local function hotbarSlots()
    local slots = {}
    local hotbar = getPlayerHotbar(PLAYER)
    if hotbar and hotbar.attachedItems then
        for slot, item in pairs(hotbar.attachedItems) do slots[item] = slot end
    end
    return slots
end



local function carried(player, shown)
    local skip = {}
    local worn = player:getWornItems()
    for i = 0, worn:size() - 1 do skip[worn:get(i):getItem()] = true end
    if player:getPrimaryHandItem() then skip[player:getPrimaryHandItem()] = true end
    if player:getSecondaryHandItem() then skip[player:getSecondaryHandItem()] = true end
    local items = player:getInventory():getItems()
    for i = 0, items:size() - 1 do
        local item = items:get(i)
        if item:IsInventoryContainer() and shown[item:getInventory()] then skip[item] = true end
    end
    return skip
end



local categories = {}

function D.category(item)
    local cat = tostring(item:getDisplayCategory() or item:getCategory())
    if not categories[cat] then categories[cat] = getTextOrNull("IGUI_ItemCat_" .. cat) or cat end
    return categories[cat]
end





D.TYPES = {
    { "Weapon", "WeaponCrafted", "WeaponImprovised", "WeaponPart", "Explosives", "BrokenWeapon", "SportsWeapon",
        "InstrumentWeapon" },
    { "Ammo" },
    { "Clothing", "ProtectiveGear", "Accessory", "Bag", "Container", "Memento" },
    { "FirstAid", "FirstAidWeapon", "Bandage", "Wound" },
    { "Food", "Water", "WaterContainer", "Cooking", "CookingWeapon" },
    { "Tool", "ToolWeapon", "Gardening", "GardeningWeapon", "Fishing", "FishingWeapon", "Trapping", "Camping",
        "VehicleMaintenance", "VehicleMaintenanceWeapon", "LightSource", "FireSource", "Electronics", "Communications",
        "Security", "Household", "HouseholdWeapon", "Paint" },
    { "Material", "MaterialWeapon", "Junk", "JunkWeapon", "AnimalPart", "AnimalPartWeapon" },
    { "Literature", "SkillBook", "RecipeResource", "Cartography" },
}
local typeOf, typed = {}, {}
for i, cats in ipairs(D.TYPES) do
    for _, cat in ipairs(cats) do typeOf[cat] = i end
end


function D.type(item)
    local cat = item:getDisplayCategory()
    if not cat then return nil end
    cat = tostring(cat)
    local t = typed[cat]
    if t == nil then
        t = typeOf[cat] or (string.find(cat, "Weapon$") and 1) or false
        typed[cat] = t
    end
    return t or nil
end

local function byLabel(a, b)
    if a.name ~= b.name then return a.name < b.name end
    return a.key < b.key
end

local function byName(a, b)
    if (a.slot ~= nil) ~= (b.slot ~= nil) then return a.slot ~= nil end
    return byLabel(a, b)
end

local function byCategory(a, b)
    if a.cat ~= b.cat then return a.cat < b.cat end
    return byLabel(a, b)
end

local function byWeight(a, b)
    if a.weight ~= b.weight then return a.weight > b.weight end
    return byLabel(a, b)
end



D.ORDERS = {
    { label = getText("IGUI_invpanel_Type"), less = byName },
    { label = getText("IGUI_invpanel_Category"), less = byCategory },
    { label = getText("IGUI_invpanel_weight"), less = byWeight },
}




function D.stacks(container, player, skip, slots)
    local list, index = {}, {}
    local items = container:getItems()
    for i = 0, items:size() - 1 do
        local item = items:get(i)
        if not item:isHidden() and not (skip and skip[item]) then
            local itemName = name(item, player)
            local slot = slots and slots[item]
            local key = slot and ("hotbar:" .. itemName) or itemName
            local stack = index[key]
            if not stack then
                local cat = D.category(item)
                stack = { key = key, name = itemName, cat = cat, find = string.lower(itemName .. "\n" .. cat), items = {},
                    item = item, count = 0, weight = 0, slot = slot, look = D.look(item),
                    unwanted = item:isUnwanted(player) }
                index[key] = stack
                table.insert(list, stack)
            end
            table.insert(stack.items, item)
            stack.count = stack.count + 1
            stack.weight = stack.weight + item:getUnequippedWeight()
        end
    end
    return list
end



function D.shown(s, query, order)
    local v = s.shown
    if v and v.stacks == s.stacks and v.query == query and v.order == order then return v.list end
    local list = {}
    for _, stack in ipairs(s.stacks) do
        if query == "" or string.find(stack.find, query, 1, true) then table.insert(list, stack) end
    end
    table.sort(list, order.less)
    s.shown = { stacks = s.stacks, query = query, order = order, list = list }
    return list
end


local function section(button, player, mine)
    local container = button.inventory
    return {
        container = container,
        title = button.name or "",
        icon = button.image,
        tint = button.textureColor,
        lock = button.textureOverride,
        locked = container:isLockedToCharacter(player),
        floor = container:getType() == "floor",
        main = container == player:getInventory(),
        mine = mine,
        stacks = {},
        count = -1,
        weight = -1,
    }
end




function D.sections(page, player, mine, held, focus)
    local list, kept = {}, {}
    for _, s in ipairs(held or {}) do kept[s.container] = s end
    for _, button in ipairs(page and page.backpacks or {}) do
        if button.inventory then
            local s = kept[button.inventory] or section(button, player, mine)
            s.title, s.icon, s.lock = button.name or s.title, button.image, button.textureOverride
            s.locked = s.container:isLockedToCharacter(player)
            if s.container == focus then table.insert(list, 1, s) else table.insert(list, s) end
        end
    end
    return list
end


function D.same(page, sections, focus)
    local buttons = page and page.backpacks or {}
    if #buttons ~= #sections then return false end
    local shown = {}
    for _, s in ipairs(sections) do shown[s.container] = true end
    for _, button in ipairs(buttons) do
        if not shown[button.inventory] then return false end
    end
    return focus == nil or not shown[focus] or sections[1].container == focus
end



function D.restack(sections, player, every)
    local shown = {}
    for _, s in ipairs(sections) do shown[s.container] = true end
    local slots, skip
    for _, s in ipairs(sections) do
        local items = s.container:getItems()
        local count, weight = items:size(), s.container:getContentsWeight()
        if every or count ~= s.count or math.abs(weight - s.weight) > 0.001 then
            s.count, s.weight = count, weight
            if s.locked then
                s.stacks = {}
            else
                slots = slots or hotbarSlots()
                if s.main then skip = skip or carried(player, shown) end
                s.stacks = D.stacks(s.container, player, s.main and skip or nil, s.mine and slots or nil)
            end
        end
    end
end


function D.load(s, player)
    if s.main then return player:getInventoryWeight(), player:getMaxWeight() end
    if s.floor then return s.container:getCapacityWeight(), 0 end
    return s.container:getCapacityWeight(), s.container:getEffectiveCapacity(player)
end


function D.condition(item)
    local most = item:getConditionMax()
    if most <= 0 then return nil end
    local now = item:getCondition()
    if instanceof(item, "HandWeapon") or instanceof(item, "Clothing") or now < most then return now / most end
    return nil
end


function D.amount(item)
    if item:IsDrainable() then return item:getCurrentUsesFloat() end
    local fluid = item:getFluidContainer()
    if fluid then return fluid:getFilledRatio() end
    return nil
end



function D.look(item)
    return { type = D.type(item), condition = D.condition(item), broken = item:isBroken(), amount = D.amount(item),
        favourite = item:isFavorite() }
end


function D.items(stacks)
    local list, seen = {}, {}
    for _, stack in ipairs(stacks) do
        for _, item in ipairs(stack.items) do
            if not seen[item] then
                seen[item] = true
                table.insert(list, item)
            end
        end
    end
    return list
end
