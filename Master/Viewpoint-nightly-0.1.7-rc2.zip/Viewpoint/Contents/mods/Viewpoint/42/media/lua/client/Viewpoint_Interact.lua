












require "Viewpoint_InteractOrder"

ViewpointInteract = { actions = {} }

local W = ISWorldObjectContextMenu



local function skipped()
    local set = {}
    for _, f in ipairs({ W.onWalkTo, W.onSitOnGround, W.onGrabWItem, W.onGrabHalfWItems, W.onGrabAllWItems,
                         W.onGrabCorpseItem, ISDisassembleMenu and ISDisassembleMenu.disassemble }) do
        if f then set[f] = true end
    end


    for _, t in ipairs({ DebugContextMenu, ISVehicleMenu }) do
        for _, f in pairs(t or {}) do
            if type(f) == "function" then set[f] = true end
        end
    end
    return set
end


local function handler(option)
    if option.onSelect == ISContextMenu.onGetUpAndThen then return option.param1 end
    return option.onSelect
end


local function curtain(object)
    if instanceof(object, "IsoWindow") or instanceof(object, "IsoDoor") or instanceof(object, "IsoThumpable") then
        return object:HasCurtains()
    end
    return nil
end



local function destroyable(player, object)
    if not (player and ISDestroyCursor) or instanceof(object, "IsoMovingObject") or not object:getSprite() then
        return false
    end
    return ISDestroyCursor:new(player, false, nil):canDestroy(object) == true
end






local function own(object, player)
    local set = {}
    local barricadable = instanceof(object, "IsoDoor") or instanceof(object, "IsoWindow")
        or instanceof(object, "IsoWindowFrame") or instanceof(object, "IsoThumpable")
    if barricadable and W.onBarricade then set[W.onBarricade] = true end
    if W.onDestroy and destroyable(player, object) then set[W.onDestroy] = true end
    return set
end


local function another(v, state)
    return v ~= nil and v ~= state.object and v ~= state.curtain and instanceof(v, "IsoObject")
        and not instanceof(v, "IsoGameCharacter")
end



local function isTarget(v, state)
    return v ~= nil and (v == state.object or v == state.curtain or v == state.plant)
end






local function whose(args, menu, state)
    if state.everything then return true end
    local other = false
    for i = 1, args.n do
        local v = args[i]
        if isTarget(v, state) then return true end
        if type(v) == "table" and v ~= state.worldobjects and v ~= menu then
            for _, w in pairs(v) do
                if isTarget(w, state) then return true end
                other = other or another(w, state)
            end
        else
            other = other or another(v, state)
        end
    end
    if other then return false end
    return nil
end



local function lockedOut(o, state)
    local door = state.object
    return o.notAvailable and handler(o) == W.onOpenCloseDoor
        and (instanceof(door, "IsoDoor") or instanceof(door, "IsoThumpable"))
        and not door:isBarricaded() and (door:isLocked() or door:isLockedByKey())
end



local function keepOwned(out, before)
    for i = before + 1, #out do
        if out[i].mine then return end
    end
    for i = #out, before + 1, -1 do table.remove(out, i) end
end






local function collect(menu, depth, prefix, out, state)
    for i = 1, menu.numOptions - 1 do
        local o = menu.options[i]
        state.seen = (state.seen or 0) + 1
        if o and not o.isDefaultOption and not (state.debugIcon and o.iconTexture == state.debugIcon) then
            local name = prefix and (prefix .. ": " .. o.name) or o.name
            local args = { o.target, o.param1, o.param2, o.param3, o.param4, o.param5, o.param6, o.param7, o.param8,
                           o.param9, o.param10, n = 11 }
            if o.subOption then
                local sub = menu:getSubMenu(o.subOption)
                if sub and not sub:isEmpty() then
                    local before = #out
                    collect(sub, depth + 1, depth >= 1 and name or nil, out, state)
                    if depth == 0 then
                        keepOwned(out, before)
                        for k = before + 1, #out do out[k].group = o.name end
                        if #out > before and not state.title then state.title = o.name end
                    end
                end
            elseif o.onSelect and not state.skip[handler(o)] then
                local mine = state.own[handler(o)] or whose(args, menu, state)
                if mine or mine == nil and depth > 0 then
                    if lockedOut(o, state) then name = name .. " [" .. state.lockedWord .. "]" end
                    table.insert(out, {
                        name = name,
                        fn = o.onSelect,
                        args = args,
                        n = args.n,
                        enabled = not o.notAvailable and not o.isDisabled,
                        first = state.first[handler(o)] == true,
                        rank = state.rank[handler(o)],
                        mine = mine,
                        menu = true,
                        tip = o.toolTip,
                    })
                end
            end
        end
    end
end




local function label(a, title)
    if not a.group or a.group == title then return a.name end
    if a.name == title then return a.group end
    return a.group .. ": " .. a.name
end





local function lightToggle(list, player, object)
    if not instanceof(object, "IsoLightSwitch") then return end
    for _, a in ipairs(list) do
        if a.fn == W.onToggleLight or a.args and a.args[2] == W.onToggleLight then return end
    end
    local name = getText(object:isActivated() and "ContextMenu_Turn_Off" or "ContextMenu_Turn_On")
    table.insert(list, 1, { name = name, fn = W.onToggleLight, args = { nil, object, player:getPlayerNum() }, n = 3,
                            enabled = true, first = true })
end



local function chopTree(worldobjects, playerObj, tree)
    W.doChopTree(playerObj, tree)
end




local function withoutChopCursor(list)
    for _, a in ipairs(list) do
        if a.fn == ISContextMenu.onGetUpAndThen and a.args[2] == W.onChopTree then
            a.args[2] = chopTree
        elseif a.fn == W.onChopTree then
            a.fn = chopTree
        end
    end
end


local CORNER = { west = 0, north = 1 }




local function destroy(object, side, player, sledgehammer)
    local sq = object:getSquare()
    if not sq then return end
    local cursor = ISDestroyCursor:new(player, false, sledgehammer)
    cursor.renderX, cursor.renderY, cursor.renderZ = sq:getX(), sq:getY(), sq:getZ()
    if not cursor:isValid(sq) then return end
    local objects = cursor:getObjectList()
    for i, o in ipairs(objects) do
        if o == object then cursor.objectIndex = i end
    end
    if objects[cursor.objectIndex] ~= object then return end
    if object:hasProperty("CornerNorthWall") then
        if side == "north" and not cursor:canDestroyWall_North(object)
                or side == "west" and not cursor:canDestroyWall_West(object) then
            return
        end
        cursor.cornerCounter = CORNER[side] or cursor.cornerCounter
        cursor:checkNorthWestCorner(object)
    end
    cursor:tryBuild(sq:getX(), sq:getY(), sq:getZ())
end




local function withoutDestroyCursor(list, object)
    for _, a in ipairs(list) do
        local standing = a.fn == ISContextMenu.onGetUpAndThen and a.args[2] == W.onDestroy
        if standing or a.fn == W.onDestroy then
            local knock = function(worldobjects, player, sledgehammer) destroy(object, a.side, player, sledgehammer) end
            if standing then a.args[2] = knock else a.fn = knock end
            a.deliberate = true
        end
    end
end


local function addWords(words, text, x, y, r, g, b, font)
    text = string.trim(text):gsub("&lt;", "<"):gsub("&gt;", ">")
    if text ~= "" then table.insert(words, { text = text, x = x, y = y, r = r, g = g, b = b, font = font }) end
end


local function lineLength(panel, c, font)
    local width = 0
    for k = c, #panel.lines do
        if panel.lineY[k] ~= panel.lineY[c] then break end
        width = width + getTextManager():MeasureStringX(panel.fonts[k] or font, string.trim(panel.lines[k]))
    end
    return width
end




local function description(panel, left, top, words, pictures)
    local r, g, b, font, orient = 1, 1, 1, panel.defaultFont, "left"
    local centredY, shift = nil, 0
    for c, text in ipairs(panel.lines or {}) do
        local colour = panel.rgb[c]
        if colour then r, g, b = colour.r, colour.g, colour.b end
        orient = panel.orient[c] or orient
        font = panel.fonts[c] or font
        local x = left + panel.marginLeft + panel.lineX[c]
        local y = top + panel.marginTop + panel.lineY[c]
        if orient == "centre" or centredY == panel.lineY[c] then
            if centredY ~= panel.lineY[c] and string.trim(text) ~= "" then
                centredY = panel.lineY[c]
                shift = (panel.width - panel.marginLeft - panel.marginRight - lineLength(panel, c, font)) / 2
            end
            x = x + shift
        elseif orient == "right" then
            x = x - getTextManager():MeasureStringX(font, string.trim(text))
        end
        addWords(words, text, x, y, r, g, b, font)
    end
    for c, texture in ipairs(panel.images or {}) do
        table.insert(pictures, { texture = texture, x = left + panel.marginLeft + panel.imageX[c],
                                 y = top + panel.marginTop + panel.imageY[c], w = panel.imageW[c], h = panel.imageH[c] })
    end
end





local function tipOf(tip)
    if type(tip) ~= "table" or not tip.doLayout or not tip.descriptionPanel then return nil end
    tip:doLayout()
    local words, pictures = {}, {}
    local medium = getTextManager():getFontHeight(UIFont.Medium)
    local left = 10
    if tip.texture then
        local w, h = tip.texture:getWidth(), tip.texture:getHeight()
        table.insert(pictures, { texture = tip.texture, x = 8, y = tip.name and 35 or 5, w = w, h = h })
        left = 8 + w + 10
    end
    if tip.name then addWords(words, tip.name, 8, 5, 1, 1, 1, UIFont.Medium) end
    if tip.description ~= "" then description(tip.descriptionPanel, left, tip.name and medium or 0, words, pictures) end
    if tip.footNote then
        local small = getTextManager():getFontHeight(UIFont.Small)
        local x = (tip.width - getTextManager():MeasureStringX(UIFont.Small, tip.footNote)) / 2
        addWords(words, tip.footNote, x, tip.height - small - 4, 1, 1, 1, UIFont.Small)
    end
    if #words == 0 then return nil end
    return { width = tip.width, height = tip.height, words = words, pictures = pictures }
end


local tipFailed = false


local function laidOut(tip)
    local ok, result = pcall(tipOf, tip)
    if ok then return result end
    if not tipFailed then
        tipFailed = true
        print("[Viewpoint] interaction menu: a tooltip could not be laid out: " .. tostring(result))
    end
    return nil
end




local function finish(list, title, seen)
    local ordered = ViewpointInteractOrder.sort(list)
    ViewpointInteract.actions = ordered
    local labels, enabled, deliberate, tips = {}, {}, {}, {}
    for i, a in ipairs(ordered) do
        labels[i] = a.name
        enabled[i] = a.enabled
        deliberate[i] = a.deliberate == true
        tips[i] = a.tip and laidOut(a.tip)
    end
    return { title = title, labels = labels, enabled = enabled, deliberate = deliberate, tips = tips,
             seen = seen or #list }
end




local HALO_TEXTS = { "addText", "addGoodText", "addBadText", "addTextWithArrow" }





local function unseen(build)
    local debug = DebugContextMenu and DebugContextMenu.doDebugMenu
    if debug then DebugContextMenu.doDebugMenu = function() end end
    local halo = {}
    for _, name in ipairs(HALO_TEXTS) do
        halo[name] = HaloTextHelper[name]
        HaloTextHelper[name] = function() end
    end
    local ok, result = pcall(build)
    for _, name in ipairs(HALO_TEXTS) do HaloTextHelper[name] = halo[name] end
    if debug then DebugContextMenu.doDebugMenu = debug end
    return ok, result
end



function ViewpointInteract.menu(playerNum)
    local open = getPlayerContextMenu(playerNum)
    if not open then return nil, "no context menu" end
    if getCell():getDrag(playerNum) then return nil, "a placement cursor is out" end
    if open:getIsVisible() then return nil, "the right-click menu is open" end
    return open
end



function ViewpointInteract.build(playerNum, worldobjects, sq)
    local x = isoToScreenX(playerNum, sq:getX(), sq:getY(), sq:getZ())
    local y = isoToScreenY(playerNum, sq:getX(), sq:getY(), sq:getZ())
    return unseen(function() return W.createMenu(playerNum, worldobjects, x, y) end)
end




local function loaded(x, y, z)
    local s = getCell():getGridSquare(x, y, z)
    return s ~= nil and s:getChunk() ~= nil
end


function ViewpointInteract.state(object, worldobjects, player)
    local order = ViewpointInteractOrder
    return { skip = skipped(), first = order.primary(), rank = order.ranks(),
             own = object and own(object, player) or {}, object = object, curtain = object and curtain(object),
             worldobjects = worldobjects,
             debugIcon = getTexture("media/textures/Item_Plumpabug_Left.png"), lockedWord = getText("EC_Locked") }
end



function ViewpointInteract.harvest(player, object)
    local playerNum = player:getPlayerNum()
    local open, why = ViewpointInteract.menu(playerNum)
    if not open then return { why = why } end
    local sq = object:getSquare()
    if not sq then return { why = "not on a square" } end
    local x, y, z = sq:getX(), sq:getY(), sq:getZ()
    if not (loaded(x, y, z) and loaded(x - 1, y, z) and loaded(x, y - 1, z)) then
        return { why = "the squares by it are not loaded yet" }
    end
    local worldobjects = { object }
    local ok, context = ViewpointInteract.build(playerNum, worldobjects, sq)
    local list = {}
    local state = ViewpointInteract.state(object, worldobjects, player)
    state.plant = CFarmingSystem and CFarmingSystem.instance and CFarmingSystem.instance:getLuaObjectOnSquare(sq)
    if ok and type(context) == "table" then collect(context, 0, nil, list, state) end
    for _, a in ipairs(list) do a.name = label(a, state.title) end
    lightToggle(list, player, object)
    withoutChopCursor(list)
    withoutDestroyCursor(list, object)

    if not state.title and instanceof(object, "IsoPlayer") then state.title = object:getDisguisedDisplayName() end

    open:hideAndChildren()
    if not ok then error(context) end
    if type(context) ~= "table" then return { why = "the game built no menu (" .. tostring(context) .. ")" } end
    ViewpointInteract.target = { square = sq, object = object }
    return finish(list, state.title, state.seen or 0)
end



local function seatAt(player, vehicle, part)
    if not part then return vehicle:getBestSeat(player) end
    if not (part:getDoor() and part:getInventoryItem()) then return -1 end
    for seat = 0, vehicle:getMaxPassengers() - 1 do
        if vehicle:getPassengerDoor(seat) == part or vehicle:getPassengerDoor2(seat) == part then return seat end
    end
    return -1
end




local function radialStandIn(list)
    local menu = {
        addSlice = function(self, text, texture, fn, ...)
            table.insert(list, { name = text, fn = fn, args = { ... }, n = select("#", ...), enabled = fn ~= nil })
        end,
        isEmpty = function() return true end,
        isReallyVisible = function() return #list > 0 end,
    }
    return setmetatable(menu, { __index = function() return function() end end })
end




local function radialEntries(player, vehicle)
    local list = {}
    local standIn = radialStandIn(list)
    local radialOf, pick = getPlayerRadialMenu, ISVehicleMenu.getVehicleToInteractWith
    getPlayerRadialMenu = function() return standIn end
    ISVehicleMenu.getVehicleToInteractWith = function() return vehicle end
    local ok, err = pcall(ISVehicleMenu.showRadialMenuOutside, player)
    getPlayerRadialMenu, ISVehicleMenu.getVehicleToInteractWith = radialOf, pick
    if not ok then error(err) end
    return list
end





function ViewpointInteract.harvestVehicle(player, vehicle)
    local list = {}
    local doorPart = vehicle:getUseablePart(player)
    local seat = seatAt(player, vehicle, doorPart)
    local lockedWord = getText("EC_Locked")
    if seat ~= -1 then
        local name = getText("IGUI_EnterVehicle")
        if doorPart and doorPart:getDoor():isLocked() then name = name .. " [" .. lockedWord .. "]" end
        table.insert(list, { name = name, fn = ISVehicleMenu.onEnter,
                             args = { player, vehicle, seat }, n = 3, enabled = true, first = true })
    end
    for _, a in ipairs(radialEntries(player, vehicle)) do
        local door = a.fn == ISVehicleMenu.onOpenDoor or a.fn == ISVehicleMenu.onCloseDoor
        a.first = seat == -1 and door and a.args[2] == doorPart
        if a.fn == ISVehicleMenu.onOpenDoor and a.args[2]:getDoor():isLocked() then
            a.name = a.name .. " [" .. lockedWord .. "]"
        end
        if a.fn ~= ISVehicleMenu.onShowSeatUI then table.insert(list, a) end
    end
    ViewpointInteract.target = nil
    return finish(list, ISVehicleMenu.getVehicleDisplayName(vehicle))
end




local function barricade(player, cursor, object)
    local sq = object:getSquare()
    local x, y, z = sq:getX(), sq:getY(), sq:getZ()
    local n = 2
    if object:getNorth() then
        if player:getY() < y then y, n = y - 1, 4 end
    else
        n = 1
        if player:getX() < x then x, n = x - 1, 3 end
    end
    cursor.nSprite = n
    cursor:getFace()
    cursor:getSprite()
    local at = getCell():getGridSquare(x, y, z)
    if at and cursor:isValid(at) then cursor:tryBuild(x, y, z) end
end







local function placed(player, cursor)
    local t = ViewpointInteract.target
    if t and t.object and ViewpointBuild and ViewpointBuild.barricade(cursor) then
        barricade(player, cursor, t.object)
        return
    end
    local farming = ISFarmingMenu and cursor == ISFarmingMenu.cursor
    if not (t and (t.ground or farming)) then return end
    local playerNum = player:getPlayerNum()
    getCell():setDrag(nil, playerNum)
    if farming and not JoypadState.players[playerNum + 1] then return end
    local sq = t.square
    cursor.sq = sq
    if cursor:isValid(sq) then cursor:tryBuild(sq:getX(), sq:getY(), sq:getZ()) end
end




function ViewpointInteract.run(player, index, side)
    local a = ViewpointInteract.actions[index]
    if not a or not a.enabled or not a.fn then return end
    local playerNum = player:getPlayerNum()
    local before = getCell():getDrag(playerNum)
    a.side = side
    if a.menu then ISContextMenu.globalPlayerContext = playerNum end
    a.fn(unpack(a.args, 1, a.n))
    local cursor = getCell():getDrag(playerNum)
    if cursor and cursor ~= before then placed(player, cursor) end
end


ViewpointInteract.collect, ViewpointInteract.label, ViewpointInteract.finish = collect, label, finish
