




ViewpointInvBody = {}
local B = ViewpointInvBody


B.W, B.H = 123, 302
local REACH_W, REACH_H = 14, 16
local MAX_SCALE = 2.25

B.TARGETS_X, B.TARGETS_Y = -7, -13

local BODY_ALPHA = 0.25
B.LAST = 16



local PARTS = {
    [0] = { "hand_left", "left-hand", 0 }, [1] = { "hand_right", "right-hand", 0 },
    [2] = { "lowerarm_left", "lower-left-arm", 0 }, [3] = { "lowerarm_right", "lower-right-arm", 0 },
    [4] = { "upperarm_left", "upper-left-arm", 0 }, [5] = { "upperarm_right", "upper-right-arm", 0 },
    [6] = { "chest", "chest", 30 }, [7] = { "abdomen", "abdomen", 50 }, [8] = { "head", "head", 0 },
    [9] = { "neck", "neck", 0 }, [10] = { "groin", "groin", 100 },
    [11] = { "upperleg_left", "left-thigh", 0 }, [12] = { "upperleg_right", "right-thigh", 0 },
    [13] = { "lowerleg_left", "left-calf", 0 }, [14] = { "lowerleg_right", "right-calf", 0 },
    [15] = { "foot_left", "left-foot", 0 }, [16] = { "foot_right", "right-foot", 0 },
}


local ORDER = {}
for i = 0, B.LAST do table.insert(ORDER, i) end
table.sort(ORDER, function(a, b) return PARTS[a][3] < PARTS[b][3] end)


local figures = {}

function B.textures(female)
    local sex = female and "female" or "male"
    if figures[sex] then return figures[sex] end
    local f = {
        health = getTexture("media/ui/BodyDamage/" .. sex .. "_base.png"),
        body = getTexture("media/ui/BodyParts/" .. sex .. "_base_white"),
        outline = getTexture("media/ui/BodyParts/bps_" .. sex .. "_outlines"),
        parts = {},
    }
    for i = 0, B.LAST do
        local name = PARTS[i][1] .. ".png"
        local function mark(kind) return getTexture("media/ui/BodyDamage/" .. sex .. "_" .. kind .. "_" .. name) end
        f.parts[i] = {
            scratch = mark("scratch"), bandage = mark("bandage"), dirty = mark("bandagedirty"),
            infection = mark("infection"), bite = mark("bite"), deep = mark("deepwound"), stitches = mark("stitches"),
            glass = mark("glass"), bones = mark("bones"), splint = mark("splint"), burn = mark("burn"),
            bullet = mark("bullet"), shape = getTexture("media/ui/BodyParts/bps_" .. sex .. "_" .. PARTS[i][2]),
        }
    end
    figures[sex] = f
    return f
end


function B.fit(w, h)
    return math.min(MAX_SCALE, h / (B.H + REACH_H), w / (B.W + REACH_W))
end


function B.part(player, i)
    return player:getBodyDamage():getBodyPart(BodyPartType.FromIndex(i))
end

function B.name(i)
    return BodyPartType.getDisplayName(BodyPartType.FromIndex(i))
end

local function draw(o, tex, x, y, s, alpha)
    if tex and alpha > 0 then o:DrawTextureScaledUniform(tex, x, y, s, 1, 1, 1, math.min(1, alpha)) end
end



local function marks(o, x, y, s, part, t)
    local bandaged = part:bandaged()
    if not bandaged then draw(o, t.infection, x, y, s, part:getWoundInfectionLevel() / 10) end
    if bandaged then
        draw(o, part:getBandageLife() > 0 and t.bandage or t.dirty, x, y, s, 1)
    elseif part:scratched() then
        draw(o, t.scratch, x, y, s, part:getScratchTime() / 20)
    elseif part:isCut() then
        draw(o, t.scratch, x, y, s, part:getCutTime() / 20)
    elseif part:bitten() and part:getBiteTime() >= 0 then
        draw(o, t.bite, x, y, s, 1)
    elseif part:deepWounded() then
        draw(o, t.deep, x, y, s, part:getDeepWoundTime() / 15)
    elseif part:stitched() then
        draw(o, t.stitches, x, y, s, 1)
    end
    if part:getFractureTime() > 0 and part:getSplintFactor() == 0 then
        draw(o, t.bones, x, y, s, 1)
    elseif part:getSplintFactor() > 0 then
        draw(o, t.splint, x, y, s, 1)
    end
    if bandaged then return end
    if part:haveGlass() then draw(o, t.glass, x, y, s, 1) end
    if part:haveBullet() then draw(o, t.bullet, x, y, s, 1) end
    draw(o, t.burn, x, y, s, part:getBurnTime() / 100)
end


function B.health(o, f, player, x, y, s)
    if not f.health then return end
    local fx = x + (f.health:getWidth() - B.W + 2) * s
    local fy = y + (f.health:getHeight() - B.H + 2) * s
    o:DrawTextureScaledUniform(f.health, fx, fy, s, 1, 1, 1, 1)
    for i = 0, B.LAST do marks(o, fx, fy, s, B.part(player, i), f.parts[i]) end
end

function B.body(o, f, x, y, s)
    if f.body then o:DrawTextureScaledUniform(f.body, x, y, s, 1, 1, 1, BODY_ALPHA) end
end

function B.outline(o, f, x, y, s)
    if f.outline then o:DrawTextureScaledUniform(f.outline, x, y, s, 1, 1, 1, 1) end
end



function B.shapes(o, f, x, y, s, tint, add)
    for _, i in ipairs(ORDER) do
        local shape = f.parts[i].shape
        if shape then
            local c, alpha = tint(i)
            if c then o:DrawTextureScaledUniform(shape, x, y, s, c[1], c[2], c[3], alpha) end
            add(x + shape:getOffsetX() * s, y + shape:getOffsetY() * s, shape:getWidth() * s, shape:getHeight() * s, i)
        end
    end
end
