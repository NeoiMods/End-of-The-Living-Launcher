








require "Viewpoint_InvStyle"
require "Viewpoint_InvData"

ViewpointInvGrid = {}
local G = ViewpointInvGrid
G.__index = G
local S = ViewpointInvStyle
local D = ViewpointInvData

local folded = getTexture("media/ui/inventoryPanes/Button_TreeCollapsed.png")
local unfolded = getTexture("media/ui/inventoryPanes/Button_TreeExpanded.png")
local favourite = getTexture("media/ui/FavoriteStar.png")
local broken = getTexture("media/ui/icon_broken.png")


function G.new(title, mine, grows)
    return setmetatable({ title = title, mine = mine, grows = grows, sections = {}, scroll = 0, hits = {}, query = "",
        order = D.ORDERS[1], x = 0, y = 0, w = 0, h = 0, room = 0 }, G)
end




function G:layout(x, y, w, h, m)
    self.x, self.y, self.w, self.h, self.room, self.m = x, y, w, h, h, m
    self.cols = math.max(1, math.floor((w - m.pad * 2 + m.gap) / (m.tile + m.gap)))
    local widest = 0
    for _, order in ipairs(D.ORDERS) do
        widest = math.max(widest, getTextManager():MeasureStringX(UIFont.Small, order.label))
    end
    local row = m.font + m.pad * 2
    local bh = m.font + m.pad
    local by = y + m.title + math.floor((row - bh) / 2)
    local ow = widest + m.pad * 3 + 10
    self.orderRect = { x = x + w - m.pad - ow, y = by, w = ow, h = bh }
    self.searchRect = { x = x + m.pad, y = by, w = self.orderRect.x - m.pad * 2 - x, h = bh }
    self.bodyTop = y + m.title + row
end

function G:nextOrder()
    for i, order in ipairs(D.ORDERS) do
        if order == self.order then
            self.order = D.ORDERS[i % #D.ORDERS + 1]
            return
        end
    end
    self.order = D.ORDERS[1]
end

function G:contains(mx, my)
    return mx >= self.x and mx < self.x + self.w and my >= self.y and my < self.y + self.h
end


function G:scrollBy(px)
    self.scroll = math.max(0, math.min(self.scroll + px, self.most or 0))
end

function G:wheel(del)
    self:scrollBy(del * (self.m.tile + self.m.gap))
end


function G:floor()
    for _, s in ipairs(self.sections) do
        if s.floor then return s end
    end
    return nil
end





function G.tile(ui, m, x, y, size, item, count, state, job, look)
    look = look or D.look(item)
    S.slotBox(ui, x, y, size, size, state.hover, nil, state.selected)
    local inset = m.inset
    local inner = size - inset * 2
    local kind = S.typeTint(look.type)
    if kind then S.rect(ui, x + inset, y + inset, inner, inner, kind) end
    local damage = S.damage(look.condition, look.broken)
    if damage then S.rect(ui, x + inset, y + inset, inner, inner, damage) end
    if job and job > 0 then S.rect(ui, x + inset, y + inset, math.floor(inner * job), inner, S.job) end
    local icon = math.floor(size * 0.6)
    local alpha = state.dim and 0.45 or 1.0
    ui.javaObject:DrawItemIcon(item, x + math.floor((size - icon) / 2), y + math.floor((size - icon) / 2) - 2, alpha, icon, icon)
    local bottom = y + size - inset
    local amount = look.amount
    if amount then
        local fill = math.floor((inner - 2) * math.max(0, math.min(1, amount)))
        if fill > 0 then S.rect(ui, x + inset + 1, bottom - 3, fill, 2, S.amount) end
        bottom = bottom - 3
    end
    if count and count > 1 then S.textRight(ui, tostring(count), x + size - inset - 2, bottom - m.font, S.bright) end
    if state.slot then S.text(ui, tostring(state.slot), x + inset + 2, y + inset, S.accent) end
    local mark = look.broken and broken or (look.favourite and favourite or nil)
    if mark then S.icon(ui, mark, x + size - inset - 12, y + inset + 1, 11) end
end



local JOB_ITEMS = 16

local function largestJob(stack)
    local job = 0
    for i = 1, math.min(#stack.items, JOB_ITEMS) do job = math.max(job, stack.items[i]:getJobDelta()) end
    return job
end

local function hit(self, x, y, w, h, target)
    table.insert(self.hits, { x = x, y = y, w = w, h = h, target = target })
end


local function tilesHeight(self, n)
    local m = self.m
    if n == 0 then return m.font + m.gap * 2 end
    return m.gap + math.ceil(n / self.cols) * (m.tile + m.gap)
end


function G:contentHeight()
    local m = self.m
    local searching = self.query ~= ""
    local height = 0
    for _, s in ipairs(self.sections) do
        local shown = D.shown(s, self.query, self.order)
        if not searching or #shown > 0 then
            height = height + m.header + m.pad
            if searching or not s.folded then height = height + tilesHeight(self, #shown) end
        end
    end
    return height
end



function G:header(ui, s, shown, x, y, w, view)
    local m = self.m
    local over = view.hover and view.hover.section == s
    hit(self, x, y, w, m.header, { kind = "header", section = s })
    S.componentHeader(ui, x, y, w, m.header, over)
    if s.container == view.across or s.container == view.into then
        S.rect(ui, x + 1, y + 1, 2, m.header - 2, S.accent)
    end
    local cx = x + m.pad
    S.icon(ui, s.folded and folded or unfolded, cx, y + math.floor((m.header - 12) / 2), 12)
    cx = cx + 16
    local iconSize = m.header - 4
    if s.icon then
        local tint = s.tint
        S.icon(ui, s.icon, cx, y + 2, iconSize, 1, tint and tint.r, tint and tint.g, tint and tint.b)
    end
    if s.lock then S.icon(ui, s.lock, cx + iconSize - 10, y + iconSize - 8, 10) end
    cx = cx + iconSize + m.pad
    local load, capacity = D.load(s, view.player)
    local drag = view.drag and over and view.drag
    if drag then load = load + drag.weight end
    local weight = capacity > 0 and (S.weight(load) .. " / " .. S.weight(capacity)) or S.weight(load)
    local right = x + w - m.pad
    S.textRight(ui, weight, right, y + m.pad, drag and (drag.fits[s] and S.good or S.bad) or S.muted)
    right = right - getTextManager():MeasureStringX(UIFont.Small, weight) - m.pad * 2
    if not self.mine and not s.locked and #s.stacks > 0 then
        local label = getText("IGUI_invpage_Loot_all")
        local bw = getTextManager():MeasureStringX(UIFont.Small, label) + m.pad * 2
        local bx = right - bw
        local bover = view.hover and view.hover.kind == "takeAll" and view.hover.section == s
        S.button(ui, m, bx, y + 2, bw, m.header - 4, label, bover, false, true)
        hit(self, bx, y + 2, bw, m.header - 4, { kind = "takeAll", section = s, stacks = self.query ~= "" and shown or nil })
        right = bx - m.pad
    end
    S.text(ui, S.fit(S.caps(s.title), right - cx), cx, y + m.pad, s.locked and S.dim or S.bright)
    if capacity > 0 then
        local fraction = load / capacity
        S.bar(ui, x, y + m.header - 2, w, 2, fraction, drag and (drag.fits[s] and S.drop or S.refuse) or S.fullness(fraction))
    end
    if drag then S.edge(ui, x, y, w, m.header, drag.fits[s] and S.drop or S.refuse) end
end


function G:tiles(ui, s, stacks, top, bottomEdge, view)
    local m = self.m
    local size, step = m.tile, m.tile + m.gap
    local x0 = self.x + m.pad
    if #stacks == 0 then
        if not s.locked then S.text(ui, getText("Fluid_Empty"), x0 + m.pad, top + m.gap, S.dim) end
        return tilesHeight(self, 0)
    end
    local selected = view.selected[s.container]
    local working = not view.player:getCharacterActions():isEmpty()
    for i, stack in ipairs(stacks) do
        local col, row = (i - 1) % self.cols, math.floor((i - 1) / self.cols)
        local tx, ty = x0 + col * step, top + m.gap + row * step
        if ty + size >= self.bodyTop and ty <= bottomEdge then
            local state = {
                hover = view.hover and view.hover.stack == stack,
                selected = selected and selected[stack.key],
                dim = stack.unwanted,
                slot = stack.slot,
            }
            local job = working and largestJob(stack) or nil
            G.tile(ui, m, tx, ty, size, stack.item, stack.count, state, job, stack.look)
            hit(self, tx, ty, size, size, { kind = "tile", section = s, stack = stack })
        end
    end
    return tilesHeight(self, #stacks)
end



function G:orderButton(ui, view)
    local m, r = self.m, self.orderRect
    local over = view.hover and view.hover.kind == "order" and view.hover.grid == self
    S.button(ui, m, r.x, r.y, r.w, r.h, "", over)
    local colour = (S.modern and not over) and S.muted or S.bright
    S.text(ui, self.order.label, r.x + m.pad, r.y + math.floor((r.h - m.font) / 2), colour)
    S.icon(ui, unfolded, r.x + r.w - m.pad - 10, r.y + math.floor((r.h - 10) / 2), 10)
end



function G:render(ui, view)
    local m = self.m
    self.hits = {}
    local bottom = self.y + self.room
    if self.grows then bottom = math.min(bottom, self.bodyTop + self:contentHeight()) end
    self.h = bottom - self.y
    S.window(ui, m, self.x, self.y, self.w, self.h, self.title)
    self:orderButton(ui, view)
    local bodyH = math.min(self.y + self.room - m.pad, bottom) - self.bodyTop
    local bottomEdge = self.bodyTop + bodyH
    self.body = { x = self.x, y = self.bodyTop, w = self.w, h = bodyH }
    ui:setStencilRect(self.x, self.bodyTop, self.w, bodyH)
    local y = self.bodyTop - self.scroll
    local w = self.w - m.pad * 2
    local searching = self.query ~= ""
    for _, s in ipairs(self.sections) do
        local shown = D.shown(s, self.query, self.order)
        if not searching or #shown > 0 then
            if y + m.header >= self.bodyTop and y <= bottomEdge then
                self:header(ui, s, shown, self.x + m.pad, y, w, view)
            end
            y = y + m.header
            if searching or not s.folded then y = y + self:tiles(ui, s, shown, y, bottomEdge, view) end
            y = y + m.pad
        end
    end
    ui:clearStencilRect()
    local content = y + self.scroll - self.bodyTop
    self.most = math.max(0, content - bodyH)
    self.scroll = math.max(0, math.min(self.scroll, self.most))
    if content > bodyH then
        local track = bodyH * bodyH / content
        local at = self.bodyTop + (bodyH - track) * (self.scroll / math.max(1, content - bodyH))
        S.rect(ui, self.x + self.w - 4, at, 2, track, S.scrollBar)
    end
end


function G:tilesIn(r)
    local list = {}
    for _, h in ipairs(self.hits) do
        local t = h.target
        if t.kind == "tile" and h.x < r.x + r.w and r.x < h.x + h.w and h.y < r.y + r.h and r.y < h.y + h.h then
            table.insert(list, t)
        end
    end
    return list
end


function G:hit(mx, my)
    if not self:contains(mx, my) then return nil end
    local r = self.orderRect
    if r and mx >= r.x and mx < r.x + r.w and my >= r.y and my < r.y + r.h then return { kind = "order", grid = self } end
    if my >= (self.bodyTop or self.y) then
        for i = #self.hits, 1, -1 do
            local h = self.hits[i]
            if mx >= h.x and mx < h.x + h.w and my >= h.y and my < h.y + h.h then return h.target end
        end
    end
    return { kind = "column", grid = self }
end
