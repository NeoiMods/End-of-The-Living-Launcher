




require "ISUI/ISEquippedItem"
require "Viewpoint_InvScreen"
require "Viewpoint_InvInput"
require "Viewpoint_InvPad"

ViewpointInventory = ViewpointInventory or {}


local PLAYER = 0

local SIDEBAR_TABS = { INVENTORY = "character", HEALTH = "health" }


local windowsUp = false



local function showWindows()
    local loot, inventory = getPlayerLoot(PLAYER), getPlayerInventory(PLAYER)
    if not (loot and inventory) then return false end
    for _, page in ipairs({ loot, inventory }) do
        page:setVisible(true)
        if page.isCollapsed then
            if isClient() and not page.onCharacter then page.inventoryPane.inventory:requestSync() end
            page.isCollapsed = false
            page:clearMaxDrawHeight()
        end
        page.collapseCounter = 0
    end
    return true
end

local function hideWindows()
    for _, page in ipairs({ getPlayerLoot(PLAYER), getPlayerInventory(PLAYER) }) do
        if page then page:setVisible(false) end
    end
end



function ViewpointInventory.open(how)
    if how == "screen" then return ViewpointInvScreen.show(nil) end
    local shown = showWindows()
    if how == "windows" then windowsUp = windowsUp or shown end
    return shown
end

function ViewpointInventory.close()
    ViewpointInvScreen.hide()
    if windowsUp then hideWindows() end
    windowsUp = false
end


function ViewpointInventory.release()
    ViewpointInvScreen.hide()
    windowsUp = false
end


function ViewpointInventory.up()
    if ViewpointInvScreen.isUp() then return true end
    local inventory = getPlayerInventory(PLAYER)
    return windowsUp and inventory ~= nil and inventory:getIsVisible()
end


function ViewpointInventory.focus(container)
    ViewpointInvScreen.focusOn(container)
end


function ViewpointInventory.tab(id)
    if ViewpointInvScreen.isUp() then ViewpointInvScreen.instance:selectTab(id) end
end


local sidebarClick = ISEquippedItem.onOptionMouseDown

function ISEquippedItem:onOptionMouseDown(button, x, y)
    local tab = SIDEBAR_TABS[button.internal]
    local loot = Viewpoint and Viewpoint.Loot
    if tab and loot and self.chr:getPlayerNum() == PLAYER and loot.openScreen(tab) then return end
    return sidebarClick(self, button, x, y)
end


local data = getPlayerData(PLAYER)
if data and data.equipped then
    for _, button in ipairs({ data.equipped.invBtn, data.equipped.healthBtn }) do
        if button.onclick == sidebarClick then button.onclick = ISEquippedItem.onOptionMouseDown end
    end
end
