-- Project A-Life - Hungarian Translation
-- NPC kimondott sorok (barks, valaszok, jelenetek, radio) magyaritasa.
-- Ez a fajl NEM modositja az alap mod fajljait: futasidoben wrappeli a beszed-fuggvenyeket,
-- es a forditasokat a Translate/HU/RadioData.json -bol olvassa RD_AlifeLine_<hash> kulcsokkal.
-- A kulcsot az alap mod sajat Text.hash / Text.lineKey fuggvenyevel azonosan szamoljuk.

ProjectALife = ProjectALife or {}

local HU = ProjectALife.HU or {}
ProjectALife.HU = HU

HU.prefix = "RD_AlifeLine_"
HU.metrics = HU.metrics or { lookups = 0, hits = 0, misses = 0, patched = 0 }
HU.installed = HU.installed == true
HU.digest = HU.digest == true

local cache = {}
local cacheCount = 0
local cacheCap = 20000
local digits = "0123456789abcdef"

local function hex8(value)
    local out = ""
    value = math.floor(value)
    for _ = 1, 8 do
        local digit = value % 16
        out = string.sub(digits, digit + 1, digit + 1) .. out
        value = math.floor(value / 16)
    end
    return out
end

-- Pontosan ugyanaz az algoritmus, mint az alap mod Core/ALifeText.lua Text.hash fuggvenye.
function HU.hash(text)
    local a, b = 5381.0, 52711.0
    for index = 1, #text do
        local c = string.byte(text, index)
        a = (a * 33 + c) % 2147483647
        b = (b * 131 + c) % 2147483629
    end
    return hex8(a) .. hex8(b)
end

function HU.key(text)
    return HU.prefix .. HU.hash(text)
end

function HU.flush()
    cache = {}
    cacheCount = 0
end

local function remember(text, value)
    if cacheCount >= cacheCap then HU.flush() end
    cache[text] = value
    cacheCount = cacheCount + 1
end

-- Visszaadja a magyar valtozatot, vagy nil-t, ha nincs forditas.
function HU.lookup(text)
    if type(text) ~= "string" or text == "" then return nil end
    local memo = cache[text]
    if memo ~= nil then
        if memo == false then return nil end
        return memo
    end
    HU.metrics.lookups = HU.metrics.lookups + 1
    local value = nil
    if type(getTextOrNull) == "function" then
        local ok, result = pcall(getTextOrNull, HU.key(text))
        if ok and type(result) == "string" and result ~= "" then value = result end
    end
    if value == nil then
        HU.metrics.misses = HU.metrics.misses + 1
        remember(text, false)
        return nil
    end
    HU.metrics.hits = HU.metrics.hits + 1
    remember(text, value)
    return value
end

function HU.translate(text)
    if type(text) ~= "string" or text == "" then return text end
    return HU.lookup(text) or text
end

-- "HU", "OTHER" vagy "UNKNOWN" (ha az API nem erheto el).
local function languageState()
    local okCore, core = pcall(function() return getCore() end)
    if not okCore or core == nil then return "UNKNOWN" end
    local okName, name = pcall(function() return core:getOptionLanguageName() end)
    if okName and type(name) == "string" and name ~= "" then
        name = string.upper(name)
        if name == "HU" then return "HU" end
    end
    local okLang, lang = pcall(function() return core:getOptionLanguage() end)
    if okLang and type(lang) == "string" and lang ~= "" then
        lang = string.upper(lang)
        if lang == "HU" then return "HU" end
    end
    if okName or okLang then return "OTHER" end
    return "UNKNOWN"
end

-- Magyar megszolitasok: az angol {sir} / {he} / {him} ... placeholderek magyar alakot kapnak.
local function localizeAddressForms(speech)
    local forms = speech.addressForms
    if type(forms) ~= "table" then return end
    forms.sir = { "uram", "asszonyom" }
    forms.mister = { "uram", "hölgyem" }
    forms.he = { "ő", "ő" }
    forms.him = { "őt", "őt" }
    forms.his = { "az ő", "az ő" }
    forms.hers = { "az övé", "az övé" }
    forms.himself = { "magát", "magát" }
end

-- A becsomagoltsag nyilvantartasa: a Kahlua (a jatek Lua-ertelmezoje) hibaval
-- eldobja a fuggvenyertekek mezoinek olvasasat/irasat (pl. fn.huWrapped),
-- ezert a korabban hasznalt jeloles minden betolteskor kivetelt dobott.
-- Helyette referencia-osszehasonlitast hasznalunk: ha a speech-tabla
-- aktualis erteke azonos az altalunk feltett wrapperrel, keszen vagyunk.
HU.wrappers = HU.wrappers or {}

local function patchSpeech(speech)
    local newly = 0

    local baseRender = speech.render
    if type(baseRender) == "function" and baseRender ~= HU.wrappers.render then
        local wrapper = function(text, vars, shell, psex)
            if type(text) == "string" then text = HU.translate(text) end
            return baseRender(text, vars, shell, psex)
        end
        HU.wrappers.render = wrapper
        speech.render = wrapper
        newly = newly + 1
    end

    local baseSay = speech.say
    if type(baseSay) == "function" and baseSay ~= HU.wrappers.say then
        local wrapper = function(shell, text, options)
            if type(text) == "string" then text = HU.translate(text) end
            return baseSay(shell, text, options)
        end
        HU.wrappers.say = wrapper
        speech.say = wrapper
        newly = newly + 1
    end

    local baseSayLine = speech.sayLine
    if type(baseSayLine) == "function" and baseSayLine ~= HU.wrappers.sayLine then
        local wrapper = function(shell, text, kind)
            if type(text) == "string" then text = HU.translate(text) end
            return baseSayLine(shell, text, kind)
        end
        HU.wrappers.sayLine = wrapper
        speech.sayLine = wrapper
        newly = newly + 1
    end

    local baseDisplay = speech.display
    if type(baseDisplay) == "function" and baseDisplay ~= HU.wrappers.display then
        local wrapper = function(shell, text, color, kind, uid)
            if type(text) == "string" then text = HU.translate(text) end
            return baseDisplay(shell, text, color, kind, uid)
        end
        HU.wrappers.display = wrapper
        speech.display = wrapper
        newly = newly + 1
    end

    return newly
end

function HU.install()
    local speech = ProjectALife and ProjectALife.Speech
    if type(speech) ~= "table" or type(speech.render) ~= "function" then return false end

    -- A megszolitasokat mindig magyarositjuk: a forditas kesz szovegeben {sir} / {he} szerepel,
    -- fuggetlenul attol, hogy eppen kliensen vagy dedikalt szerveren futunk.
    local state = languageState()
    localizeAddressForms(speech)

    HU.metrics.patched = HU.metrics.patched + patchSpeech(speech)
    HU.installed = true

    if HU.digest then
        print("[ALifeHU] Beszed-hook telepitve. Nyelv: " .. state .. ", kulcselotag: " .. HU.prefix)
    end
    return true
end

function HU.stats()
    return string.format("[ALifeHU] lookups=%d hits=%d misses=%d installed=%s",
        HU.metrics.lookups, HU.metrics.hits, HU.metrics.misses, tostring(HU.installed))
end

-- A mod betoltese utan azonnal, majd a jatek esemenyein ujra megprobaljuk (betoltesi sorrend fuggetlen).
HU.install()

local events = Events
if events ~= nil then
    if events.OnGameBoot ~= nil then events.OnGameBoot.Add(HU.install) end
    if events.OnGameStart ~= nil then events.OnGameStart.Add(HU.install) end
    if events.OnServerStarted ~= nil then events.OnServerStarted.Add(HU.install) end
    if events.OnGameEnd ~= nil then events.OnGameEnd.Add(HU.flush) end
end
