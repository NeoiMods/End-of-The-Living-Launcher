package com.pzoptimizer;

/** Normalises and interns asset paths (textures, models, sounds) so loading doesn't keep copying the same strings. */
public class FastPathCache {
    private static final int CACHE_SIZE = 4096;
    private static final int MASK = CACHE_SIZE - 1;
    private static final String[] KEY_CACHE = new String[CACHE_SIZE];
    private static final String[] VAL_CACHE = new String[CACHE_SIZE];

    public static String normalize(String path) {
        if (path == null) return null;
        if (path.isEmpty()) return "";

        int hash = (path.hashCode() & 0x7FFFFFFF) & MASK;
        String cachedKey = KEY_CACHE[hash];
        if (path.equals(cachedKey)) {
            return VAL_CACHE[hash];
        }

        String normalized = path.indexOf('\\') != -1 ? path.replace('\\', '/') : path;
        normalized = ResourceInterner.intern(normalized);

        KEY_CACHE[hash] = path;
        VAL_CACHE[hash] = normalized;
        return normalized;
    }
}
