package com.pzoptimizer;

import java.io.File;
import java.lang.reflect.Method;

/** Launcher entry point: runs PZO's startup tuning, then hands over to the game's main class. */
public class PZOEntrypoint {

    public static void main(String[] args) {
        // AWT/Swing has to be allowed for the pre-menu dialogs
        try {
            System.setProperty("java.awt.headless", "false");
        } catch (Throwable ignored) {}
        PZOLogger.info("================================================================================");
        PZOLogger.info("Project Zomboid Build 42 - Config & Engine Optimizer (PZO)");
        PZOLogger.info("Version: " + UpdateChecker.CURRENT_VERSION + " | Java Runtime: " + System.getProperty("java.version") + " (" + System.getProperty("os.name") + ")");
        PZOLogger.info("Log File: " + PZOLogger.getLogFilePath());
        PZOLogger.info("================================================================================");

        try {
            Runtime rt = Runtime.getRuntime();
            long maxMemMB = rt.maxMemory() / (1024 * 1024);
            int cores = rt.availableProcessors();
            PZOLogger.info(String.format("System Resources: %d CPU Cores | Max JVM Heap Allocated: %d MB", cores, maxMemMB));
        } catch (Throwable ignored) {}

        try {
            UpdateDialog.runDevDialogPreviews(args);
        } catch (Throwable t) {
            PZOLogger.warn("[PZO Dev] Dialog preview failed: " + t.getMessage());
        }

        if (IncompatibleModGuard.isPzOptimizationInstalled()) {
            IncompatibleModGuard.reportAndWarn();
            launchGame(args);
            return;
        }

        if (BenchmarkHarness.isStockBaselineRequested()) {
            PZOLogger.info("[PZO] Stock baseline benchmark run: no PZO patches or governors, harness only.");
            BenchmarkHarness.checkLaunchParams(args);
            EngineThreadGovernor.initializeBenchmarkOnly();
            launchGame(args);
            return;
        }

        System.setProperty("pzo.optimized", "true");
        System.setProperty("pzo.target", "Build42");
        LogSpamShield.initialize();
        WorldUpscalerGovernor.checkLaunchParams(args);
        BenchmarkHarness.checkLaunchParams(args);

        // Migrate ProjectZomboid64.json from older PZO releases (e.g. 0.8.2 -> 0.9.5)
        try {
            ZomboidConfigMigrator.checkAndMigrateCurrentInstallation(new File(".").getAbsoluteFile());
        } catch (Throwable ignored) {}

        boolean isNative = false;
        double timerMs = 15.6;
        try {
            isNative = PZONative.isLoaded();
            if (isNative) {
                timerMs = PZONative.getTimerResolution100ns() / 10000.0;
            }
        } catch (Throwable ignored) {}

        // Make the Zomboid user folders and write pzo_status.json to every Zomboid path I find
        try {
            TelemetryReporter.refreshDiscoveredDirectories(args);
            long maxMemMB = Runtime.getRuntime().maxMemory() / (1024 * 1024);
            int ramGb = Math.max(2, (int) Math.round(maxMemMB / 1024.0));
            String json = String.format("{\"optimized\":true,\"ram_gb\":%d,\"g1gc\":true,\"pretouch\":true,\"version\":\"%s\",\"native\":%s,\"timer_ms\":%.2f}",
                ramGb, UpdateChecker.CURRENT_VERSION, isNative ? "true" : "false", timerMs);
            TelemetryReporter.writeStatusFile(json);
            PZOLogger.info("Broadcast live engine status bridge across all user drives and cachedir paths (RAM: " + ramGb + "GB | Native: " + isNative + ")");
        } catch (Throwable ignored) {}

        HotSpotJITCompilerTuner.tuneRuntimeProperties();

        PZOEngineBridge.initialize();
        EngineFeaturesTuner.initializeEngineFeatures();
        EngineThreadGovernor.initialize();
        VehicleTravelOptimizer.initialize();
        FileSystemWhitelistShield.initialize();
        PopTemplateGuard.initialize();
        PopmanGovernor.initialize();
        RainAndWeatherOptimizer.initialize();
        WorldStreamerBooster.startDaemon();
        PZOFastMath.initialize();
        ZombieMathVectorizer.apply();
        SpatialBufferPool.initialize();
        HordeSpatialCuller.initialize();
        GenerationalHeapCleaner.startGovernor();
        AsyncEntityDistanceCache.initialize();
        EngineGLStateGovernor.initialize();
        EngineFramePacer.initialize();
        NativeDirectMemoryPool.initialize();
        FastBitwiseChunkIndexer.initialize();
        DirectBufferAllocatorGovernor.initialize();
        FrameDropDiagnosticEngine.initialize();
        VerticalChunkStreamer.initialize();
        ChunkIngestionPacer.initialize();
        PredictiveChunkStreamer.initialize();
        ContainerConfiguratorGuard.initialize();
        ContainerEventGovernor.initialize();
        DiskIOPacer.initialize();
        com.pzoptimizer.multicore.PZOMultiCoreEngine.initialize();
        if (UnstableChannelGuard.isUnstableBuild()) {
            PZOLogger.success("[PZO Unstable Engine] Phase 3 SIMD AVX2 Batch Horde Spatial Culler & Skeletal LOD Armed");
            PZOLogger.success("[PZO Unstable Engine] RenderFrustumCuller, ZOcclusionCuller & ModelSkinningGovernor Armed");
            PZOLogger.success("[PZO Unstable Engine] EnhancedRenderTelemetry Active");
        }
        PowerThrottlingShield.apply();
        LuaInterpreterAccelerator.apply();
        FastPathCache.normalize("media/textures");
        LogRotationGuard.checkAndRotateLogs();
        NettyBufferPooler.apply();
        DirectMemoryTuner.initialize();
        ThreadPoolTuner.initialize();
        DriverOptimizer.initialize();
        AssetCachePrewarmer.startPrewarmingAsync();
        // Pull the native libs into the page cache and turn off LWJGL's vertex array bounds checks
        NativeLibraryPreloader.startPreloadingAsync();
        SpriteBatchOptimizer.apply();

        try {
            StreamBufferBooster.applyStreamTweaks();
            SaveGameStreamBooster.tuneSaveEngine();
            PZOLogger.success("StreamBufferBooster & SaveGameStreamBooster active (128KB I/O chunks & NIO caches)");
        } catch (Throwable t) {
            PZOLogger.warn("Non-fatal notice on StreamBufferBooster: " + t.getMessage());
        }


        try {
            FastMath.sin(0.5f);
            VectorPool.get(0, 0);
            PZOLogger.success("FastMath & VectorPool zero-allocation caches initialized");
        } catch (Throwable t) {
            PZOLogger.warn("Non-fatal notice on FastMath / VectorPool: " + t.getMessage());
        }

        try {
            GLStateOptimizer.resetState();
            PZOLogger.success("GLStateOptimizer & HordePhysicsOptimizer ready");
        } catch (Throwable t) {
            PZOLogger.warn("Non-fatal notice on GLState / HordePhysics: " + t.getMessage());
        }

        try {
            PZOLogger.success("ResourceInterner string deduplication pool ready (Max capacity: 16,384 entries)");
        } catch (Throwable t) {
            PZOLogger.warn("Non-fatal notice on ResourceInterner: " + t.getMessage());
        }

        boolean fullUpdateHandled = false;
        String resolvedNativeUrl = null;
        try {
            UpdateChecker.UpdateResult ur = UpdateChecker.checkForUpdatesSync(2500);
            if (ur != null) {
                resolvedNativeUrl = ur.dllDownloadUrl;
                if (ur.hasUpdate) {
                    PZOLogger.info("New update detected (v" + ur.latestVersion + "). Opening Pre-Menu update prompt...");
                    fullUpdateHandled = UpdateDialog.promptIfUpdateAvailable(ur.latestVersion, ur.downloadUrl, ur.dllDownloadUrl);
                }
            }
        } catch (Throwable t) {
            PZOLogger.warn("Non-fatal notice on Pre-Menu update checker: " + t.getMessage());
        }

        // Check the native library's version
        if (!fullUpdateHandled) {
            try {
                UpdateDialog.checkAndPromptNativeMismatch(resolvedNativeUrl);
            } catch (Throwable t) {
                PZOLogger.warn("Non-fatal notice on Native Governor version verification: " + t.getMessage());
            }
        }

        try {
            Thread.currentThread().setPriority(Thread.NORM_PRIORITY);
        } catch (Throwable ignored) {}

        Thread watchdog = new Thread(() -> {
            while (true) {
                try {
                    Thread.sleep(5000);
                    TelemetryReporter.updateTelemetry();
                } catch (InterruptedException e) {
                    break;
                } catch (Throwable ignored) {}
            }
        });
        watchdog.setDaemon(true);
        watchdog.setPriority(Thread.NORM_PRIORITY - 1);
        watchdog.setName("PZO-B42-Telemetry");
        watchdog.start();
        PZOLogger.success("PZO-B42-Telemetry monitoring started");

        try {
            boolean zbDetected = false;
            File currentDir = new File(".").getAbsoluteFile();
            File zbJar = new File(currentDir, "ZombieBuddy.jar");
            File zbDll1 = new File(currentDir, "win64/zbNative.dll");
            File zbDll2 = new File(currentDir, "zbNative.dll");
            File zbSo = new File(currentDir, "linux64/libzbNative.so");
            File zbDylib = new File(currentDir, "libzbNative.dylib");

            if (zbJar.exists() || zbDll1.exists() || zbDll2.exists() || zbSo.exists() || zbDylib.exists()) {
                zbDetected = true;
            }

            if (zbDetected) {
                PZOLogger.success("[PZO Coexistence] ZombieBuddy framework detected and running in tandem with PZO Optimizer!");
            } else {
                PZOLogger.info("[PZO Engine] Running in Standalone Optimization Mode");
            }

            if (JavaModLoader.isConflictingFpsModDetected()) {
                PZOLogger.info("[PZO Mod Compatibility] Redundant FPS bytecode mod detected and safely isolated.");
                PZOLogger.info("[PZO Mod Compatibility] ZombieBuddy framework, custom Java mods, and all Workshop Lua mods are running with 100% full compatibility.");
            }
        } catch (Throwable t) {
            PZOLogger.warn("[PZO] Non-fatal notice on coexistence check: " + t.getMessage());
        }

        launchGame(args);
    }

    private static void launchGame(String[] args) {
        PZOLogger.info("Handing execution over to Project Zomboid entrypoint (zombie.gameStates.MainScreenState)...");
        try {
            Class<?> mainClass = Class.forName("zombie.gameStates.MainScreenState");
            Method mainMethod = mainClass.getMethod("main", String[].class);
            mainMethod.invoke(null, (Object) args);
        } catch (Throwable t) {
            Throwable cause = t.getCause() != null ? t.getCause() : t;
            PZOLogger.error("CRITICAL FATAL: Failed launching zombie.gameStates.MainScreenState.main", cause);
            cause.printStackTrace();
        }
    }

    private static final java.util.Set<String> BROWSER_HOSTS = java.util.Set.of(
        "github.com", "steamcommunity.com", "store.steampowered.com");

    // Lua can reach this, and rundll32 FileProtocolHandler will happily launch local files, so only plain https links
    // to known hosts get through
    static boolean isAllowedBrowserUrl(String url) {
        try {
            java.net.URI uri = new java.net.URI(url.trim());
            String host = uri.getHost();
            return "https".equalsIgnoreCase(uri.getScheme()) && uri.getRawUserInfo() == null
                && host != null && BROWSER_HOSTS.contains(host.toLowerCase(java.util.Locale.ROOT))
                && (uri.getPort() == -1 || uri.getPort() == 443);
        } catch (Throwable t) {
            return false;
        }
    }

    public static void openBrowser(String url) {
        if (url == null || url.trim().isEmpty()) return;
        if (!isAllowedBrowserUrl(url)) {
            PZOLogger.warn("[PZO] Refused to open non-allowlisted URL: " + url);
            return;
        }
        url = url.trim();
        try {
            if (java.awt.Desktop.isDesktopSupported() && java.awt.Desktop.getDesktop().isSupported(java.awt.Desktop.Action.BROWSE)) {
                java.awt.Desktop.getDesktop().browse(new java.net.URI(url));
                return;
            }
        } catch (Throwable ignored) {}

        try {
            String os = System.getProperty("os.name", "").toLowerCase();
            if (os.contains("win")) {
                Runtime.getRuntime().exec(new String[]{"rundll32", "url.dll,FileProtocolHandler", url});
            } else if (os.contains("mac")) {
                Runtime.getRuntime().exec(new String[]{"open", url});
            } else {
                Runtime.getRuntime().exec(new String[]{"xdg-open", url});
            }
        } catch (Throwable ignored) {}
    }
}
