package com.pzoptimizer;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentLinkedQueue;

/** Caps how much chunk integration the main thread does per frame. A B42 chunk is 2,048 squares (32 levels). */
public final class ChunkIngestionPacer {

    private static volatile boolean active = false;
    private static volatile boolean pacerInstalled = false;
    // Set if this game build doesn't have the fields I hook; otherwise the daemon retries every second
    private static volatile boolean pacerUnavailable = false;
    private static volatile boolean pacerWarned = false;

    // 3.5 ms per frame
    public static final long FRAME_BUDGET_NANOS = 3_500_000L;
    public static final int MAX_CHUNKS_PER_FRAME = 3;
    private static volatile int chunkBudgetMs = 6;

    public static void setChunkBudgetMs(int ms) {
        chunkBudgetMs = Math.max(1, Math.min(32, ms));
    }

    public static int getChunkBudgetMs() {
        return chunkBudgetMs;
    }

    public static void initialize() {
        if (active) return;
        active = true;

        try {
            installPacer();
            upgradeChunkMapLock();
            installShutdownHook();
        } catch (Throwable t) {
            PZOLogger.warn("ChunkIngestionPacer initialization notice: " + t.getMessage());
        }
    }

    public static synchronized boolean installPacer() {
        upgradeChunkMapLock();
        if (pacerInstalled) return true;
        if (pacerUnavailable) return false;

        try {
            Class<?> chunkClass = Class.forName("zombie.iso.IsoChunk");
            Field loadGridField = chunkClass.getField("loadGridSquare");
            Object cappedQueue = loadGridField.get(null);

            if (cappedQueue == null) return false;

            Field innerQField = cappedQueue.getClass().getDeclaredField("queue");
            innerQField.setAccessible(true);
            Object origQ = innerQField.get(cappedQueue);

            if (origQ instanceof PacedConcurrentQueue) {
                pacerInstalled = true;
                return true;
            }

            if (origQ instanceof ConcurrentLinkedQueue) {
                @SuppressWarnings("unchecked")
                ConcurrentLinkedQueue<Object> typedQ = (ConcurrentLinkedQueue<Object>) origQ;
                PacedConcurrentQueue pacedQ = new PacedConcurrentQueue(typedQ);
                innerQField.set(cappedQueue, pacedQ);
                pacerInstalled = true;
                PZOLogger.success("ChunkIngestionPacer: Active (Frame-Budgeted Chunk Integration Governor Armed)");
                return true;
            }

            pacerUnavailable = true;
            PZOLogger.warn("ChunkIngestionPacer disabled: unexpected loadGridSquare queue type " + (origQ == null ? "null" : origQ.getClass().getName()));
        } catch (NoSuchFieldException | ClassCastException e) {
            pacerUnavailable = true;
            PZOLogger.warn("ChunkIngestionPacer disabled: incompatible game build (" + e + ")");
        } catch (Throwable t) {
            if (!pacerWarned) {
                pacerWarned = true;
                PZOLogger.warn("ChunkIngestionPacer install notice (retrying quietly): " + t);
            }
        }
        return false;
    }

    private static volatile boolean lockUpgraded = false;

    public static void upgradeChunkMapLock() {
        if (lockUpgraded) return;
        try {
            Field theUnsafe = sun.misc.Unsafe.class.getDeclaredField("theUnsafe");
            theUnsafe.setAccessible(true);
            sun.misc.Unsafe u = (sun.misc.Unsafe) theUnsafe.get(null);

            Class<?> chunkMapClass = Class.forName("zombie.iso.IsoChunkMap");
            Field lockField = chunkMapClass.getDeclaredField("bSettingChunk");
            Object base = u.staticFieldBase(lockField);
            long offset = u.staticFieldOffset(lockField);

            java.util.concurrent.locks.ReentrantLock oldLock = (java.util.concurrent.locks.ReentrantLock) u.getObject(base, offset);
            if (oldLock != null && oldLock.isFair()) {
                u.putObject(base, offset, new java.util.concurrent.locks.ReentrantLock(false));
                lockUpgraded = true;
                PZOLogger.success("[ChunkIngestionPacer] Upgraded IsoChunkMap.bSettingChunk to high-throughput unfair ReentrantLock (0ms kernel contention)");
            } else if (oldLock != null && !oldLock.isFair()) {
                lockUpgraded = true;
            }
        } catch (Throwable t) {
            // IsoChunkMap isn't loaded yet, try again next check
        }
    }

    private static volatile boolean shutdownHookInstalled = false;

    private static void installShutdownHook() {
        if (shutdownHookInstalled) return;
        shutdownHookInstalled = true;
        try {
            Runtime.getRuntime().addShutdownHook(new Thread(() -> {
                flushAllUnloads();
            }, "PZO-ShutdownChunkFlusher"));
        } catch (Throwable ignored) {}
    }

    public static boolean isPacerInstalled() {
        return pacerInstalled;
    }

    public static boolean isPacerSettled() {
        return pacerInstalled || pacerUnavailable;
    }

    public static void onFrameBoundary(int frameCount) {
        processPendingUnloads();
        PacedConcurrentQueue.onFrameBoundary(frameCount);
    }

    private static volatile int lastUnloadFrameCount = -1;

    /**
     * Spreads out tearing down the orphaned chunks left in IsoChunkMap.SharedChunks. Vanilla tears down the ~13
     * trailing chunks of a boundary crossing in one frame (50-80 ms at driving speed). With the Up/Down/Left/Right
     * patch the shift itself is cheap and those chunks stay in SharedChunks, so I unload one per frame on frames that
     * didn't ingest anything.
     */
    public static boolean isPlayerDriving() {
        return PacedConcurrentQueue.isPlayerDriving();
    }

    public static void processPendingUnloads() {
        if (isEngineLoading()) return;
        if (isPlayerDriving()) return; // no unloading while driving, it leaves collision/mesh gaps

        try {
            if (zombie.iso.IsoWorld.instance == null || zombie.iso.IsoWorld.instance.currentCell == null) return;
            if (zombie.iso.IsoChunkMap.SharedChunks == null || zombie.iso.IsoChunkMap.SharedChunks.isEmpty()) return;
            if (zombie.iso.IsoChunkMap.bSettingChunk == null) return;

            int currentFrame = -1;
            try {
                if (zombie.iso.IsoCamera.frameState != null) {
                    currentFrame = zombie.iso.IsoCamera.frameState.frameCount;
                }
            } catch (Throwable ignored) {}

            if (currentFrame != -1 && currentFrame == lastUnloadFrameCount) {
                return; // already done this tick
            }
            lastUnloadFrameCount = currentFrame;

            // tryLock: just skip this tick if bSettingChunk is held
            if (!zombie.iso.IsoChunkMap.bSettingChunk.tryLock()) {
                return;
            }

            try {
                int totalShared = zombie.iso.IsoChunkMap.SharedChunks.size();
                if (totalShared <= 0) return;

                long now = System.nanoTime();
                int chunksIngested = PacedConcurrentQueue.getChunksIngestedThisFrame();
                int maxUnloads = (chunksIngested > 0) ? 1 : 2;
                long budgetNanos = (chunksIngested > 0) ? 1_500_000L : 2_500_000L;

                int unloadsThisFrame = 0;
                int checkedEntries = 0;
                var iterator = zombie.iso.IsoChunkMap.SharedChunks.entrySet().iterator();
                while (iterator.hasNext()) {
                    if (unloadsThisFrame >= maxUnloads || checkedEntries >= 16 || (System.nanoTime() - now) >= budgetNanos) {
                        break;
                    }

                    var entry = iterator.next();
                    checkedEntries++;
                    zombie.iso.IsoChunk chunk = entry.getValue();
                    if (chunk == null) {
                        iterator.remove();
                        continue;
                    }

                    // Orphaned = no longer referenced by any player's IsoChunkMap
                    if (chunk.refs == null || chunk.refs.isEmpty()) {
                        if (ChunkRetentionRing.isRetained(chunk.wx, chunk.wy)) {
                            continue;
                        }
                        iterator.remove();
                        if (chunk.loaded) {
                            try {
                                chunk.removeFromWorld();
                                if (zombie.iso.ChunkSaveWorker.instance != null) {
                                    zombie.iso.ChunkSaveWorker.instance.Add(chunk);
                                }
                            } catch (Throwable t) {
                            }
                        }
                        unloadsThisFrame++;
                        break; // one chunk per slack frame
                    }
                }
            } finally {
                zombie.iso.IsoChunkMap.bSettingChunk.unlock();
            }
        } catch (Throwable ignored) {}
    }

    /** Drops every orphaned chunk in SharedChunks right away (shutdown, cell unloads). */
    public static void flushAllUnloads() {
        try {
            if (zombie.iso.IsoChunkMap.SharedChunks == null || zombie.iso.IsoChunkMap.SharedChunks.isEmpty()) return;
            if (zombie.iso.IsoChunkMap.bSettingChunk != null) {
                zombie.iso.IsoChunkMap.bSettingChunk.lock();
            }
            try {
                var iterator = zombie.iso.IsoChunkMap.SharedChunks.entrySet().iterator();
                while (iterator.hasNext()) {
                    var entry = iterator.next();
                    zombie.iso.IsoChunk chunk = entry.getValue();
                    if (chunk == null) {
                        iterator.remove();
                        continue;
                    }
                    if (chunk.refs == null || chunk.refs.isEmpty()) {
                        iterator.remove();
                        if (chunk.loaded) {
                            try {
                                chunk.removeFromWorld();
                                if (zombie.iso.ChunkSaveWorker.instance != null) {
                                    zombie.iso.ChunkSaveWorker.instance.Add(chunk);
                                }
                            } catch (Throwable ignored) {}
                        }
                    }
                }
            } finally {
                if (zombie.iso.IsoChunkMap.bSettingChunk != null && zombie.iso.IsoChunkMap.bSettingChunk.isHeldByCurrentThread()) {
                    zombie.iso.IsoChunkMap.bSettingChunk.unlock();
                }
            }
        } catch (Throwable ignored) {}
    }

    public static boolean isEngineLoading() {
        try {
            return zombie.gameStates.IngameState.loading;
        } catch (Throwable ignored) {
            return false;
        }
    }

    /** ConcurrentLinkedQueue that meters poll() calls on the main thread. */
    public static final class PacedConcurrentQueue extends ConcurrentLinkedQueue<Object> {
        private static final long serialVersionUID = 42L;

        private static volatile long lastFrameCount = -1;
        private static volatile long frameStartTime = 0;
        private static volatile int chunksThisFrame = 0;
        // Budget runs from the first chunk taken this frame. Counting from the frame start used it up on busy frames
        // before any chunk came in, so only the one guaranteed chunk got through and driving outran loading.
        private static volatile long ingestStartTime = 0;
        private static volatile long lastDrivingCheckTime = 0;
        private static volatile boolean playerIsDriving = false;

        private final java.util.concurrent.atomic.AtomicInteger approximateSize = new java.util.concurrent.atomic.AtomicInteger(0);

        public PacedConcurrentQueue(ConcurrentLinkedQueue<Object> existing) {
            super();
            if (existing != null && !existing.isEmpty()) {
                this.addAll(existing);
                this.approximateSize.set(existing.size());
            }
        }

        @Override
        public boolean add(Object e) {
            boolean added = super.add(e);
            if (added) approximateSize.incrementAndGet();
            return added;
        }

        @Override
        public boolean offer(Object e) {
            boolean offered = super.offer(e);
            if (offered) approximateSize.incrementAndGet();
            return offered;
        }

        @Override
        public void clear() {
            super.clear();
            approximateSize.set(0);
        }

        @Override
        public int size() {
            return Math.max(0, approximateSize.get());
        }

        @Override
        public boolean isEmpty() {
            return approximateSize.get() <= 0;
        }

        @Override
        public boolean remove(Object o) {
            boolean removed = super.remove(o);
            if (removed) approximateSize.decrementAndGet();
            return removed;
        }

        public static boolean isPlayerDriving() {
            long now = System.currentTimeMillis();
            if (now - lastDrivingCheckTime < 100L) {
                return playerIsDriving;
            }
            lastDrivingCheckTime = now;
            try {
                zombie.characters.IsoPlayer player = zombie.characters.IsoPlayer.getInstance();
                if (player != null) {
                    playerIsDriving = (player.getVehicle() != null);
                    return playerIsDriving;
                }
            } catch (Throwable ignored) {}
            playerIsDriving = false;
            return false;
        }

        public static int getChunksIngestedThisFrame() {
            return chunksThisFrame;
        }

        public static void onFrameBoundary(int frameCount) {
            if (frameCount != lastFrameCount) {
                lastFrameCount = frameCount;
                chunksThisFrame = 0;
                frameStartTime = System.nanoTime();
            }
        }

        private static void checkFrameBoundary(long now) {
            try {
                if (zombie.iso.IsoCamera.frameState != null) {
                    int fc = zombie.iso.IsoCamera.frameState.frameCount;
                    if (fc != lastFrameCount) {
                        lastFrameCount = fc;
                        chunksThisFrame = 0;
                        frameStartTime = now;
                        return;
                    }
                }
            } catch (Throwable ignored) {}

            // Only reset after a gap over 500 ms (debugger pause, external stall). Resetting on smaller gaps shoved the
            // next chunks into the same frame.
            if (now - frameStartTime > 500_000_000L) {
                frameStartTime = now;
                chunksThisFrame = 0;
            }
        }

        @Override
        public Object poll() {
            // Background callers (WorldStreamer, WorldReuser) aren't metered
            String threadName = Thread.currentThread().getName();
            if (threadName != null && (threadName.contains("WorldStreamer") || threadName.contains("Reuser"))) {
                Object chunk = super.poll();
                if (chunk != null) approximateSize.decrementAndGet();
                return chunk;
            }

            // No limit while loading (boot, teleports, cell loads)
            if (isEngineLoading()) {
                Object chunk = super.poll();
                if (chunk != null) approximateSize.decrementAndGet();
                return chunk;
            }

            long now = System.nanoTime();

            checkFrameBoundary(now);

            // Driving across a chunk boundary needs 13-26 chunks, so take up to 32 under a 12 ms ceiling. Any lower and
            // the car outruns ingestion onto missing floor.
            boolean driving = isPlayerDriving();
            int backlog = approximateSize.get();
            int maxChunks;
            long budgetNanos;

            long baseBudgetNanos = chunkBudgetMs * 1_000_000L;
            if (driving) {
                maxChunks = Math.max(32, backlog);
                budgetNanos = Math.max(baseBudgetNanos * 2, 12_000_000L);
            } else {
                maxChunks = (backlog > 8) ? 8 : 4;
                budgetNanos = baseBudgetNanos;
            }

            if (chunksThisFrame > 0 && (chunksThisFrame >= maxChunks || (now - ingestStartTime) >= budgetNanos)) {
                // Out of budget, the rest goes next frame
                return null;
            }

            Object chunk = super.poll();
            if (chunk != null) {
                approximateSize.decrementAndGet();
                if (chunksThisFrame == 0) ingestStartTime = now;
                chunksThisFrame++;
            }
            return chunk;
        }

        private boolean isEngineLoading() {
            try {
                return zombie.gameStates.IngameState.loading;
            } catch (Throwable ignored) {
                return false;
            }
        }
    }
}
