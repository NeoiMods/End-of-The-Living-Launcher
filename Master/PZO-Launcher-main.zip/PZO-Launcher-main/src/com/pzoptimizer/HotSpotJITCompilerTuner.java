package com.pzoptimizer;

/** JIT and runtime properties sized to the core count. */
public class HotSpotJITCompilerTuner {

    public static void tuneRuntimeProperties() {
        try {
            int cores = CpuTopologyGovernor.getOptimalWorkerCount();
            
            int targetParallelism = Math.max(2, Math.min(16, cores));
            System.setProperty("java.util.concurrent.ForkJoinPool.common.parallelism", String.valueOf(targetParallelism));
            System.setProperty("jdk.virtualThreadScheduler.parallelism", String.valueOf(targetParallelism));
            
            System.setProperty("sun.java2d.opengl", "true");
            System.setProperty("sun.java2d.d3d", "false");
            System.setProperty("sun.java2d.noddraw", "true");
            
            System.setProperty("sun.io.useCanonCaches", "true");
            System.setProperty("sun.io.useCanonPrefixCache", "true");
            
            System.setProperty("java.security.egd", "file:/dev/urandom");

            WorkerRandGovernor.ensureInstalled();

            PZOLogger.info("HotSpotJITCompilerTuner: Runtime properties configured for " + cores + " optimal worker cores (Hybrid CPU: " + CpuTopologyGovernor.IS_HYBRID_CPU + ")");
        } catch (Throwable ignored) {}
    }
}
