package com.pzoptimizer;

import java.io.File;
import java.nio.file.Files;

/** Persistent preferences (beta opt-in, ignored versions, Java mod approvals) in pzo_config.json. */
public final class PZOConfig {
    private static final String CONFIG_FILE = "pzo_config.json";
    public static final String CURRENT_NOTICE_VERSION = "1.9.5";
    private static volatile boolean betaOptIn = false;
    private static volatile String ignoredVersion = "";
    private static volatile boolean isolateConflictingFpsMods = true;
    private static volatile String multithreadingNoticeAckVersion = "";
    private static volatile String viewpointStanddownMode = "AUTO";
    private static volatile boolean javaModsEnabled = true;
    private static volatile boolean fsrEnabled = false;
    private static volatile boolean powerShieldEnabled = true;
    private static volatile boolean luaCompileCache = true;
    private static volatile boolean fastLoad = true;
    // Set when I added the Windows "High performance" GPU preference, so I know I can take it out again
    private static volatile boolean gpuPrefWritten = false;
    // Loading features that kick in before the Lua settings arrive, so they're read at launch
    private static volatile boolean textureHandoff = true;
    // The sprite ring is created with the window, before the Lua settings arrive
    private static volatile boolean persistentSpriteVbo = true;
    private static volatile boolean depthMapParallel = true;
    private static volatile boolean animImportCache = true;
    // Off only for running the Java engine without the Lua mod on purpose, see LuaModGuard
    private static volatile boolean requireLuaMod = true;
    // Testing aid: "key=value;..." merged over HardwareProbe's real values, "" for the real hardware
    private static volatile String hardwareOverride = "";
    // "auto", "on" or "off": compatibility mode for older PCs, see CompatMode
    private static volatile String compatMode = "auto";
    private static final java.util.Set<String> approvedJavaMods = new java.util.LinkedHashSet<>();
    private static final java.util.Set<String> blockedJavaMods = new java.util.LinkedHashSet<>();
    private static volatile boolean loaded = false;

    public static synchronized void load() {
        if (loaded) return;
        loaded = true;
        try {
            File cfg = getConfigFile();
            if (cfg.exists()) {
                String content = Files.readString(cfg.toPath());
                betaOptIn = content.contains("\"beta_opt_in\":true") || content.contains("\"beta_opt_in\": true") || content.contains("\"beta_opt_in\":1");
                ignoredVersion = extractJsonField(content, "ignored_version");
                if (ignoredVersion == null) ignoredVersion = "";
                multithreadingNoticeAckVersion = extractJsonField(content, "multithreading_notice_ack_version");
                if (multithreadingNoticeAckVersion == null) multithreadingNoticeAckVersion = "";
                if (multithreadingNoticeAckVersion.isEmpty() && (content.contains("\"multithreading_notice_ack\":true") || content.contains("\"multithreading_notice_ack\": true"))) {
                    multithreadingNoticeAckVersion = CURRENT_NOTICE_VERSION;
                }
                if (content.contains("\"isolate_conflicting_fps_mods\":false") || content.contains("\"isolate_conflicting_fps_mods\": false") || content.contains("\"isolate_conflicting_fps_mods\":0")) {
                    isolateConflictingFpsMods = false;
                } else {
                    isolateConflictingFpsMods = true;
                }
                String vpMode = extractJsonField(content, "viewpoint_standdown_mode");
                if (vpMode != null && !vpMode.isEmpty()) {
                    viewpointStanddownMode = vpMode.toUpperCase();
                } else {
                    viewpointStanddownMode = "AUTO";
                }
                javaModsEnabled = !(content.contains("\"java_mods_enabled\":false") || content.contains("\"java_mods_enabled\": false"));
                fsrEnabled = content.contains("\"fsr_enabled\":true") || content.contains("\"fsr_enabled\": true");
                powerShieldEnabled = !(content.contains("\"power_shield\":false") || content.contains("\"power_shield\": false"));
                luaCompileCache = !(content.contains("\"lua_compile_cache\":false") || content.contains("\"lua_compile_cache\": false"));
                fastLoad = !(content.contains("\"fast_load\":false") || content.contains("\"fast_load\": false"));
                textureHandoff = !(content.contains("\"texture_handoff\":false") || content.contains("\"texture_handoff\": false"));
                persistentSpriteVbo = !(content.contains("\"persistent_sprite_vbo\":false") || content.contains("\"persistent_sprite_vbo\": false"));
                depthMapParallel = !(content.contains("\"depth_map_parallel\":false") || content.contains("\"depth_map_parallel\": false"));
                animImportCache = !(content.contains("\"anim_import_cache\":false") || content.contains("\"anim_import_cache\": false"));
                requireLuaMod = !(content.contains("\"require_lua_mod\":false") || content.contains("\"require_lua_mod\": false"));
                gpuPrefWritten = content.contains("\"gpu_pref_written\":true") || content.contains("\"gpu_pref_written\": true");
                String hw = extractJsonField(content, "hardware_override");
                hardwareOverride = hw == null ? "" : hw;
                String cm = extractJsonField(content, "compat_mode");
                compatMode = ("on".equalsIgnoreCase(cm) || "off".equalsIgnoreCase(cm)) ? cm.toLowerCase() : "auto";
                parseHashList(extractJsonField(content, "approved_java_mods"), approvedJavaMods);
                parseHashList(extractJsonField(content, "blocked_java_mods"), blockedJavaMods);
            }
        } catch (Throwable ignored) {}
    }

    public static synchronized void save() {
        try {
            File cfg = getConfigFile();
            String json = String.format("{\"beta_opt_in\":%b,\"ignored_version\":\"%s\",\"isolate_conflicting_fps_mods\":%b,\"multithreading_notice_ack_version\":\"%s\",\"viewpoint_standdown_mode\":\"%s\",\"java_mods_enabled\":%b,\"fsr_enabled\":%b,\"power_shield\":%b,\"lua_compile_cache\":%b,\"fast_load\":%b,\"gpu_pref_written\":%b,\"texture_handoff\":%b,\"depth_map_parallel\":%b,\"anim_import_cache\":%b,\"persistent_sprite_vbo\":%b,\"require_lua_mod\":%b,\"hardware_override\":\"%s\",\"compat_mode\":\"%s\",\"approved_java_mods\":\"%s\",\"blocked_java_mods\":\"%s\"}",
                betaOptIn, ignoredVersion != null ? ignoredVersion : "", isolateConflictingFpsMods,
                multithreadingNoticeAckVersion != null ? multithreadingNoticeAckVersion : "",
                viewpointStanddownMode != null ? viewpointStanddownMode : "AUTO",
                javaModsEnabled, fsrEnabled, powerShieldEnabled, luaCompileCache, fastLoad, gpuPrefWritten, textureHandoff, depthMapParallel, animImportCache, persistentSpriteVbo, requireLuaMod, hardwareOverride.replace("\"", "").replace("\\", ""), compatMode, String.join(",", approvedJavaMods), String.join(",", blockedJavaMods));
            Files.writeString(cfg.toPath(), json);
        } catch (Throwable ignored) {}
    }

    public static boolean isBetaOptIn() {
        load();
        if (betaOptIn) return true;

        if (UpdateChecker.isUnstableIdentifier(UpdateChecker.CURRENT_VERSION)) {
            return true;
        }

        try {
            Class<?> coreClass = Class.forName("zombie.core.Core");
            java.lang.reflect.Method getInst = coreClass.getMethod("getInstance");
            Object core = getInst.invoke(null);
            if (core != null) {
                java.lang.reflect.Method getVer = coreClass.getMethod("getVersionNumber");
                Object verObj = getVer.invoke(core);
                if (verObj != null) {
                    String verStr = verObj.toString().toLowerCase();
                    if (verStr.contains("unstable") || verStr.contains("beta")) {
                        return true;
                    }
                }
            }
        } catch (Throwable ignored) {}

        String steamBranch = System.getProperty("zomboid.steam");
        if (steamBranch != null && (steamBranch.toLowerCase().contains("unstable") || steamBranch.toLowerCase().contains("beta"))) {
            return true;
        }

        return false;
    }

    public static void setBetaOptIn(boolean optIn) {
        load();
        betaOptIn = optIn;
        save();
        PZOLogger.info("[PZO Config] Beta/Unstable build channel opt-in set to: " + optIn);
    }

    public static String getIgnoredVersion() {
        load();
        return ignoredVersion;
    }

    public static void setIgnoredVersion(String version) {
        load();
        ignoredVersion = version != null ? version : "";
        save();
    }

    public static boolean isVersionIgnored(String version) {
        load();
        return ignoredVersion != null && !ignoredVersion.isEmpty() && ignoredVersion.equalsIgnoreCase(version);
    }

    public static boolean isIsolateConflictingFpsMods() {
        load();
        return isolateConflictingFpsMods;
    }

    public static void setIsolateConflictingFpsMods(boolean isolate) {
        load();
        isolateConflictingFpsMods = isolate;
        save();
        PZOLogger.info("[PZO Config] Isolate conflicting FPS mods set to: " + isolate);
    }

    public static boolean isMultithreadingNoticeAcknowledged() {
        load();
        return CURRENT_NOTICE_VERSION.equals(multithreadingNoticeAckVersion);
    }

    public static void setMultithreadingNoticeAcknowledged(boolean ack) {
        load();
        multithreadingNoticeAckVersion = ack ? CURRENT_NOTICE_VERSION : "";
        save();
        PZOLogger.info("[PZO Config] Multithreading notice acknowledged set to: " + ack + " (" + multithreadingNoticeAckVersion + ")");
    }

    public static String getMultithreadingNoticeAckVersion() {
        load();
        return multithreadingNoticeAckVersion;
    }

    public static String getViewpointStanddownMode() {
        load();
        return viewpointStanddownMode != null ? viewpointStanddownMode : "AUTO";
    }

    public static void setViewpointStanddownMode(String mode) {
        load();
        viewpointStanddownMode = mode != null ? mode.toUpperCase() : "AUTO";
        save();
        PZOLogger.info("[PZO Config] Viewpoint standdown mode set to: " + viewpointStanddownMode);
    }

    public static boolean isJavaModsEnabled() {
        load();
        return javaModsEnabled;
    }

    public static synchronized void setJavaModsEnabled(boolean enabled) {
        load();
        if (javaModsEnabled == enabled) return;
        javaModsEnabled = enabled;
        save();
        PZOLogger.info("[PZO Config] Third-party Java mod loading set to: " + enabled + " (applies on next launch)");
    }

    /**
     * Kernel QoS (timer, power throttling exemption, MMCSS, priority). Applied at launch, so changes take effect next
     * time.
     */
    public static boolean isPowerShieldEnabled() {
        load();
        return powerShieldEnabled;
    }

    public static synchronized void setPowerShieldEnabled(boolean enabled) {
        load();
        if (powerShieldEnabled == enabled) return;
        powerShieldEnabled = enabled;
        save();
        PZOLogger.info("[PZO Config] CPU power shield set to: " + enabled + " (applies on next launch)");
    }

    /** Lua compile cache. Read at launch, before the Lua mod's settings exist. */
    public static boolean isLuaCompileCacheEnabled() {
        load();
        return luaCompileCache;
    }

    public static synchronized void setLuaCompileCacheEnabled(boolean enabled) {
        load();
        if (luaCompileCache == enabled) return;
        luaCompileCache = enabled;
        save();
        PZOLogger.info("[PZO Config] Lua compile cache set to: " + enabled + " (applies on next launch)");
    }

    /** Faster file and map loading (ScriptCommentStrip, MapLoadFixes). Read at launch. */
    public static boolean isFastLoadEnabled() {
        load();
        return fastLoad;
    }

    public static synchronized void setFastLoadEnabled(boolean enabled) {
        load();
        if (fastLoad == enabled) return;
        fastLoad = enabled;
        save();
        PZOLogger.info("[PZO Config] Faster file and map loading set to: " + enabled + " (applies on next launch)");
    }

    public static boolean isLuaModRequired() {
        load();
        return requireLuaMod;
    }

    public static boolean isPersistentSpriteVboEnabled() {
        load();
        return persistentSpriteVbo;
    }

    public static synchronized void setPersistentSpriteVboEnabled(boolean enabled) {
        load();
        if (persistentSpriteVbo == enabled) return;
        persistentSpriteVbo = enabled;
        save();
    }

    public static boolean isTextureHandoffEnabled() {
        load();
        return textureHandoff;
    }

    public static synchronized void setTextureHandoffEnabled(boolean enabled) {
        load();
        if (textureHandoff == enabled) return;
        textureHandoff = enabled;
        save();
    }

    public static boolean isDepthMapParallelEnabled() {
        load();
        return depthMapParallel;
    }

    public static synchronized void setDepthMapParallelEnabled(boolean enabled) {
        load();
        if (depthMapParallel == enabled) return;
        depthMapParallel = enabled;
        save();
    }

    public static boolean isAnimImportCacheEnabled() {
        load();
        return animImportCache;
    }

    public static synchronized void setAnimImportCacheEnabled(boolean enabled) {
        load();
        if (animImportCache == enabled) return;
        animImportCache = enabled;
        save();
        PZOLogger.info("[PZO Config] Imported animation cache set to: " + enabled + " (applies on next launch)");
    }

    public static boolean isGpuPrefWritten() {
        load();
        return gpuPrefWritten;
    }

    public static synchronized void setGpuPrefWritten(boolean written) {
        load();
        if (gpuPrefWritten == written) return;
        gpuPrefWritten = written;
        save();
    }

    public static String getHardwareOverride() {
        load();
        return hardwareOverride;
    }

    public static synchronized void setHardwareOverride(String summary) {
        load();
        hardwareOverride = summary == null ? "" : summary.trim();
        save();
        PZOLogger.info("[PZO Config] Hardware override: " + (hardwareOverride.isEmpty() ? "off (real hardware)" : hardwareOverride));
    }

    /** "auto", "on" or "off"; read once at launch by CompatMode. */
    public static String getCompatMode() {
        load();
        return compatMode;
    }

    public static synchronized void setCompatMode(String mode) {
        load();
        String m = ("on".equalsIgnoreCase(mode) || "off".equalsIgnoreCase(mode)) ? mode.toLowerCase() : "auto";
        if (m.equals(compatMode)) return;
        compatMode = m;
        save();
        PZOLogger.info("[PZO Config] Compatibility mode set to: " + m + " (applies on next launch)");
    }

    /** FSR world upscaling from the JAVA tab. Read at launch, since the render hooks go in before the game starts. */
    public static boolean isFsrEnabled() {
        load();
        return fsrEnabled;
    }

    public static synchronized void setFsrEnabled(boolean enabled) {
        load();
        if (fsrEnabled == enabled) return;
        fsrEnabled = enabled;
        save();
        PZOLogger.info("[PZO Config] FSR world upscaling set to: " + enabled);
    }

    /** "APPROVED", "BLOCKED", or null if the user hasn't decided on this jar hash yet. */
    public static synchronized String getJavaModDecision(String sha256) {
        load();
        if (approvedJavaMods.contains(sha256)) return "APPROVED";
        if (blockedJavaMods.contains(sha256)) return "BLOCKED";
        return null;
    }

    public static synchronized void setJavaModDecision(String sha256, boolean approved) {
        load();
        approvedJavaMods.remove(sha256);
        blockedJavaMods.remove(sha256);
        (approved ? approvedJavaMods : blockedJavaMods).add(sha256);
        save();
    }

    private static void parseHashList(String value, java.util.Set<String> dest) {
        if (value == null) return;
        for (String h : value.split(",")) {
            h = h.trim().toLowerCase();
            if (h.matches("[0-9a-f]{64}")) dest.add(h);
        }
    }

    private static String extractJsonField(String json, String fieldName) {
        String key = "\"" + fieldName + "\":";
        int idx = json.indexOf(key);
        if (idx == -1) return null;
        int start = json.indexOf("\"", idx + key.length());
        if (start == -1) return null;
        int end = json.indexOf("\"", start + 1);
        if (end == -1) return null;
        return json.substring(start + 1, end);
    }

    public static File getConfigFile() {
        File zDir = PZOEngineBridge.getZomboidDir();
        if (zDir != null && zDir.exists()) {
            File luaDir = new File(zDir, "Lua");
            if (!luaDir.exists()) luaDir.mkdirs();
            return new File(luaDir, CONFIG_FILE);
        }
        String userHome = System.getProperty("user.home");
        File luaDir = new File(userHome, "Zomboid" + File.separator + "Lua");
        if (!luaDir.exists()) luaDir.mkdirs();
        return new File(luaDir, CONFIG_FILE);
    }

    public static boolean isMobileZomdroid() {
        return EngineGLStateGovernor.isMobileGLEnvironment();
    }
}
