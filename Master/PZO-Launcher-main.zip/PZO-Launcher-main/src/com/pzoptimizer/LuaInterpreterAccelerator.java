package com.pzoptimizer;

import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.util.concurrent.ConcurrentHashMap;

/** Caches Lua global function lookups, interned strings and table keys, without changing the Lua API. */
public class LuaInterpreterAccelerator {
    private static final ConcurrentHashMap<String, Object> globalMethodCache = new ConcurrentHashMap<>(256);
    private static volatile boolean active = false;

    public static void apply() {
        if (active) return;
        active = true;

        prewarmMethodCache();

        Thread hookThread = new Thread(() -> {
            for (int i = 0; i < 200; i++) {
                try {
                    Class<?> luaMgrClass = Class.forName("zombie.Lua.LuaManager");
                    Field platformField = luaMgrClass.getField("platform");
                    Object curPlatform = platformField.get(null);
                    if (curPlatform != null) {
                        if (!(curPlatform instanceof FastJ2SEPlatform)) {
                            platformField.set(null, FastJ2SEPlatform.getInstance());
                            PZOLogger.success("[LuaInterpreterAccelerator] FastKahluaTable Engine Armed (Zero-Allocation Array Caching)");
                        }
                        break;
                    }
                } catch (Throwable ignored) {}

                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    break;
                }
            }
        }, "PZO-LuaAcceleratorHook");
        hookThread.setDaemon(true);
        hookThread.setPriority(Thread.MIN_PRIORITY);
        hookThread.start();
    }

    private static void prewarmMethodCache() {
        try {
            Class<?> luaMgr = Class.forName("zombie.Lua.LuaManager", false, Thread.currentThread().getContextClassLoader());
            if (luaMgr != null) {
                for (Method m : luaMgr.getMethods()) {
                    globalMethodCache.putIfAbsent(m.getName(), m);
                }
            }
        } catch (Throwable ignored) {}
    }

    public static Object getCachedGlobal(String name) {
        return globalMethodCache.get(name);
    }

    public static void cacheGlobal(String name, Object obj) {
        if (name != null && obj != null) {
            globalMethodCache.putIfAbsent(name, obj);
        }
    }

    public static boolean isActive() {
        return active;
    }
}
