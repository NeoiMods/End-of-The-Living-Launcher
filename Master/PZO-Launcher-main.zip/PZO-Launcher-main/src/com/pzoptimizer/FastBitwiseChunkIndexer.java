package com.pzoptimizer;

/** Bit-packing helpers for chunk and meta-grid indices. */
public final class FastBitwiseChunkIndexer {

    public static void initialize() {
        PZOLogger.success("FastBitwiseChunkIndexer: 64-Bit Register Spatial Indexer Ready");
    }

    public static long packChunkKey(int chunkX, int chunkY) {
        return ((long) chunkX << 32) | (chunkY & 0xFFFFFFFFL);
    }

    public static int unpackChunkX(long key) {
        return (int) (key >>> 32);
    }

    public static int unpackChunkY(long key) {
        return (int) key;
    }

    public static long packTileKey(int x, int y, int z) {
        return ((long) (z & 0xFF) << 48) | ((long) (x & 0xFFFFFF) << 24) | (y & 0xFFFFFF);
    }

    /** Interleaves two 16-bit values into a 32-bit Morton code, so neighbouring tiles sit close together in memory. */
    public static int mortonEncode2D(int x, int y) {
        return (spreadBits(x & 0xFFFF)) | (spreadBits(y & 0xFFFF) << 1);
    }

    private static int spreadBits(int v) {
        v = (v | (v << 8)) & 0x00FF00FF;
        v = (v | (v << 4)) & 0x0F0F0F0F;
        v = (v | (v << 2)) & 0x33333333;
        v = (v | (v << 1)) & 0x55555555;
        return v;
    }
}
