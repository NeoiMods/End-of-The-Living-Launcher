package com.pzoptimizer.multicore;

import com.pzoptimizer.PZOLogger;
import com.pzoptimizer.PZONative;

import java.util.Locale;
import java.util.concurrent.*;
import java.util.concurrent.atomic.AtomicBoolean;
import java.util.concurrent.atomic.AtomicInteger;

/**
 * Creates the shared worker pool and starts the chunk streamer, horde governor, animation engine and island scheduler.
 */
public final class PZOMultiCoreEngine {

    private static final AtomicBoolean initialized = new AtomicBoolean(false);
    private static volatile boolean active = false;

    private static ExecutorService sharedWorkerPool;
    private static int workerCount = 4;

    public static synchronized void initialize() {
        if (initialized.get()) return;

        workerCount = com.pzoptimizer.CpuTopologyGovernor.getOptimalWorkerCount();

        sharedWorkerPool = Executors.newFixedThreadPool(workerCount, new ThreadFactory() {
            private final AtomicInteger counter = new AtomicInteger(1);
            @Override
            public Thread newThread(Runnable r) {
                Thread t = new com.pzoptimizer.WorkerRandGovernor.WorkerThread(r, "PZO-MultiCore-Worker-" + counter.getAndIncrement());
                t.setDaemon(true);
                t.setPriority(Thread.NORM_PRIORITY);
                return t;
            }
        });

        com.pzoptimizer.WorkerRandGovernor.ensureInstalled();
        MultiCoreChunkStreamer.initialize();
        MultiCoreHordeGovernor.initialize();
        MultiCoreAnimationEngine.initialize();

        initialized.set(true);
        active = true;

        PZOLogger.success(String.format(
            "================================================================================\n" +
            "[PZOMultiCoreEngine] TRUE MULTI-CORE ENGINE ARMED & OPERATIONAL\n" +
            "  - Dedicated Performance Workers: %d threads (Pinned P-Core Affinity)\n" +
            "  - Pillar 1: MultiCoreChunkStreamer (Parallel Decompression & 1MB NIO Ring)\n" +
            "  - Pillar 2: MultiCoreHordeGovernor (AVX2 SIMD Multi-Core Spatial Matrix)\n" +
            "  - Pillar 3: MultiCoreAnimationEngine (Thread-Safe Skeletal Animation & Off-Screen Skip)\n" +
            "================================================================================",
            workerCount
        ));
    }

    public static boolean isMultiCoreActive() {
        return active;
    }

    public static ExecutorService getExecutor() {
        return sharedWorkerPool;
    }

    public static int getWorkerCount() {
        return workerCount;
    }

    public static long getParallelChunksStreamed() {
        return MultiCoreChunkStreamer.getTotalChunksStreamed();
    }

    public static long getParallelHordeSweeps() {
        return MultiCoreHordeGovernor.totalParallelSweeps.get();
    }

    // The island scheduler never ran (simulation has to stay on the game thread) and is gone; kept for the Lua bridge
    public static long getParallelSimulatedEntities() {
        return 0L;
    }

    public static long getBonesSaved() {
        return MultiCoreAnimationEngine.getBoneTransformsBypassed();
    }

    public static long getPreloadedTrajectoryHits() {
        return com.pzoptimizer.PredictiveChunkStreamer.getPreloadedCacheHits();
    }

    public static String getTelemetryReport() {
        if (!active) {
            return "- **PZO Multi-Core Scaling**: Inactive\n";
        }

        StringBuilder sb = new StringBuilder();
        sb.append("#### PZO Multi-Core Scaling Architecture\n");
        sb.append(String.format(Locale.US, "- **Dedicated P-Core Workers**: %d Threads (Affinity Mask Active)\n", workerCount));
        sb.append(String.format(Locale.US, "- **Parallel Chunks Streamed**: %,d chunks (Saved: %,d ms I/O void latency | Trajectory Hits: %,d)\n",
            getParallelChunksStreamed(), MultiCoreChunkStreamer.getTotalStreamTimeSavedMs(), getPreloadedTrajectoryHits()));
        sb.append(String.format(Locale.US, "- **Multi-Core AVX2 Horde Sweeps**: %,d passes (Entities Tracked: %,d | In FOV: %,d | Culled: %,d)\n",
            getParallelHordeSweeps(), MultiCoreHordeGovernor.lastTrackedZombieCount.get(), MultiCoreHordeGovernor.getLastVisibleCount(), MultiCoreHordeGovernor.lastCulledOffscreenCount.get()));
        sb.append(String.format(Locale.US, "- **Skeletal Bone Transforms Bypassed**: %,d matrices (Adaptive 4-Tier LOD)\n",
            getBonesSaved()));
        return sb.toString();
    }

    public static void shutdown() {
        active = false;
        MultiCoreChunkStreamer.shutdown();
        MultiCoreHordeGovernor.shutdown();
        if (sharedWorkerPool != null) {
            sharedWorkerPool.shutdownNow();
        }
    }
}
