package com.pzoptimizer;

import java.io.File;
import java.io.FileInputStream;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.nio.ByteBuffer;
import java.nio.ByteOrder;
import java.util.HashSet;
import java.util.Set;

/** Watches how the player is moving (driving, sprinting, walking) and pre-reads chunk files ahead of them. */
public final class PredictiveChunkStreamer {

    private static volatile boolean running = false;
    private static Thread streamerThread = null;
    private static final Set<Long> PREWARMED_KEYS = java.util.concurrent.ConcurrentHashMap.newKeySet();
    private static final ThreadLocal<byte[]> PREWARM_IO_BUFFER = ThreadLocal.withInitial(() -> new byte[65536]);
    private static final java.util.concurrent.atomic.AtomicLong preloadedCacheHits = new java.util.concurrent.atomic.AtomicLong(0);
    private static final java.util.concurrent.atomic.AtomicLong preloadedChunksFetched = new java.util.concurrent.atomic.AtomicLong(0);
    private static final float CHUNK_WIDTH = 8.0f;

    private static volatile long lastPrewarmClearTime = 0;
    private static volatile Boolean isSolidState = null;

    public static boolean isStorageFast() {
        if (isSolidState != null) return isSolidState;
        try {
            String checkPath = System.getProperty("user.dir");
            if (checkPath == null || checkPath.isEmpty()) {
                checkPath = System.getProperty("user.home");
            }
            boolean fast = PZONative.isSolidStateDrive(checkPath);
            isSolidState = fast;
            if (fast) {
                PZOLogger.info("[PredictiveChunkStreamer] Fast Solid State Storage (NVMe/SSD) detected: Multi-vector trajectory lookahead active.");
            } else {
                PZOLogger.info("[PredictiveChunkStreamer] Mechanical Storage (HDD) detected: Adaptive sequential lookahead active (Head-thrashing protection armed).");
            }
            return fast;
        } catch (Throwable t) {
            isSolidState = true;
            return true;
        }
    }

    public static void initialize() {
        start();
    }

    public static void start() {
        if (running) return;
        running = true;

        streamerThread = new Thread(() -> {
            PZOLogger.success("PredictiveChunkStreamer: Active (Universal Multi-Modal Predictive Chunk Streaming Engine)");

            while (running) {
                try {
                    Thread.sleep(isStorageFast() ? 200 : 350); // 5 Hz on SSD/NVMe, 3 Hz on HDD

                    long now = System.currentTimeMillis();
                    if (now - lastPrewarmClearTime > 30_000L) {
                        PREWARMED_KEYS.clear();
                        lastPrewarmClearTime = now;
                    }

                    Class<?> playerClass = Class.forName("zombie.characters.IsoPlayer");
                    Method getInstMethod = playerClass.getMethod("getInstance");
                    Object player = getInstMethod.invoke(null);

                    if (player == null) {
                        Thread.sleep(600);
                        continue;
                    }

                    Method getXMethod = playerClass.getMethod("getX");
                    Method getYMethod = playerClass.getMethod("getY");
                    float px = ((Number) getXMethod.invoke(player)).floatValue();
                    float py = ((Number) getYMethod.invoke(player)).floatValue();

                    int currentChunkX = (int) Math.floor(px / CHUNK_WIDTH);
                    int currentChunkY = (int) Math.floor(py / CHUNK_WIDTH);
                    for (int dx = -1; dx <= 1; dx++) {
                        for (int dy = -1; dy <= 1; dy++) {
                            ChunkRetentionRing.touch(currentChunkX + dx, currentChunkY + dy);
                        }
                    }

                    Method getVehicleMethod = playerClass.getMethod("getVehicle");
                    Object vehicle = getVehicleMethod.invoke(player);

                    if (vehicle != null) {
                        handleVehicleStreaming(player, vehicle, px, py);
                    } else {
                        handleOnFootStreaming(playerClass, player, px, py);
                    }

                } catch (Throwable ignored) {
                    try { Thread.sleep(1000); } catch (Throwable ignored2) {}
                }
            }
        }, "PZO-PredictiveChunkStreamer");

        streamerThread.setDaemon(true);
        streamerThread.setPriority(Thread.NORM_PRIORITY - 1); // priority 4, never competes with gameplay or the WorldStreamer
        streamerThread.start();
    }

    private static void handleVehicleStreaming(Object player, Object vehicle, float px, float py) {
        try {
            Method getSpeedMethod = vehicle.getClass().getMethod("getCurrentSpeedKmHour");
            float speed = ((Number) getSpeedMethod.invoke(vehicle)).floatValue();

            if (Math.abs(speed) < 8.0f) {
                return;
            }

            float dirX = 0.0f;
            float dirY = 0.0f;

            try {
                Field velField = vehicle.getClass().getField("jniLinearVelocity");
                Object velObj = velField.get(vehicle);
                if (velObj instanceof org.joml.Vector3f vel) {
                    float lenSq = vel.x * vel.x + vel.z * vel.z;
                    if (lenSq > 0.001f) {
                        float invLen = (float) (1.0 / Math.sqrt(lenSq));
                        dirX = vel.x * invLen;
                        dirY = vel.z * invLen;
                    }
                }
            } catch (Throwable ignored) {}

            if (dirX == 0.0f && dirY == 0.0f) {
                try {
                    Method getForwardVectorMethod = vehicle.getClass().getMethod("getForwardVector", org.joml.Vector3f.class);
                    org.joml.Vector3f fwd = (org.joml.Vector3f) getForwardVectorMethod.invoke(vehicle, new org.joml.Vector3f());
                    if (fwd != null) {
                        float lenSq = fwd.x * fwd.x + fwd.z * fwd.z;
                        if (lenSq > 0.001f) {
                            float invLen = (float) (1.0 / Math.sqrt(lenSq));
                            float sign = speed < 0.0f ? -1.0f : 1.0f;
                            dirX = (fwd.x * invLen) * sign;
                            dirY = (fwd.z * invLen) * sign;
                        }
                    }
                } catch (Throwable ignored) {}
            }

            if (dirX == 0.0f && dirY == 0.0f) {
                try {
                    Class<?> playerClass = player.getClass();
                    Method getDirXMethod = playerClass.getMethod("getForwardDirectionX");
                    Method getDirYMethod = playerClass.getMethod("getForwardDirectionY");
                    dirX = ((Number) getDirXMethod.invoke(player)).floatValue();
                    dirY = ((Number) getDirYMethod.invoke(player)).floatValue();
                } catch (Throwable ignored) {}
            }

            if (dirX == 0.0f && dirY == 0.0f) return;

            float normX = -dirY;
            float normY = dirX;

            boolean isFast = isStorageFast();
            int maxSteps = isFast ? 3 : 2;
            float lookaheadTiles = Math.min(isFast ? 80.0f : 40.0f, Math.abs(speed) * 1.5f);

            for (int step = 1; step <= maxSteps; step++) {
                float progress = (float) step / (float) maxSteps;
                float targetX = px + (dirX * lookaheadTiles * progress);
                float targetY = py + (dirY * lookaheadTiles * progress);

                int targetChunkX = (int) Math.floor(targetX / CHUNK_WIDTH);
                int targetChunkY = (int) Math.floor(targetY / CHUNK_WIDTH);

                prewarmChunkInOSCache(targetChunkX, targetChunkY);
                ChunkRetentionRing.touch(targetChunkX, targetChunkY);

                if (isFast) {
                    int lateralChunkX = (int) Math.signum(normX);
                    int lateralChunkY = (int) Math.signum(normY);
                    if (lateralChunkX != 0 || lateralChunkY != 0) {
                        prewarmChunkInOSCache(targetChunkX + lateralChunkX, targetChunkY + lateralChunkY);
                        prewarmChunkInOSCache(targetChunkX - lateralChunkX, targetChunkY - lateralChunkY);
                    }
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void handleOnFootStreaming(Class<?> playerClass, Object player, float px, float py) {
        try {
            Method isMovingMethod = playerClass.getMethod("isPlayerMoving");
            boolean isMoving = (Boolean) isMovingMethod.invoke(player);

            if (!isMoving) return;

            Method isSprintingMethod = playerClass.getMethod("isSprinting");
            boolean isSprinting = (Boolean) isSprintingMethod.invoke(player);

            Method getDirXMethod = playerClass.getMethod("getForwardDirectionX");
            Method getDirYMethod = playerClass.getMethod("getForwardDirectionY");
            float dirX = ((Number) getDirXMethod.invoke(player)).floatValue();
            float dirY = ((Number) getDirYMethod.invoke(player)).floatValue();

            float lookaheadTiles = isSprinting ? 32.0f : 16.0f;
            int steps = isSprinting ? 3 : 2;

            for (int step = 1; step <= steps; step++) {
                float targetX = px + (dirX * lookaheadTiles * ((float) step / steps));
                float targetY = py + (dirY * lookaheadTiles * ((float) step / steps));

                int targetChunkX = (int) Math.floor(targetX / CHUNK_WIDTH);
                int targetChunkY = (int) Math.floor(targetY / CHUNK_WIDTH);

                prewarmChunkInOSCache(targetChunkX, targetChunkY);
                ChunkRetentionRing.touch(targetChunkX, targetChunkY);
            }
        } catch (Throwable ignored) {}
    }

    public static void prewarmChunkDirect(int wx, int wy) {
        prewarmChunkInOSCache(wx, wy);
    }

    private static void prewarmChunkInOSCache(int wx, int wy) {
        long key = FastChunkKey.pack(wx, wy);
        ChunkRetentionRing.touch(wx, wy);

        if (!PREWARMED_KEYS.add(key)) {
            return;
        }

        try {
            File inFile = zombie.ChunkMapFilenames.instance.getFilename(wx, wy);
            if (inFile == null) {
                inFile = zombie.ZomboidFileSystem.instance.getFileInCurrentSave(wx + File.separator + wy + ".bin");
            }
            if (inFile != null && inFile.exists()) {
                byte[] buf = PREWARM_IO_BUFFER.get();
                try (FileInputStream fis = new FileInputStream(inFile)) {
                    fis.read(buf);
                    preloadedChunksFetched.incrementAndGet();
                }
            }
        } catch (Throwable ignored) {}
    }

    public static byte[] pollPreloadedChunk(int wx, int wy) {
        return null;
    }

    public static void recordCacheHit() {
        preloadedCacheHits.incrementAndGet();
    }

    public static long getPreloadedCacheHits() {
        return preloadedCacheHits.get();
    }

    public static long getPreloadedChunksFetched() {
        return preloadedChunksFetched.get();
    }

    public static void stop() {
        running = false;
        if (streamerThread != null) {
            streamerThread.interrupt();
        }
    }
}
