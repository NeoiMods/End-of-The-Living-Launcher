package com.pzoptimizer;

import java.lang.reflect.Field;
import java.lang.reflect.Method;

/** Pre-caches the levels above and below the player; B42 worlds have 32 levels (-16 to +16). */
public final class VerticalChunkStreamer {

    private static volatile boolean active = false;
    private static Thread verticalThread = null;
    private static int lastPlayerZ = 0;
    private static long lastZChangeTime = 0;

    public static void initialize() {
        if (active) return;
        active = true;
        PZOLogger.success("VerticalChunkStreamer: Active (Build 42 32-Level Z-Index Integrated Mode)");
    }

    private static void trackVerticalTransitions() {
        try {
            // Cars don't go up stairs or lifts, so skip the elevation sweeps on the road
            if (VehicleTravelOptimizer.isPlayerDriving()) {
                return;
            }

            Class<?> playerClass = Class.forName("zombie.characters.IsoPlayer");
            Field playersField = playerClass.getField("players");
            Object[] players = (Object[]) playersField.get(null);
            if (players == null || players.length == 0 || players[0] == null) return;

            Object player = players[0];
            Method getZ = player.getClass().getMethod("getZ");
            int currentZ = (int) Math.floor(((Number) getZ.invoke(player)).floatValue());

            if (currentZ != lastPlayerZ) {
                int zDelta = currentZ - lastPlayerZ;
                lastPlayerZ = currentZ;
                lastZChangeTime = System.currentTimeMillis();

                // Warm currentZ + zDelta and currentZ + 2*zDelta
                int targetZ1 = currentZ + zDelta;
                int targetZ2 = currentZ + (zDelta * 2);

                // B42 levels run from -16 to +16
                if (targetZ1 >= -16 && targetZ1 <= 16) {
                    prewarmVerticalLevel(player, targetZ1);
                }
                if (targetZ2 >= -16 && targetZ2 <= 16) {
                    prewarmVerticalLevel(player, targetZ2);
                }
            }
        } catch (Throwable ignored) {}
    }

    private static void prewarmVerticalLevel(Object player, int targetZ) {
        try {
            Class<?> worldClass = Class.forName("zombie.iso.IsoWorld");
            Field instField = worldClass.getField("instance");
            Object world = instField.get(null);
            if (world == null) return;

            Field cellField = null;
            try {
                cellField = worldClass.getField("currentCell");
            } catch (Throwable t) {
                cellField = worldClass.getField("CurrentCell");
            }
            Object cell = cellField.get(world);
            if (cell == null) return;

            Method getX = player.getClass().getMethod("getX");
            Method getY = player.getClass().getMethod("getY");
            int px = (int) ((Number) getX.invoke(player)).floatValue();
            int py = (int) ((Number) getY.invoke(player)).floatValue();

            // 5x5 column around the player on the target level
            Method getGridSquare = cell.getClass().getMethod("getGridSquare", int.class, int.class, int.class);
            for (int dx = -2; dx <= 2; dx++) {
                for (int dy = -2; dy <= 2; dy++) {
                    getGridSquare.invoke(cell, px + dx, py + dy, targetZ);
                }
            }
        } catch (Throwable ignored) {}
    }

    public static void shutdown() {
        active = false;
        if (verticalThread != null) {
            verticalThread.interrupt();
        }
    }
}
