package com.pzoptimizer;

/** Sizes ForkJoinPool and the worker pools to the CPU's performance cores. */
public class ThreadPoolTuner {
    public static void initialize() {
        try {
            int availableCores = Runtime.getRuntime().availableProcessors();
            // Between 2 and 16
            int targetParallelism = Math.max(2, Math.min(16, availableCores));

            System.setProperty("java.util.concurrent.ForkJoinPool.common.parallelism", String.valueOf(targetParallelism));
            System.setProperty("jdk.virtualThreadScheduler.parallelism", String.valueOf(targetParallelism));
            
            PZOLogger.success(String.format("ThreadPoolTuner active (Scaled ForkJoinPool parallelism: %d threads for %d CPU cores)",
                targetParallelism, availableCores));
        } catch (Throwable t) {
            PZOLogger.warn("ThreadPoolTuner non-fatal fallback: " + t.getMessage());
        }
    }
}
