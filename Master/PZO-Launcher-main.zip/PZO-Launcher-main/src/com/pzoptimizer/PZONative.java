package com.pzoptimizer;

import java.io.File;
import java.nio.ByteBuffer;
import java.nio.FloatBuffer;
import java.util.ArrayList;
import java.util.List;

/**
 * JNI bridge to pzo_native64.dll / libpzo_native64.so / libpzo_native64.dylib: OS scheduling, timer resolution, power
 * throttling exemption and the AVX2 batch helpers.
 */
public class PZONative {

    private static volatile boolean loaded = false;
    private static volatile boolean initialized = false;

    public static final String OS_NAME;
    public static final boolean IS_WINDOWS;
    public static final boolean IS_MAC;
    public static final boolean IS_LINUX;
    public static final String NATIVE_LIB_FILENAME;

    static {
        String os = System.getProperty("os.name", "").toLowerCase();
        OS_NAME = os;
        IS_WINDOWS = os.contains("win");
        IS_MAC = os.contains("mac") || os.contains("darwin");
        IS_LINUX = !IS_WINDOWS && !IS_MAC;

        if (IS_WINDOWS) {
            NATIVE_LIB_FILENAME = "pzo_native64.dll";
        } else if (IS_MAC) {
            NATIVE_LIB_FILENAME = "libpzo_native64.dylib";
        } else {
            NATIVE_LIB_FILENAME = "libpzo_native64.so";
        }

        loadNativeLibrary();
    }

    private static synchronized void loadNativeLibrary() {
        if (loaded) return;

        try {
            System.loadLibrary("pzo_native64");
            loaded = true;
            PZOLogger.success("[PZONative] Loaded " + NATIVE_LIB_FILENAME + " via System.loadLibrary");
        } catch (Throwable t1) {
            List<String> candidatePaths = new ArrayList<>();
            candidatePaths.add(NATIVE_LIB_FILENAME);
            candidatePaths.add(System.getProperty("user.dir") + File.separator + NATIVE_LIB_FILENAME);

            try {
                File jarFile = new File(PZONative.class.getProtectionDomain().getCodeSource().getLocation().toURI());
                if (jarFile.isFile() && jarFile.getParentFile() != null) {
                    File p = jarFile.getParentFile();
                    candidatePaths.add(new File(p, NATIVE_LIB_FILENAME).getAbsolutePath());
                    if (IS_WINDOWS) {
                        candidatePaths.add(new File(p, "win64" + File.separator + NATIVE_LIB_FILENAME).getAbsolutePath());
                    } else if (IS_LINUX) {
                        candidatePaths.add(new File(p, "linux64" + File.separator + NATIVE_LIB_FILENAME).getAbsolutePath());
                        candidatePaths.add(new File(p, "natives" + File.separator + NATIVE_LIB_FILENAME).getAbsolutePath());
                    } else if (IS_MAC) {
                        candidatePaths.add(new File(p, "ProjectZomboid.app/Contents/MacOS/" + NATIVE_LIB_FILENAME).getAbsolutePath());
                        candidatePaths.add(new File(p, "ProjectZomboid.app/Contents/Java/" + NATIVE_LIB_FILENAME).getAbsolutePath());
                    }
                }
            } catch (Throwable ignored) {}

            if (IS_WINDOWS) {
                candidatePaths.add("win64" + File.separator + NATIVE_LIB_FILENAME);
                candidatePaths.add("K:/SteamLibrary/steamapps/common/ProjectZomboid/" + NATIVE_LIB_FILENAME);
            } else if (IS_LINUX) {
                candidatePaths.add("linux64" + File.separator + NATIVE_LIB_FILENAME);
                candidatePaths.add("natives" + File.separator + NATIVE_LIB_FILENAME);
                String home = System.getProperty("user.home", "");
                if (!home.isEmpty()) {
                    candidatePaths.add(home + "/.local/share/Steam/steamapps/common/ProjectZomboid/" + NATIVE_LIB_FILENAME);
                    candidatePaths.add(home + "/.steam/steam/steamapps/common/ProjectZomboid/" + NATIVE_LIB_FILENAME);
                }
            } else if (IS_MAC) {
                candidatePaths.add("ProjectZomboid.app/Contents/MacOS/" + NATIVE_LIB_FILENAME);
                candidatePaths.add("ProjectZomboid.app/Contents/Java/" + NATIVE_LIB_FILENAME);
                candidatePaths.add("../MacOS/" + NATIVE_LIB_FILENAME);
                candidatePaths.add("../Java/" + NATIVE_LIB_FILENAME);
            }

            for (String p : candidatePaths) {
                try {
                    File f = new File(p);
                    if (f.exists() && f.isFile()) {
                        System.load(f.getAbsolutePath());
                        loaded = true;
                        PZOLogger.success("[PZONative] Loaded " + NATIVE_LIB_FILENAME + " from: " + f.getAbsolutePath());
                        break;
                    }
                } catch (Throwable ignored) {}
            }
        }

        if (loaded) {
            try {
                if (initNative()) {
                    initialized = true;
                    applyKernelGovernors();
                }
            } catch (Throwable t) {
                PZOLogger.warn("[PZONative] initNative failed: " + t.getMessage());
            }
        } else {
            String osLabel = IS_WINDOWS ? "Windows" : (IS_MAC ? "macOS" : "Linux");
            PZOLogger.info("[PZONative] Native companion library (" + NATIVE_LIB_FILENAME + ") not found on " + osLabel + "; operating in pure JVM safe mode.");
        }
    }

    private static void applyKernelGovernors() {
        if (!initialized) return;

        try {
            boolean avx2 = false;
            try { avx2 = isAVX2Supported(); } catch (Throwable ignored) {}
            CompatMode.noteNativeAvx2(avx2);
            boolean compat = CompatMode.isActive();

            // The JAVA tab's CPU power shield switch, read at launch
            boolean shield = PZOConfig.isPowerShieldEnabled();
            boolean powerShield = false;
            if (shield) try { powerShield = disablePowerThrottling(); } catch (Throwable ignored) {}

            boolean timerLock = false;
            if (shield) try { timerLock = setHighPrecisionTimer(true); } catch (Throwable ignored) {}

            boolean lowCore = isLowCoreCpu();
            boolean mmcss = false;
            boolean prio = false;
            boolean wsLock = false;
            if (!shield) {
                PZOLogger.info("[PZONative] CPU power shield switched off in the JAVA tab: timer, power throttling, MMCSS and priority left as stock.");
            } else if (!lowCore && !compat) {
                try { mmcss = setMMCSSProfile("Games"); } catch (Throwable ignored) {}
                try { prio = setProcessPriority(1); } catch (Throwable ignored) {}
                try { wsLock = lockProcessWorkingSet(); } catch (Throwable ignored) {}
            } else {
                PZOLogger.info("[PZONative] " + (compat ? "Compatibility mode" : "Low core count CPU")
                    + ": skipping MMCSS, raised process priority and working set lock.");
            }

            int physCores = 0;
            try { physCores = getPhysicalCores(); } catch (Throwable ignored) {}
            int pCores = 0;
            try { pCores = getPerformanceCores(); } catch (Throwable ignored) {}
            int logProc = 0;
            try { logProc = getLogicalProcessors(); } catch (Throwable ignored) {}
            long pCoreMask = 0;
            try { pCoreMask = getPerformanceCoreMask(); } catch (Throwable ignored) {}
            int timerRes100ns = 0;
            try { timerRes100ns = getTimerResolution100ns(); } catch (Throwable ignored) {}

            double timerMs = timerRes100ns / 10000.0;

            PZOLogger.success(String.format(
                "[PZONative] Hardware Governor Active: CPU [%d Physical | %d P-Cores | %d Threads] Mask: 0x%X",
                physCores, pCores, logProc, pCoreMask
            ));
            PZOLogger.success(String.format(
                "[PZONative] Kernel QoS Active: Timer: %.2fms (Status: %s) | PowerThrottling Disabled: %s | MMCSS: %s | RAM WorkingSet Locked: %s | AVX2: %s",
                timerMs, timerLock ? "LOCKED" : "FALLBACK",
                powerShield ? "SUCCESS" : "N/A",
                mmcss ? "ACTIVE" : "N/A",
                wsLock ? "YES" : "N/A",
                avx2 ? "ENABLED" : "DISABLED"
            ));
        } catch (Throwable t) {
            PZOLogger.warn("[PZONative] applyKernelGovernors notice: " + t.getMessage());
        }
    }

    public static boolean isLoaded() {
        return loaded && initialized;
    }

    /**
     * 4 or fewer logical CPUs (e.g. i5-7300HQ). The game's main and render threads already need most of those, so the
     * HIGH priority class, MMCSS boosts and full-width worker pools just starve input handling.
     */
    public static boolean isLowCoreCpu() {
        return Runtime.getRuntime().availableProcessors() <= 4;
    }

    public static boolean bindCallingThreadToPCores() {
        if (!isLoaded()) return false;
        try {
            return bindThreadToPerformanceCores();
        } catch (Throwable t) {
            return false;
        }
    }

    public static int calculateDistancesAVX2(FloatBuffer directCoords, int count, float originX, float originY, FloatBuffer directOutDist) {
        if (!isLoaded() || !directCoords.isDirect() || !directOutDist.isDirect()) {
            return fallbackDistances(directCoords, count, originX, originY, directOutDist);
        }
        try {
            return batchCalculateDistancesAVX2(directCoords, count, originX, originY, directOutDist);
        } catch (Throwable t) {
            return fallbackDistances(directCoords, count, originX, originY, directOutDist);
        }
    }

    public static int calculateDistancesSqAVX2(FloatBuffer directCoords, int count, float originX, float originY, FloatBuffer directOutDistSq) {
        if (!isLoaded() || !directCoords.isDirect() || !directOutDistSq.isDirect()) {
            return fallbackDistancesSq(directCoords, count, originX, originY, directOutDistSq);
        }
        try {
            return batchCalculateDistancesSqAVX2(directCoords, count, originX, originY, directOutDistSq);
        } catch (Throwable t) {
            return fallbackDistancesSq(directCoords, count, originX, originY, directOutDistSq);
        }
    }

    public static int cullRadialAVX2(FloatBuffer directCoords, int count, float originX, float originY, float maxRadiusSq, ByteBuffer directOutMask) {
        if (!isLoaded() || !directCoords.isDirect() || !directOutMask.isDirect()) {
            return fallbackCullRadial(directCoords, count, originX, originY, maxRadiusSq, directOutMask);
        }
        try {
            return batchCullRadialAVX2(directCoords, count, originX, originY, maxRadiusSq, directOutMask);
        } catch (Throwable t) {
            return fallbackCullRadial(directCoords, count, originX, originY, maxRadiusSq, directOutMask);
        }
    }

    public static int cullAABBAVX2(FloatBuffer directCoords, int count, float minX, float minY, float maxX, float maxY, ByteBuffer directOutMask) {
        if (!isLoaded() || !directCoords.isDirect() || !directOutMask.isDirect()) {
            return fallbackCullAABB(directCoords, count, minX, minY, maxX, maxY, directOutMask);
        }
        try {
            return batchCullAABBAVX2(directCoords, count, minX, minY, maxX, maxY, directOutMask);
        } catch (Throwable t) {
            return fallbackCullAABB(directCoords, count, minX, minY, maxX, maxY, directOutMask);
        }
    }

    public static int classifyTiersAVX2(FloatBuffer directCoords, int count, float originX, float originY,
                                        float t0Sq, float t1Sq, float t2Sq, ByteBuffer directOutTiers) {
        if (!isLoaded() || !directCoords.isDirect() || !directOutTiers.isDirect()) {
            return fallbackClassifyTiers(directCoords, count, originX, originY, t0Sq, t1Sq, t2Sq, directOutTiers);
        }
        try {
            return batchClassifyTiersAVX2(directCoords, count, originX, originY, t0Sq, t1Sq, t2Sq, directOutTiers);
        } catch (Throwable t) {
            return fallbackClassifyTiers(directCoords, count, originX, originY, t0Sq, t1Sq, t2Sq, directOutTiers);
        }
    }

    public static int calculateFovAVX2(FloatBuffer directCoords, FloatBuffer directHeadings, int count,
                                       float targetX, float targetY, float viewDistSq, float cosHalfFov,
                                       float closeRadiusSq, ByteBuffer directOutMask) {
        if (!isLoaded() || !directCoords.isDirect() || !directHeadings.isDirect() || !directOutMask.isDirect()) {
            return fallbackCalculateFov(directCoords, directHeadings, count, targetX, targetY, viewDistSq, cosHalfFov, closeRadiusSq, directOutMask);
        }
        try {
            return batchCalculateFovAVX2(directCoords, directHeadings, count, targetX, targetY, viewDistSq, cosHalfFov, closeRadiusSq, directOutMask);
        } catch (Throwable t) {
            return fallbackCalculateFov(directCoords, directHeadings, count, targetX, targetY, viewDistSq, cosHalfFov, closeRadiusSq, directOutMask);
        }
    }

    public static int calculateRepulsionAVX2(FloatBuffer directCoords, int count, float separationRadius,
                                            float maxForce, FloatBuffer directOutForces) {
        if (!isLoaded() || !directCoords.isDirect() || !directOutForces.isDirect()) {
            return fallbackCalculateRepulsion(directCoords, count, separationRadius, maxForce, directOutForces);
        }
        try {
            return batchCalculateRepulsionAVX2(directCoords, count, separationRadius, maxForce, directOutForces);
        } catch (Throwable t) {
            return fallbackCalculateRepulsion(directCoords, count, separationRadius, maxForce, directOutForces);
        }
    }

    public static int readAndDecompressChunk(String filePath, ByteBuffer dstDirectBuf) {
        if (filePath == null || dstDirectBuf == null || !dstDirectBuf.isDirect()) return -1;
        if (!isLoaded()) return -1;
        try {
            return readAndDecompressChunkDirect(filePath, dstDirectBuf, dstDirectBuf.capacity());
        } catch (Throwable t) {
            return -1;
        }
    }

    private static int fallbackDistances(FloatBuffer coords, int count, float ox, float oy, FloatBuffer out) {
        coords.rewind();
        out.rewind();
        for (int i = 0; i < count; i++) {
            float x = coords.get(i * 2);
            float y = coords.get(i * 2 + 1);
            float dx = x - ox;
            float dy = y - oy;
            out.put(i, (float) Math.sqrt(dx * dx + dy * dy));
        }
        return count;
    }

    private static int fallbackDistancesSq(FloatBuffer coords, int count, float ox, float oy, FloatBuffer out) {
        coords.rewind();
        out.rewind();
        for (int i = 0; i < count; i++) {
            float x = coords.get(i * 2);
            float y = coords.get(i * 2 + 1);
            float dx = x - ox;
            float dy = y - oy;
            out.put(i, dx * dx + dy * dy);
        }
        return count;
    }

    private static int fallbackCullRadial(FloatBuffer coords, int count, float ox, float oy, float maxRadSq, ByteBuffer outMask) {
        coords.rewind();
        outMask.rewind();
        int inside = 0;
        for (int i = 0; i < count; i++) {
            float dx = coords.get(i * 2) - ox;
            float dy = coords.get(i * 2 + 1) - oy;
            byte in = (byte) ((dx * dx + dy * dy <= maxRadSq) ? 1 : 0);
            outMask.put(i, in);
            if (in == 1) inside++;
        }
        return inside;
    }

    private static int fallbackCullAABB(FloatBuffer coords, int count, float minX, float minY, float maxX, float maxY, ByteBuffer outMask) {
        coords.rewind();
        outMask.rewind();
        int inside = 0;
        for (int i = 0; i < count; i++) {
            float x = coords.get(i * 2);
            float y = coords.get(i * 2 + 1);
            byte in = (byte) ((x >= minX && x <= maxX && y >= minY && y <= maxY) ? 1 : 0);
            outMask.put(i, in);
            if (in == 1) inside++;
        }
        return inside;
    }

    private static int fallbackClassifyTiers(FloatBuffer coords, int count, float ox, float oy,
                                             float t0Sq, float t1Sq, float t2Sq, ByteBuffer outTiers) {
        coords.rewind();
        outTiers.rewind();
        for (int i = 0; i < count; i++) {
            float dx = coords.get(i * 2) - ox;
            float dy = coords.get(i * 2 + 1) - oy;
            float dSq = dx * dx + dy * dy;
            if (dSq <= t0Sq) outTiers.put(i, (byte) 0);
            else if (dSq <= t1Sq) outTiers.put(i, (byte) 1);
            else if (dSq <= t2Sq) outTiers.put(i, (byte) 2);
            else outTiers.put(i, (byte) 3);
        }
        return count;
    }

    private static int fallbackCalculateFov(FloatBuffer coords, FloatBuffer headings, int count,
                                            float targetX, float targetY, float viewDistSq, float cosHalfFov,
                                            float closeRadiusSq, ByteBuffer outMask) {
        int visible = 0;
        float cosSq = cosHalfFov * cosHalfFov;
        for (int i = 0; i < count; i++) {
            float x = coords.get(i * 2);
            float y = coords.get(i * 2 + 1);
            float dx = targetX - x;
            float dy = targetY - y;
            float distSq = dx * dx + dy * dy;
            if (distSq <= closeRadiusSq) {
                outMask.put(i, (byte) 1);
                visible++;
                continue;
            }
            if (distSq <= viewDistSq && distSq > 0.0001f) {
                float hx = headings.get(i * 2);
                float hy = headings.get(i * 2 + 1);
                float dot = dx * hx + dy * hy;
                if (dot > 0.0f && (dot * dot) >= (cosSq * distSq)) {
                    outMask.put(i, (byte) 1);
                    visible++;
                    continue;
                }
            }
            outMask.put(i, (byte) 0);
        }
        return visible;
    }

    private static int fallbackCalculateRepulsion(FloatBuffer coords, int count, float separationRadius,
                                                  float maxForce, FloatBuffer outForces) {
        float radSq = separationRadius * separationRadius;
        for (int i = 0; i < count; i++) {
            float xi = coords.get(i * 2);
            float yi = coords.get(i * 2 + 1);
            float fx = 0.0f, fy = 0.0f;
            for (int j = 0; j < count; j++) {
                if (i == j) continue;
                float dx = xi - coords.get(j * 2);
                float dy = yi - coords.get(j * 2 + 1);
                float dSq = dx * dx + dy * dy;
                if (dSq < radSq && dSq > 0.0001f) {
                    float invD = 1.0f / dSq;
                    fx += dx * invD;
                    fy += dy * invD;
                }
            }
            if (fx > maxForce) fx = maxForce; else if (fx < -maxForce) fx = -maxForce;
            if (fy > maxForce) fy = maxForce; else if (fy < -maxForce) fy = -maxForce;
            outForces.put(i * 2, fx);
            outForces.put(i * 2 + 1, fy);
        }
        return count;
    }

    // Decompression and Win32 chunk stream helpers

    public static int decompress(byte[] src, int srcOff, int srcLen, byte[] dst, int dstOff, int dstCap) {
        if (!isLoaded() || src == null || dst == null || srcLen <= 0 || dstCap <= 0) return -1;
        try {
            return decompressBytes(src, srcOff, srcLen, dst, dstOff, dstCap);
        } catch (Throwable t) {
            return -1;
        }
    }

    public static int decompress(ByteBuffer src, int srcPos, int srcLen, ByteBuffer dst, int dstPos, int dstCap) {
        if (!isLoaded() || src == null || dst == null || !src.isDirect() || !dst.isDirect() || srcLen <= 0 || dstCap <= 0) return -1;
        try {
            return decompressDirect(src, srcPos, srcLen, dst, dstPos, dstCap);
        } catch (Throwable t) {
            return -1;
        }
    }

    public static int readChunkFile(String path, byte[] dst, int maxCap) {
        if (!isLoaded() || path == null || dst == null || maxCap <= 0) return -1;
        try {
            return readChunkFileNative(path, dst, maxCap);
        } catch (Throwable t) {
            return -1;
        }
    }

    public static boolean prewarmFile(String path) {
        if (!isLoaded() || path == null) return false;
        try {
            return prewarmFileNative(path);
        } catch (Throwable t) {
            return false;
        }
    }

    public static int prewarmFiles(String[] paths) {
        if (!isLoaded() || paths == null || paths.length == 0) return 0;
        try {
            return prewarmFilesNative(paths);
        } catch (Throwable t) {
            return 0;
        }
    }

    public static boolean isSolidStateDrive(String path) {
        if (!isLoaded() || path == null) return true;
        try {
            return isDriveSSDNative(path);
        } catch (Throwable t) {
            return true;
        }
    }

    public static boolean isNativeFilePresent() {
        if (loaded) return true;

        String nativeName = NATIVE_LIB_FILENAME;
        List<File> searchDirs = new ArrayList<>();
        searchDirs.add(new File("."));
        try {
            File jarFile = new File(PZONative.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            if (jarFile.isFile() && jarFile.getParentFile() != null) {
                searchDirs.add(jarFile.getParentFile());
            }
        } catch (Throwable ignored) {}

        for (File dir : searchDirs) {
            if (new File(dir, nativeName).exists()) return true;
            if (IS_WINDOWS) {
                if (new File(dir, "win64" + File.separator + nativeName).exists()) return true;
            } else if (IS_LINUX) {
                if (new File(dir, "linux64" + File.separator + nativeName).exists()) return true;
                if (new File(dir, "natives" + File.separator + nativeName).exists()) return true;
            } else if (IS_MAC) {
                if (new File(dir, "ProjectZomboid.app/Contents/MacOS/" + nativeName).exists()) return true;
                if (new File(dir, "ProjectZomboid.app/Contents/Java/" + nativeName).exists()) return true;
                if (new File(dir, "../MacOS/" + nativeName).exists()) return true;
                if (new File(dir, "../Java/" + nativeName).exists()) return true;
            }
        }

        return false;
    }

    public static String getInstalledNativeVersion() {
        if (!loaded) {
            if (!isNativeFilePresent()) {
                return "Not Installed (Missing)";
            }
            return "Load Failed (Incompatible/Corrupt)";
        }
        try {
            String ver = getNativeVersion();
            if (ver != null && !ver.trim().isEmpty()) {
                return ver.trim();
            }
        } catch (UnsatisfiedLinkError | NoSuchMethodError e) {
            return "Legacy / Outdated (pre-0.9.0)";
        } catch (Throwable t) {
            return "Unknown (" + t.getMessage() + ")";
        }
        return "Unknown";
    }

    // JNI declarations, implemented in native/pzo_native.c
    public static native String getNativeVersion();
    private static native boolean initNative();
    public static native boolean setHighPrecisionTimer(boolean enable);
    public static native boolean disablePowerThrottling();
    public static native boolean setMMCSSProfile(String profileName);
    public static native boolean setProcessPriority(int priorityLevel);
    public static native boolean lockProcessWorkingSet();
    public static native boolean optimizeCallingThread(int priorityLevel, boolean bindPCores, String profileStr);
    public static native long getPerformanceCoreMask();
    public static native boolean bindThreadToPerformanceCores();
    public static native int getPhysicalCores();
    public static native int getPerformanceCores();
    public static native int getLogicalProcessors();
    public static native int getTimerResolution100ns();
    public static native boolean isAVX2Supported();
    private static native int batchCalculateDistancesAVX2(
        FloatBuffer directCoords, int count, float originX, float originY, FloatBuffer directOutDist
    );
    private static native int batchCalculateDistancesSqAVX2(
        FloatBuffer directCoords, int count, float originX, float originY, FloatBuffer directOutDistSq
    );
    private static native int batchCullRadialAVX2(
        FloatBuffer directCoords, int count, float originX, float originY, float maxRadiusSq, ByteBuffer directOutMask
    );
    private static native int batchCullAABBAVX2(
        FloatBuffer directCoords, int count, float minX, float minY, float maxX, float maxY, ByteBuffer directOutMask
    );
    private static native int batchClassifyTiersAVX2(
        FloatBuffer directCoords, int count, float originX, float originY,
        float t0Sq, float t1Sq, float t2Sq, ByteBuffer directOutTiers
    );
    private static native int batchCalculateFovAVX2(
        FloatBuffer directCoords, FloatBuffer directHeadings, int count,
        float targetX, float targetY, float viewDistSq, float cosHalfFov, float closeRadiusSq,
        ByteBuffer directOutMask
    );
    private static native int batchCalculateRepulsionAVX2(
        FloatBuffer directCoords, int count, float separationRadius, float maxForce, FloatBuffer directOutForces
    );
    private static native int decompressBytes(byte[] src, int srcOff, int srcLen, byte[] dst, int dstOff, int dstCap);
    private static native int decompressDirect(ByteBuffer src, int srcPos, int srcLen, ByteBuffer dst, int dstPos, int dstCap);
    private static native int readChunkFileNative(String filePath, byte[] dstArray, int maxCap);
    private static native int readAndDecompressChunkDirect(String filePath, ByteBuffer dstDirectBuf, int dstCap);
    private static native boolean prewarmFileNative(String filePath);
    private static native int prewarmFilesNative(String[] filePaths);
    private static native boolean isDriveSSDNative(String path);
    /** 1 active, 0 vanilla, -1 PZPathFind64 not loaded, -2 different DLL build, -3 write failed, -4 not Windows. */
    public static native int setPathfindAStarHook(boolean enable);
    /** out = {searches, nodes expanded, indexed decrease-keys}. */
    public static native void getPathfindAStarStats(long[] out);
}
