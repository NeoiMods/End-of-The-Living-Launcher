package com.pzoptimizer;

import java.lang.management.GarbageCollectorMXBean;
import java.lang.management.ManagementFactory;
import java.lang.management.MemoryPoolMXBean;
import java.lang.management.MemoryUsage;
import java.util.concurrent.atomic.AtomicLong;

/**
 * With G1 a young collection (3-8 ms) runs wherever the game thread happens to be when Eden fills up, often mid-step in
 * combat or driving, and that drops a frame. I watch "G1 Eden Space" over JMX, and when Eden is past 90% of its
 * learned threshold and the frame limiter has slack at the end of a step, I push the collection into that idle time so
 * the next tick starts with an empty Eden.
 */
public final class GcSlackGovernor {

    private static volatile boolean active = true;
    private static MemoryPoolMXBean edenPool = null;
    private static GarbageCollectorMXBean youngCollector = null;
    private static boolean initialized = false;
    private static boolean usable = false;

    private static long lastYoungCount = -1L;
    private static long lastEdenUsed = 0L;
    private static long learnedEdenCapBytes = 256L * 1024L * 1024L;
    private static long lastSlackCollectNanos = 0L;

    public static final AtomicLong slackCollectionsScheduled = new AtomicLong(0);
    public static final AtomicLong naturalCollectionsObserved = new AtomicLong(0);
    public static volatile Object fillerSink = null;

    private GcSlackGovernor() {}

    public static boolean isActive() {
        return active;
    }

    public static void setActive(boolean val) {
        active = val;
    }

    private static synchronized void initialize() {
        if (initialized) return;
        initialized = true;
        try {
            for (MemoryPoolMXBean pool : ManagementFactory.getMemoryPoolMXBeans()) {
                if ("G1 Eden Space".equals(pool.getName())) {
                    edenPool = pool;
                    break;
                }
            }
            for (GarbageCollectorMXBean gc : ManagementFactory.getGarbageCollectorMXBeans()) {
                if ("G1 Young Generation".equals(gc.getName())) {
                    youngCollector = gc;
                    break;
                }
            }
            usable = (edenPool != null && youngCollector != null);
            if (usable) {
                lastYoungCount = youngCollector.getCollectionCount();
                PZOLogger.success("[PZO GcSlackGovernor] G1 Eden Space frame-slack pacer armed");
            }
        } catch (Throwable ignored) {
            usable = false;
        }
    }

    /** Called at the end of a frame step when there's spare frame-cap time (in nanoseconds). */
    public static void onFrameSlack(long spareSlackNanos) {
        if (!active) return;
        if (!initialized) initialize();
        if (!usable || spareSlackNanos < 3_500_000L) {
            return; // need at least 3.5 ms spare
        }

        try {
            long gcCount = youngCollector.getCollectionCount();
            MemoryUsage usage = edenPool.getUsage();
            if (usage == null) return;

            long used = usage.getUsed();
            long committed = usage.getCommitted();
            if (committed > 0) {
                learnedEdenCapBytes = committed;
            }

            if (gcCount != lastYoungCount) {
                if (lastYoungCount >= 0 && lastEdenUsed > (64L << 20)) {
                    // Blend in the Eden size I saw before the last collection
                    learnedEdenCapBytes = (learnedEdenCapBytes * 3 + lastEdenUsed) / 4;
                }
                lastYoungCount = gcCount;
                naturalCollectionsObserved.incrementAndGet();
            }
            lastEdenUsed = used;

            long remaining = learnedEdenCapBytes - used;
            long threshold = (long) (learnedEdenCapBytes * 0.10); // under 10% of Eden left
            long now = System.nanoTime();

            if (remaining > 0 && remaining <= threshold && remaining <= (24L << 20) && (now - lastSlackCollectNanos) > 500_000_000L) {
                // A few small short-lived allocations tip the coming young GC into this idle window
                long deadline = now + Math.min(spareSlackNanos - 1_500_000L, 2_500_000L);
                int chunkBytes = 128 * 1024; // 128 KB, never humongous
                long beforeCount = youngCollector.getCollectionCount();
                long allocated = 0L;
                while (System.nanoTime() < deadline && allocated < remaining + (4L << 20)) {
                    fillerSink = new byte[chunkBytes];
                    allocated += chunkBytes;
                    if (youngCollector.getCollectionCount() > beforeCount) {
                        slackCollectionsScheduled.incrementAndGet();
                        lastYoungCount = youngCollector.getCollectionCount();
                        lastSlackCollectNanos = System.nanoTime();
                        break;
                    }
                }
                fillerSink = null;
            }
        } catch (Throwable ignored) {}
    }
}
