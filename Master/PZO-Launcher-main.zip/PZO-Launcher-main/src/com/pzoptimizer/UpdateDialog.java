package com.pzoptimizer;

import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicReference;

/**
 * Pre-menu update prompt and self-updater: WinForms on Windows, AppleScript on macOS, Zenity/KDialog on Linux and Steam
 * Deck.
 */
public class UpdateDialog {
    private static final String CONFIG_FILE = "pzo_config.json";

    // These block startup before the game window exists, so one nobody can see must never hang the launch
    private static final int DIALOG_AUTO_CLOSE_MS = 60000;
    private static final long DIALOG_PROCESS_TIMEOUT_SEC = 120;

    // The PowerShell child rarely gets foreground rights, so Activate() alone often just flashes the taskbar. Attaching
    // to the foreground window's input thread lets SetForegroundWindow through. Passed in PZO_FG_SRC because the script
    // itself can't contain double quotes.
    private static final String PS_FOREGROUND_SRC = """
        using System;
        using System.Runtime.InteropServices;
        public static class PzoForeground {
            [DllImport("user32.dll")] static extern IntPtr GetForegroundWindow();
            [DllImport("user32.dll")] static extern uint GetWindowThreadProcessId(IntPtr hWnd, IntPtr pid);
            [DllImport("kernel32.dll")] static extern uint GetCurrentThreadId();
            [DllImport("user32.dll")] static extern bool AttachThreadInput(uint idAttach, uint idAttachTo, bool attach);
            [DllImport("user32.dll")] static extern bool BringWindowToTop(IntPtr hWnd);
            [DllImport("user32.dll")] static extern bool SetForegroundWindow(IntPtr hWnd);
            [DllImport("user32.dll")] static extern bool ShowWindow(IntPtr hWnd, int cmd);
            public static void Force(IntPtr hWnd) {
                uint fg = GetWindowThreadProcessId(GetForegroundWindow(), IntPtr.Zero);
                uint me = GetCurrentThreadId();
                bool attached = fg != 0 && fg != me && AttachThreadInput(me, fg, true);
                try {
                    ShowWindow(hWnd, 5);
                    BringWindowToTop(hWnd);
                    SetForegroundWindow(hWnd);
                } finally {
                    if (attached) AttachThreadInput(me, fg, false);
                }
            }
        }
        """;

    // TopMost keeps it above normal windows, and it's pulled to the front on show and again for 3 s in case Steam's
    // launch window grabs focus back. If nobody answers it closes as Cancel (= skip).
    private static final String PS_FORM_GUARDS =
        "try{Add-Type -TypeDefinition $env:PZO_FG_SRC}catch{};" +
        "$f.TopMost=$true;$f.ShowInTaskbar=$true;" +
        "$fg={if(-not $f.ContainsFocus){try{[PzoForeground]::Force($f.Handle)}catch{$f.Activate()}}};" +
        "$global:pzoFgTicks=0;$ft=New-Object Windows.Forms.Timer;$ft.Interval=1000;" +
        "$ft.Add_Tick({$global:pzoFgTicks++;if($global:pzoFgTicks -ge 3){$ft.Stop()};& $fg});" +
        "$tm=New-Object Windows.Forms.Timer;$tm.Interval=" + DIALOG_AUTO_CLOSE_MS + ";" +
        "$tm.Add_Tick({$tm.Stop();$f.DialogResult=[Windows.Forms.DialogResult]::Cancel});" +
        "$f.Add_Shown({& $fg;$ft.Start();$tm.Start()});";

    public static boolean promptIfUpdateAvailable(String latestVersion, String downloadUrl) {
        return promptIfUpdateAvailable(latestVersion, downloadUrl, null);
    }

    public static boolean promptIfUpdateAvailable(String latestVersion, String downloadUrl, String dllDownloadUrl) {
        if (latestVersion == null || isVersionIgnored(latestVersion)) {
            return false;
        }

        try {
            String result = showUpdateDialog(latestVersion);
            if ("UPDATE".equalsIgnoreCase(result)) {
                performAutoUpdateAndExit(latestVersion, downloadUrl, dllDownloadUrl);
                return true;
            } else if ("SKIP_IGNORE".equalsIgnoreCase(result)) {
                setIgnoredVersion(latestVersion);
            }
        } catch (Throwable t) {
            PZOLogger.error("UpdateDialog launch error: " + t.getMessage(), t);
        }
        return false;
    }

    /**
     * Checks the game folder for the native library and whether its version matches the Java side. If it's missing,
     * mismatched or outdated, asks the user to download it.
     */
    public static boolean checkAndPromptNativeMismatch(String dllDownloadUrl) {
        boolean filePresent = PZONative.isNativeFilePresent();
        String installedVersion = PZONative.getInstalledNativeVersion();
        String expectedVersion = UpdateChecker.CURRENT_VERSION;

        if (filePresent && expectedVersion.equalsIgnoreCase(installedVersion)) {
            return false;
        }

        // Same base version (e.g. 0.9.9.4 and 0.9.9.4-unstable) means the same native ABI
        if (filePresent && installedVersion != null && !installedVersion.isEmpty()) {
            String cleanExpected = expectedVersion.replaceAll("(?i)-unstable|-beta|-alpha|-rc.*", "").trim();
            String cleanInstalled = installedVersion.replaceAll("(?i)-unstable|-beta|-alpha|-rc.*", "").trim();
            if (!cleanExpected.isEmpty() && cleanExpected.equalsIgnoreCase(cleanInstalled)) {
                return false;
            }
        }

        String ignoreKey = "native_" + expectedVersion;
        if (isVersionIgnored(ignoreKey)) {
            return false;
        }

        boolean isMissing = !filePresent || "Not Installed (Missing)".equalsIgnoreCase(installedVersion);
        if (isMissing) {
            PZOLogger.warn(String.format(
                "[UpdateDialog] Native governor binary not found in game folder: Expected [%s] (%s). Prompting user to download...",
                expectedVersion, PZONative.NATIVE_LIB_FILENAME
            ));
        } else {
            PZOLogger.warn(String.format(
                "[UpdateDialog] Native governor mismatch: Installed [%s], Expected [%s]. Prompting user to update...",
                installedVersion, expectedVersion
            ));
        }

        if (dllDownloadUrl == null || dllDownloadUrl.isEmpty() || dllDownloadUrl.contains("/releases/latest/")) {
            dllDownloadUrl = UpdateChecker.resolveNativeDownloadUrl(expectedVersion, 2500);
        }

        try {
            String result = showNativeMismatchDialog(installedVersion, expectedVersion);
            if ("UPDATE".equalsIgnoreCase(result)) {
                performNativeAutoUpdateAndExit(expectedVersion, dllDownloadUrl);
                return true;
            } else if ("SKIP_IGNORE".equalsIgnoreCase(result)) {
                setIgnoredVersion(ignoreKey);
            }
        } catch (Throwable t) {
            PZOLogger.error("Native update dialog launch error: " + t.getMessage(), t);
        }
        return false;
    }

    private static String showUpdateDialog(String latestVersion) {
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("win")) return showWindowsDialog(latestVersion);
        if (os.contains("mac")) return showMacDialog(latestVersion);
        return showLinuxDialog(latestVersion);
    }

    private static String showNativeMismatchDialog(String installedVersion, String expectedVersion) {
        String os = System.getProperty("os.name", "").toLowerCase();
        if (os.contains("win")) return showWindowsNativeMismatchDialog(installedVersion, expectedVersion);
        if (os.contains("mac")) return showMacNativeMismatchDialog(installedVersion, expectedVersion);
        return showLinuxNativeMismatchDialog(installedVersion, expectedVersion);
    }

    /**
     * Dev launch options that open the startup dialogs with sample data, so they can be checked without a real update,
     * mismatch or mod. Answers just get logged; nothing is downloaded, ignored, allowed or blocked. -pzo_updatebox,
     * -pzo_nativebox, -pzo_nativemissingbox, -pzo_javamodbox, -pzo_pzwarnbox, -pzo_noticebox, -pzo_alldialogs
     */
    public static void runDevDialogPreviews(String[] args) {
        java.util.Set<String> flags = new java.util.HashSet<>();
        if (args != null) {
            for (String a : args) if (a != null) flags.add(a.trim().toLowerCase());
        }
        String sunCmd = System.getProperty("sun.java.command");
        if (sunCmd != null) {
            for (String tok : sunCmd.split("\\s+")) flags.add(tok.toLowerCase());
        }
        boolean all = flags.contains("-pzo_alldialogs");
        String sample = UpdateChecker.CURRENT_VERSION;

        if (all || flags.contains("-pzo_updatebox")) {
            devResult("update", showUpdateDialog(sample + "-devpreview"));
        }
        if (all || flags.contains("-pzo_nativebox")) {
            devResult("native mismatch", showNativeMismatchDialog("0.0.0-devpreview", sample));
        }
        if (all || flags.contains("-pzo_nativemissingbox")) {
            devResult("native missing", showNativeMismatchDialog("Not Installed (Missing)", sample));
        }
        if (all || flags.contains("-pzo_javamodbox")) {
            devResult("java mod approval", promptJavaModApproval("Dev Preview Mod", "1234567890",
                new File("mods/DevPreview/media/java/devpreview.jar").getAbsolutePath(),
                "0000000000000000000000000000000000000000000000000000000000000000"));
        }
        if (all || flags.contains("-pzo_pzwarnbox")) {
            showWarningNotice("Project Zomboid Optimiser - Incompatible Mod Detected", IncompatibleModGuard.warningMessage());
            devResult("PZ_Optimization warning", "closed");
        }
        if (all || flags.contains("-pzo_noticebox")) {
            showNoticePopup("Update Notice", "Dev preview of the update failure notice.\nPlease update manually using install.bat / pzo_optimizer.sh.");
            devResult("update notice", "closed");
        }
    }

    private static void devResult(String dialog, String result) {
        PZOLogger.info("[PZO Dev] " + dialog + " dialog preview returned " + result + " (not acted on)");
    }

    private static String showWindowsDialog(String latestVersion) {
        try {
            String psCode = String.format(
                "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms');" +
                "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing');" +
                "$nl=[Environment]::NewLine;" +
                "$f=New-Object Windows.Forms.Form;" +
                "$f.Text='Project Zomboid Optimiser - Update Available';" +
                "$f.Size=New-Object Drawing.Size(480,240);" +
                "$f.StartPosition='CenterScreen';" +
                "$f.FormBorderStyle='FixedDialog';" +
                "$f.MaximizeBox=$false;$f.MinimizeBox=$false;" + PS_FORM_GUARDS +
                "$f.BackColor=[Drawing.Color]::FromArgb(30,30,30);" +
                "$f.ForeColor=[Drawing.Color]::White;" +
                "$t=New-Object Windows.Forms.Label;" +
                "$t.Text='[!] Project Zomboid Optimiser Update Available';" +
                "$t.Font=New-Object Drawing.Font('Segoe UI',12,[Drawing.FontStyle]::Bold);" +
                "$t.ForeColor=[Drawing.Color]::FromArgb(80,220,100);" +
                "$t.Location=New-Object Drawing.Point(20,15);$t.Size=New-Object Drawing.Size(430,25);$f.Controls.Add($t);" +
                "$i=New-Object Windows.Forms.Label;" +
                "$i.Text=('A newer release of PZOptimEngine is ready.' + $nl + $nl + 'Installed Version: v%s' + $nl + 'Latest Available: v%s');" +
                "$i.Font=New-Object Drawing.Font('Segoe UI',10);$i.ForeColor=[Drawing.Color]::FromArgb(220,220,220);" +
                "$i.Location=New-Object Drawing.Point(20,48);$i.Size=New-Object Drawing.Size(430,70);$f.Controls.Add($i);" +
                "$cb=New-Object Windows.Forms.CheckBox;" +
                "$cb.Text='Don''t remind me again for version %s';" +
                "$cb.Font=New-Object Drawing.Font('Segoe UI',9);$cb.ForeColor=[Drawing.Color]::FromArgb(170,170,170);" +
                "$cb.Location=New-Object Drawing.Point(23,120);$cb.Size=New-Object Drawing.Size(350,25);$f.Controls.Add($cb);" +
                "$bu=New-Object Windows.Forms.Button;$bu.Text='Update Now';" +
                "$bu.Font=New-Object Drawing.Font('Segoe UI',9,[Drawing.FontStyle]::Bold);$bu.BackColor=[Drawing.Color]::FromArgb(40,167,69);$bu.ForeColor=[Drawing.Color]::White;$bu.FlatStyle='Flat';" +
                "$bu.Location=New-Object Drawing.Point(345,155);$bu.Size=New-Object Drawing.Size(105,32);$bu.DialogResult=[Windows.Forms.DialogResult]::Yes;$f.Controls.Add($bu);" +
                "$bs=New-Object Windows.Forms.Button;$bs.Text='Skip / Launch Game';" +
                "$bs.Font=New-Object Drawing.Font('Segoe UI',9);$bs.BackColor=[Drawing.Color]::FromArgb(65,65,65);$bs.ForeColor=[Drawing.Color]::White;$bs.FlatStyle='Flat';" +
                "$bs.Location=New-Object Drawing.Point(195,155);$bs.Size=New-Object Drawing.Size(140,32);$bs.DialogResult=[Windows.Forms.DialogResult]::No;$f.Controls.Add($bs);" +
                "$f.AcceptButton=$bu;$r=$f.ShowDialog();" +
                "if($r -eq [Windows.Forms.DialogResult]::Yes){Write-Output 'UPDATE'}else{if($cb.Checked){Write-Output 'SKIP_IGNORE'}else{Write-Output 'SKIP'}}",
                UpdateChecker.CURRENT_VERSION, latestVersion, latestVersion
            );

            String out = runDialogProcess(new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", psCode), null);
            if (out.endsWith(":UPDATE")) return "UPDATE";
            if (out.endsWith(":SKIP_IGNORE")) return "SKIP_IGNORE";
        } catch (Throwable t) {
            PZOLogger.error("Windows update dialog error: " + t.getMessage(), t);
        }
        return "SKIP";
    }

    private static String showMacDialog(String latestVersion) {
        try {
            String script = String.format(
                "set r to button returned of (display dialog \"[!] A newer release of Project Zomboid Optimiser is ready.\\n\\nInstalled Version: v%s\\nLatest Available: v%s\" " +
                "with title \"PZO Engine - Update Available\" buttons {\"Don't Remind Me\", \"Skip\", \"Update Now\"} default button \"Update Now\" with icon note)\n" +
                "return r",
                UpdateChecker.CURRENT_VERSION, latestVersion
            );
            Process p = new ProcessBuilder("osascript", "-e", script).start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String out = reader.readLine();
                if (out != null) {
                    if (out.contains("Update Now")) return "UPDATE";
                    if (out.contains("Don't Remind Me")) return "SKIP_IGNORE";
                }
            }
            p.waitFor();
        } catch (Throwable ignored) {}
        return "SKIP";
    }

    private static String showLinuxDialog(String latestVersion) {
        try {
            Process p = new ProcessBuilder("zenity", "--question",
                "--title=PZO Engine - Update Available",
                "--text=[!] A newer release of Project Zomboid Optimiser is ready.\n\nInstalled Version: v" + UpdateChecker.CURRENT_VERSION + "\nLatest Available: v" + latestVersion + "\n\nWould you like to update now?",
                "--ok-label=Update Now", "--cancel-label=Skip / Launch Game",
                "--extra-button=Don't Remind Me").start();
            
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String extra = reader.readLine();
                if (extra != null && extra.contains("Don't Remind Me")) {
                    return "SKIP_IGNORE";
                }
            }
            if (p.waitFor() == 0) return "UPDATE";
            return "SKIP";
        } catch (Throwable ignored) {}

        try {
            Process p = new ProcessBuilder("kdialog",
                "--title", "PZO Engine - Update Available",
                "--yesno", "[!] A newer release of Project Zomboid Optimiser is ready.\n\nInstalled Version: v" + UpdateChecker.CURRENT_VERSION + "\nLatest Available: v" + latestVersion + "\n\nWould you like to update now?",
                "--yes-label", "Update Now", "--no-label", "Skip / Launch Game").start();
            if (p.waitFor() == 0) return "UPDATE";
            return "SKIP";
        } catch (Throwable ignored) {}

        return "SKIP";
    }

    private static String showWindowsNativeMismatchDialog(String installedVersion, String expectedVersion) {
        try {
            String nativeFileName = PZONative.NATIVE_LIB_FILENAME;
            boolean isMissing = !PZONative.isNativeFilePresent() || installedVersion.contains("Missing") || installedVersion.contains("Not Installed");
            String formTitle = isMissing ? "Project Zomboid Optimiser - Native Library Setup" : "Project Zomboid Optimiser - Native Library Update Required";
            String titleText = isMissing ? "[!] Native Governor Library Missing" : "[!] Native Governor Library Mismatch Detected";
            String btnText = isMissing ? "Install Now" : "Update Now";
            String descText = isMissing
                ? String.format("No %s was detected in your game folder." +
                    "$nl$nlInstalling this native companion library unlocks 0.5ms timer locking, AVX2 SIMD culling, and kernel thread optimization." +
                    "$nl$nlStatus: %s$nlRequired for PZO Engine: v%s", nativeFileName, installedVersion, expectedVersion)
                : String.format("An outdated or mismatched %s was detected in your game folder." +
                    "$nl$nlInstalled DLL: %s$nlRequired for PZO Engine: v%s", nativeFileName, installedVersion, expectedVersion);

            String psCode = String.format(
                "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms');" +
                "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing');" +
                "$nl=[Environment]::NewLine;" +
                "$f=New-Object Windows.Forms.Form;" +
                "$f.Text='%s';" +
                "$f.Size=New-Object Drawing.Size(530,280);" +
                "$f.StartPosition='CenterScreen';" +
                "$f.FormBorderStyle='FixedDialog';" +
                "$f.MaximizeBox=$false;$f.MinimizeBox=$false;" + PS_FORM_GUARDS +
                "$f.BackColor=[Drawing.Color]::FromArgb(30,30,30);" +
                "$f.ForeColor=[Drawing.Color]::White;" +
                "$t=New-Object Windows.Forms.Label;" +
                "$t.Text='%s';" +
                "$t.Font=New-Object Drawing.Font('Segoe UI',12,[Drawing.FontStyle]::Bold);" +
                "$t.ForeColor=[Drawing.Color]::FromArgb(255,185,50);" +
                "$t.Location=New-Object Drawing.Point(20,15);$t.Size=New-Object Drawing.Size(480,25);$f.Controls.Add($t);" +
                "$i=New-Object Windows.Forms.Label;" +
                "$i.Text=('%s');" +
                "$i.Font=New-Object Drawing.Font('Segoe UI',9.5);$i.ForeColor=[Drawing.Color]::FromArgb(220,220,220);" +
                "$i.Location=New-Object Drawing.Point(20,48);$i.Size=New-Object Drawing.Size(480,95);$f.Controls.Add($i);" +
                "$cb=New-Object Windows.Forms.CheckBox;" +
                "$cb.Text='Don''t remind me again for this version';" +
                "$cb.Font=New-Object Drawing.Font('Segoe UI',9);$cb.ForeColor=[Drawing.Color]::FromArgb(170,170,170);" +
                "$cb.Location=New-Object Drawing.Point(23,155);$cb.Size=New-Object Drawing.Size(350,25);$f.Controls.Add($cb);" +
                "$bu=New-Object Windows.Forms.Button;$bu.Text='%s';" +
                "$bu.Font=New-Object Drawing.Font('Segoe UI',9,[Drawing.FontStyle]::Bold);$bu.BackColor=[Drawing.Color]::FromArgb(40,167,69);$bu.ForeColor=[Drawing.Color]::White;$bu.FlatStyle='Flat';" +
                "$bu.Location=New-Object Drawing.Point(375,190);$bu.Size=New-Object Drawing.Size(125,32);$bu.DialogResult=[Windows.Forms.DialogResult]::Yes;$f.Controls.Add($bu);" +
                "$bs=New-Object Windows.Forms.Button;$bs.Text='Skip / Launch Game';" +
                "$bs.Font=New-Object Drawing.Font('Segoe UI',9);$bs.BackColor=[Drawing.Color]::FromArgb(65,65,65);$bs.ForeColor=[Drawing.Color]::White;$bs.FlatStyle='Flat';" +
                "$bs.Location=New-Object Drawing.Point(225,190);$bs.Size=New-Object Drawing.Size(140,32);$bs.DialogResult=[Windows.Forms.DialogResult]::No;$f.Controls.Add($bs);" +
                "$f.AcceptButton=$bu;$r=$f.ShowDialog();" +
                "if($r -eq [Windows.Forms.DialogResult]::Yes){Write-Output 'UPDATE'}else{if($cb.Checked){Write-Output 'SKIP_IGNORE'}else{Write-Output 'SKIP'}}",
                formTitle, titleText, descText.replace("'", "''"), btnText
            );

            String out = runDialogProcess(new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", psCode), null);
            if (out.endsWith(":UPDATE")) return "UPDATE";
            if (out.endsWith(":SKIP_IGNORE")) return "SKIP_IGNORE";
        } catch (Throwable t) {
            PZOLogger.error("Windows native update dialog error: " + t.getMessage(), t);
        }
        return "SKIP";
    }

    private static String showMacNativeMismatchDialog(String installedVersion, String expectedVersion) {
        try {
            boolean isMissing = !PZONative.isNativeFilePresent() || installedVersion.contains("Missing") || installedVersion.contains("Not Installed");
            String btnText = isMissing ? "Install Now" : "Update Now";
            String promptText = isMissing
                ? String.format("[!] Native Governor Library Missing.\\n\\nNo %s was detected in your game bundle.\\n\\nInstalling this companion unlocks high-precision timer locking, AVX2 SIMD math, and kernel thread optimization.\\n\\nStatus: %s\\nRequired for PZO Engine: v%s\\n\\nWould you like to download and install %s now?",
                    PZONative.NATIVE_LIB_FILENAME, installedVersion, expectedVersion, PZONative.NATIVE_LIB_FILENAME)
                : String.format("[!] Native Governor Library Mismatch Detected.\\n\\nInstalled: %s\\nRequired for PZO Engine: v%s\\n\\nWould you like to update %s now?",
                    installedVersion, expectedVersion, PZONative.NATIVE_LIB_FILENAME);

            String script = String.format(
                "set r to button returned of (display dialog \"%s\" " +
                "with title \"PZO Engine - Native Library %s\" buttons {\"Don't Remind Me\", \"Skip\", \"%s\"} default button \"%s\" with icon caution)\n" +
                "return r",
                promptText, isMissing ? "Setup" : "Update", btnText, btnText
            );
            ProcessBuilder pb = new ProcessBuilder("osascript", "-e", script);
            Process p = pb.start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line = reader.readLine();
                if (line != null) {
                    line = line.trim();
                    if (btnText.equalsIgnoreCase(line) || "Update Now".equalsIgnoreCase(line) || "Install Now".equalsIgnoreCase(line)) return "UPDATE";
                    if ("Don't Remind Me".equalsIgnoreCase(line)) return "SKIP_IGNORE";
                }
            }
            p.waitFor();
        } catch (Throwable t) {
            PZOLogger.error("Mac native update dialog error: " + t.getMessage(), t);
        }
        return "SKIP";
    }

    private static String showLinuxNativeMismatchDialog(String installedVersion, String expectedVersion) {
        try {
            boolean isMissing = !PZONative.isNativeFilePresent() || installedVersion.contains("Missing") || installedVersion.contains("Not Installed");
            String btnText = isMissing ? "Install Now" : "Update Now";
            String text = isMissing
                ? String.format("Native Governor Library Missing!\n\nNo %s was detected in your game folder.\n\nInstalling this companion unlocks high-precision timer locking, AVX2 SIMD batch culling, and kernel thread priority.\n\nStatus: %s\nRequired for PZO Engine: v%s\n\nWould you like to download and install %s now?",
                    PZONative.NATIVE_LIB_FILENAME, installedVersion, expectedVersion, PZONative.NATIVE_LIB_FILENAME)
                : String.format("Native Governor Library Mismatch Detected!\n\nInstalled: %s\nRequired for PZO Engine: v%s\n\nWould you like to update %s now?",
                    installedVersion, expectedVersion, PZONative.NATIVE_LIB_FILENAME);

            ProcessBuilder pb = new ProcessBuilder("zenity", "--question", "--title=PZO Engine - Native Library " + (isMissing ? "Setup" : "Update"),
                "--text=" + text, "--ok-label=" + btnText, "--cancel-label=Skip / Launch Game", "--extra-button=Don't Remind Me");
            Process p = pb.start();
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String extra = reader.readLine();
                if (extra != null && extra.contains("Don't Remind Me")) {
                    return "SKIP_IGNORE";
                }
            }
            if (p.waitFor() == 0) return "UPDATE";
        } catch (Throwable ignored) {
            try {
                boolean isMissing = !PZONative.isNativeFilePresent() || installedVersion.contains("Missing") || installedVersion.contains("Not Installed");
                String btnText = isMissing ? "Install Now" : "Update Now";
                String text = isMissing
                    ? String.format("Native Governor Library Missing!\n\nNo %s was detected in your game folder.\n\nStatus: %s\nRequired for PZO Engine: v%s\n\nWould you like to download and install %s now?",
                        PZONative.NATIVE_LIB_FILENAME, installedVersion, expectedVersion, PZONative.NATIVE_LIB_FILENAME)
                    : String.format("Native Governor Library Mismatch Detected!\n\nInstalled: %s\nRequired for PZO Engine: v%s\n\nWould you like to update %s now?",
                        installedVersion, expectedVersion, PZONative.NATIVE_LIB_FILENAME);

                ProcessBuilder pb = new ProcessBuilder("kdialog", "--title", "PZO Engine - Native Library " + (isMissing ? "Setup" : "Update"),
                    "--yesno", text, "--yes-label", btnText, "--no-label", "Skip / Launch Game");
                Process p = pb.start();
                if (p.waitFor() == 0) return "UPDATE";
            } catch (Throwable ignored2) {}
        }
        return "SKIP";
    }

    private static void performNativeAutoUpdateAndExit(String targetVersion, String dllDownloadUrl) {
        try {
            File currentJar = null;
            try {
                currentJar = new File(UpdateDialog.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            } catch (Throwable ignored) {}

            if (currentJar == null || !currentJar.exists()) {
                currentJar = new File("PZOptimEngine.jar").getAbsoluteFile();
            }

            File gameDir = currentJar.getParentFile();
            if (gameDir == null) {
                gameDir = new File(".").getAbsoluteFile();
            }

            String nativeFileName = PZONative.NATIVE_LIB_FILENAME;
            File currentNative = new File(gameDir, nativeFileName);
            File newNative = new File(gameDir, nativeFileName + ".new");

            List<String> candidateUrls = new ArrayList<>();
            if (dllDownloadUrl != null && !dllDownloadUrl.isEmpty() && !dllDownloadUrl.contains("/releases/latest/")) {
                candidateUrls.add(dllDownloadUrl);
            }
            String resolved = UpdateChecker.resolveNativeDownloadUrl(targetVersion, 2500);
            if (resolved != null && !candidateUrls.contains(resolved)) {
                candidateUrls.add(resolved);
            }
            String cleanVer = targetVersion.trim();
            String vTag = cleanVer.startsWith("v") || cleanVer.startsWith("V") ? cleanVer : "V" + cleanVer;
            String directUrl = "https://github.com/prop11/PZO-Launcher/releases/download/" + vTag + "/" + nativeFileName;
            if (!candidateUrls.contains(directUrl)) {
                candidateUrls.add(directUrl);
            }
            String lowerVTag = "v" + cleanVer.replaceFirst("^[vV]", "");
            String directLowerUrl = "https://github.com/prop11/PZO-Launcher/releases/download/" + lowerVTag + "/" + nativeFileName;
            if (!candidateUrls.contains(directLowerUrl)) {
                candidateUrls.add(directLowerUrl);
            }
            String rawTagUrl = "https://github.com/prop11/PZO-Launcher/releases/download/" + cleanVer + "/" + nativeFileName;
            if (!candidateUrls.contains(rawTagUrl)) {
                candidateUrls.add(rawTagUrl);
            }

            boolean downloaded = false;
            for (String tryUrl : candidateUrls) {
                PZOLogger.info("Attempting native library download from: " + tryUrl);
                if (downloadFileWithRedirects(tryUrl, newNative) && newNative.exists() && newNative.length() > 1000) {
                    downloaded = true;
                    PZOLogger.success("Successfully downloaded " + newNative.length() + " bytes to " + newNative.getAbsolutePath() + " from: " + tryUrl);
                    break;
                } else {
                    if (newNative.exists()) newNative.delete();
                }
            }

            if (!downloaded || !newNative.exists() || newNative.length() < 1000) {
                if (newNative.exists()) newNative.delete();
                PZOLogger.error("Failed to download native library from all candidate sources.");
                showNoticePopup("Update Notice", "Could not download " + nativeFileName + " from GitHub Releases.\nPlease run install.bat to update manually.");
                return;
            }

            PZOLogger.success("Downloaded " + newNative.length() + " bytes to " + newNative.getAbsolutePath());

            String os = System.getProperty("os.name", "").toLowerCase();
            long pid = ProcessHandle.current().pid();
            File win64Dll = new File(gameDir, "win64" + File.separator + nativeFileName);

            File currentJson = new File(gameDir, ZomboidConfigMigrator.TARGET_JSON_NAME);
            File newJson = new File(gameDir, ZomboidConfigMigrator.TARGET_JSON_NAME + ".new");
            boolean hasNewJson = ZomboidConfigMigrator.prepareStagedUpdate(gameDir) && newJson.exists();

            if (os.contains("win")) {
                String psJsonUpdate = hasNewJson ? String.format(
                    "if (Test-Path -LiteralPath '%s') { " +
                    "    for ($i=0; $i -lt 30; $i++) { " +
                    "        try { Move-Item -LiteralPath '%s' -Destination '%s' -Force -ErrorAction Stop; break; } " +
                    "        catch { Start-Sleep -Milliseconds 200; } " +
                    "    } " +
                    "}; ",
                    newJson.getAbsolutePath().replace("'", "''"),
                    newJson.getAbsolutePath().replace("'", "''"),
                    currentJson.getAbsolutePath().replace("'", "''")
                ) : "";

                String psUpdater = String.format(
                    "$proc = Get-Process -Id %d -ErrorAction SilentlyContinue; " +
                    "if ($proc) { $proc.WaitForExit(15000); }; " +
                    "Start-Sleep -Milliseconds 500; " +
                    "if (Test-Path -LiteralPath '%s') { " +
                    "    if (Test-Path -LiteralPath '%s') { " +
                    "        for ($i=0; $i -lt 30; $i++) { " +
                    "            try { Copy-Item -LiteralPath '%s' -Destination '%s' -Force -ErrorAction Stop; break; } " +
                    "            catch { Start-Sleep -Milliseconds 200; } " +
                    "        } " +
                    "    }; " +
                    "    for ($i=0; $i -lt 30; $i++) { " +
                    "        try { Move-Item -LiteralPath '%s' -Destination '%s' -Force -ErrorAction Stop; break; } " +
                    "        catch { Start-Sleep -Milliseconds 200; } " +
                    "    } " +
                    "}; " +
                    "%s" +
                    "$nl=[Environment]::NewLine; " +
                    "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms'); " +
                    "[Windows.Forms.MessageBox]::Show(('Native Governor (%s) and configuration have been successfully updated to v%s!' + $nl + $nl + 'Please restart Project Zomboid to apply native optimizations.'), 'Setup Complete', [Windows.Forms.MessageBoxButtons]::OK, [Windows.Forms.MessageBoxIcon]::Information)",
                    pid,
                    newNative.getAbsolutePath().replace("'", "''"),
                    win64Dll.getParentFile().getAbsolutePath().replace("'", "''"),
                    newNative.getAbsolutePath().replace("'", "''"),
                    win64Dll.getAbsolutePath().replace("'", "''"),
                    newNative.getAbsolutePath().replace("'", "''"),
                    currentNative.getAbsolutePath().replace("'", "''"),
                    psJsonUpdate,
                    nativeFileName,
                    targetVersion
                );
                new ProcessBuilder("powershell.exe", "-NoProfile", "-WindowStyle", "Hidden", "-Command", psUpdater).start();
            } else if (os.contains("mac")) {
                String macJsonUpdate = hasNewJson ? String.format(
                    " && (test -f \"%s\" && mv -f \"%s\" \"%s\" || true)",
                    newJson.getAbsolutePath(), newJson.getAbsolutePath(), currentJson.getAbsolutePath()
                ) : "";
                String macNativeUpdate = String.format(
                    " && cp -f \"%s\" \"%s\" && (test -d \"ProjectZomboid.app/Contents/Java\" && cp -f \"%s\" \"ProjectZomboid.app/Contents/Java/%s\" || true) && (test -d \"ProjectZomboid.app/Contents/MacOS\" && cp -f \"%s\" \"ProjectZomboid.app/Contents/MacOS/%s\" || true) && rm -f \"%s\"",
                    newNative.getAbsolutePath(), currentNative.getAbsolutePath(),
                    newNative.getAbsolutePath(), nativeFileName,
                    newNative.getAbsolutePath(), nativeFileName,
                    newNative.getAbsolutePath()
                );
                String shUpdater = String.format(
                    "while kill -0 %d 2>/dev/null; do sleep 0.2; done; sleep 0.5%s%s && osascript -e 'display notification \"Native Governor (%s) has been successfully installed/updated to v%s! Please restart Project Zomboid.\" with title \"Setup Complete\"'",
                    pid, macNativeUpdate, macJsonUpdate, nativeFileName, targetVersion
                );
                new ProcessBuilder("bash", "-c", shUpdater).start();
            } else {
                String linuxJsonUpdate = hasNewJson ? String.format(
                    " && (test -f \"%s\" && mv -f \"%s\" \"%s\" || true)",
                    newJson.getAbsolutePath(), newJson.getAbsolutePath(), currentJson.getAbsolutePath()
                ) : "";
                String linuxNativeUpdate = String.format(
                    " && cp -f \"%s\" \"%s\" && (test -d \"linux64\" && cp -f \"%s\" \"linux64/%s\" || true) && (test -d \"natives\" && cp -f \"%s\" \"natives/%s\" || true) && rm -f \"%s\"",
                    newNative.getAbsolutePath(), currentNative.getAbsolutePath(),
                    newNative.getAbsolutePath(), nativeFileName,
                    newNative.getAbsolutePath(), nativeFileName,
                    newNative.getAbsolutePath()
                );
                String shUpdater = String.format(
                    "while kill -0 %d 2>/dev/null; do sleep 0.2; done; sleep 0.5%s%s && (kdialog --msgbox \"Native Governor (%s) has been successfully installed/updated to v%s!\\n\\nPlease restart Project Zomboid.\" || zenity --info --text=\"Native Governor (%s) has been successfully installed/updated to v%s!\\n\\nPlease restart Project Zomboid.\" || notify-send \"PZO Native Setup Complete\" \"Please restart Project Zomboid.\")",
                    pid, linuxNativeUpdate, linuxJsonUpdate, nativeFileName, targetVersion, nativeFileName, targetVersion
                );
                new ProcessBuilder("bash", "-c", shUpdater).start();
            }

            PZOLogger.info("Exiting game process to allow atomic native library replacement...");
            System.exit(0);

        } catch (Throwable t) {
            PZOLogger.error("Native auto-update failed: " + t.getMessage(), t);
            showNoticePopup("Update Notice", "Native update error: " + t.getMessage() + "\nPlease update manually using install.bat / pzo_optimizer.sh.");
        }
    }

    private static void performAutoUpdateAndExit(String latestVersion, String downloadUrl, String dllDownloadUrl) {
        try {
            if (downloadUrl == null || downloadUrl.isEmpty()) {
                downloadUrl = "https://github.com/prop11/PZO-Launcher/releases/latest/download/PZOptimEngine.jar";
            }
            File currentJar = null;
            try {
                currentJar = new File(UpdateDialog.class.getProtectionDomain().getCodeSource().getLocation().toURI());
            } catch (Throwable ignored) {}

            if (currentJar == null || !currentJar.exists()) {
                currentJar = new File("PZOptimEngine.jar").getAbsoluteFile();
            }

            File gameDir = currentJar.getParentFile();
            if (gameDir == null) {
                gameDir = new File(".").getAbsoluteFile();
            }

            currentJar = new File(gameDir, "PZOptimEngine.jar");
            File newJar = new File(gameDir, "PZOptimEngine.jar.new");

            String cleanVer = latestVersion != null ? latestVersion.trim() : UpdateChecker.CURRENT_VERSION;
            String vTag = cleanVer.startsWith("v") || cleanVer.startsWith("V") ? cleanVer : "V" + cleanVer;

            String os = System.getProperty("os.name", "").toLowerCase();
            boolean isWin = os.contains("win");
            boolean isMac = os.contains("mac") || os.contains("darwin");
            String nativeFileName = isWin ? "pzo_native64.dll" : (isMac ? "libpzo_native64.dylib" : "libpzo_native64.so");

            File currentNative = new File(gameDir, nativeFileName);
            File newNative = new File(gameDir, nativeFileName + ".new");
            File win64Dll = new File(gameDir, "win64" + File.separator + nativeFileName);
            boolean nativeInstalled = PZONative.isNativeFilePresent() || currentNative.exists() || win64Dll.exists();
            boolean hasNewNative = false;

            // Get the matching native library first, if native support is installed or available
            List<String> nativeCandidates = new ArrayList<>();
            if (dllDownloadUrl != null && !dllDownloadUrl.isEmpty() && !dllDownloadUrl.contains("/releases/latest/")) {
                nativeCandidates.add(dllDownloadUrl);
            }
            String resolvedNative = UpdateChecker.resolveNativeDownloadUrl(latestVersion, 2500);
            if (resolvedNative != null && !nativeCandidates.contains(resolvedNative)) {
                nativeCandidates.add(resolvedNative);
            }
            String directNativeUrl = "https://github.com/prop11/PZO-Launcher/releases/download/" + vTag + "/" + nativeFileName;
            if (!nativeCandidates.contains(directNativeUrl)) {
                nativeCandidates.add(directNativeUrl);
            }
            String directNativeLowerUrl = "https://github.com/prop11/PZO-Launcher/releases/download/v" + cleanVer.replaceFirst("^[vV]", "") + "/" + nativeFileName;
            if (!nativeCandidates.contains(directNativeLowerUrl)) {
                nativeCandidates.add(directNativeLowerUrl);
            }

            for (String tryNative : nativeCandidates) {
                PZOLogger.info("Downloading matching " + nativeFileName + " for v" + latestVersion + " from: " + tryNative);
                if (downloadFileWithRedirects(tryNative, newNative) && newNative.exists() && newNative.length() > 5000) {
                    hasNewNative = true;
                    PZOLogger.success("Downloaded " + newNative.length() + " bytes to " + newNative.getAbsolutePath());
                    break;
                } else {
                    if (newNative.exists()) newNative.delete();
                }
            }

            // With the native library installed, never update the jar on its own
            if (nativeInstalled && !hasNewNative) {
                if (newNative.exists()) newNative.delete();
                PZOLogger.error("Failed to download matching native library (" + nativeFileName + ") for version " + latestVersion + ". Aborting update to avoid library mismatch.");
                showNoticePopup("Update Notice", "Could not download the matching " + nativeFileName + " for version " + latestVersion + " from GitHub Releases.\n\nTo prevent version mismatch errors, the update has been cancelled. Please check your internet connection or update manually.");
                return;
            }

            // Then PZOptimEngine.jar
            List<String> jarCandidates = new ArrayList<>();
            if (downloadUrl != null && !downloadUrl.isEmpty() && !downloadUrl.contains("/releases/latest/")) {
                jarCandidates.add(downloadUrl);
            }
            jarCandidates.add("https://github.com/prop11/PZO-Launcher/releases/download/" + vTag + "/PZOptimEngine.jar");
            jarCandidates.add("https://github.com/prop11/PZO-Launcher/releases/download/v" + cleanVer.replaceFirst("^[vV]", "") + "/PZOptimEngine.jar");
            jarCandidates.add("https://github.com/prop11/PZO-Launcher/releases/download/" + cleanVer + "/PZOptimEngine.jar");
            jarCandidates.add("https://github.com/prop11/PZO-Launcher/releases/latest/download/PZOptimEngine.jar");

            boolean jarOk = false;
            for (String tryJar : jarCandidates) {
                PZOLogger.info("Downloading latest PZOptimEngine.jar from: " + tryJar);
                if (downloadFileWithRedirects(tryJar, newJar) && newJar.exists() && newJar.length() > 10000) {
                    jarOk = true;
                    PZOLogger.success("Downloaded " + newJar.length() + " bytes to " + newJar.getAbsolutePath());
                    break;
                } else {
                    if (newJar.exists()) newJar.delete();
                }
            }

            if (!jarOk || !newJar.exists() || newJar.length() < 10000) {
                if (newNative.exists()) newNative.delete();
                showNoticePopup("Update Notice", "Automatic download failed for PZOptimEngine.jar. You can update manually using install.bat.");
                return;
            }

            long pid = ProcessHandle.current().pid();

            File currentJson = new File(gameDir, ZomboidConfigMigrator.TARGET_JSON_NAME);
            File newJson = new File(gameDir, ZomboidConfigMigrator.TARGET_JSON_NAME + ".new");
            boolean hasNewJson = ZomboidConfigMigrator.prepareStagedUpdate(gameDir) && newJson.exists();

            if (isWin) {
                String psJsonUpdate = hasNewJson ? String.format(
                    "if (Test-Path -LiteralPath '%s') { " +
                    "    for ($i=0; $i -lt 30; $i++) { " +
                    "        try { Move-Item -LiteralPath '%s' -Destination '%s' -Force -ErrorAction Stop; break; } " +
                    "        catch { Start-Sleep -Milliseconds 200; } " +
                    "    } " +
                    "}; ",
                    newJson.getAbsolutePath().replace("'", "''"),
                    newJson.getAbsolutePath().replace("'", "''"),
                    currentJson.getAbsolutePath().replace("'", "''")
                ) : "";

                String psDllUpdate = hasNewNative ? String.format(
                    "if (Test-Path -LiteralPath '%s') { " +
                    "    if (Test-Path -LiteralPath '%s') { " +
                    "        for ($i=0; $i -lt 30; $i++) { " +
                    "            try { Copy-Item -LiteralPath '%s' -Destination '%s' -Force -ErrorAction Stop; break; } " +
                    "            catch { Start-Sleep -Milliseconds 200; } " +
                    "        } " +
                    "    }; " +
                    "    for ($i=0; $i -lt 30; $i++) { " +
                    "        try { Move-Item -LiteralPath '%s' -Destination '%s' -Force -ErrorAction Stop; break; } " +
                    "        catch { Start-Sleep -Milliseconds 200; } " +
                    "    } " +
                    "}; ",
                    newNative.getAbsolutePath().replace("'", "''"),
                    win64Dll.getParentFile().getAbsolutePath().replace("'", "''"),
                    newNative.getAbsolutePath().replace("'", "''"),
                    win64Dll.getAbsolutePath().replace("'", "''"),
                    newNative.getAbsolutePath().replace("'", "''"),
                    currentNative.getAbsolutePath().replace("'", "''")
                ) : "";

                String msgTitle = hasNewNative ? "PZO Engine & Native Governor have been updated to v%s!" : "PZO Engine has been updated to v%s!";
                String psUpdater = String.format(
                    "$proc = Get-Process -Id %d -ErrorAction SilentlyContinue; " +
                    "if ($proc) { $proc.WaitForExit(15000); }; " +
                    "Start-Sleep -Milliseconds 500; " +
                    "if (Test-Path -LiteralPath '%s') { " +
                    "    for ($i=0; $i -lt 30; $i++) { " +
                    "        try { Move-Item -LiteralPath '%s' -Destination '%s' -Force -ErrorAction Stop; break; } " +
                    "        catch { Start-Sleep -Milliseconds 200; } " +
                    "    } " +
                    "}; " +
                    "%s" +
                    "%s" +
                    "$nl=[Environment]::NewLine; " +
                    "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms'); " +
                    "[Windows.Forms.MessageBox]::Show(('" + msgTitle + "' + $nl + $nl + 'Please restart Project Zomboid to load the new build.'), 'Update Complete', [Windows.Forms.MessageBoxButtons]::OK, [Windows.Forms.MessageBoxIcon]::Information)",
                    pid,
                    newJar.getAbsolutePath().replace("'", "''"),
                    newJar.getAbsolutePath().replace("'", "''"),
                    currentJar.getAbsolutePath().replace("'", "''"),
                    psDllUpdate,
                    psJsonUpdate,
                    latestVersion
                );
                new ProcessBuilder("powershell.exe", "-NoProfile", "-WindowStyle", "Hidden", "-Command", psUpdater).start();
            } else if (isMac) {
                String macJsonUpdate = hasNewJson ? String.format(
                    " && (test -f \"%s\" && mv -f \"%s\" \"%s\" || true)",
                    newJson.getAbsolutePath(), newJson.getAbsolutePath(), currentJson.getAbsolutePath()
                ) : "";

                String macNativeUpdate = hasNewNative ? String.format(
                    " && cp -f \"%s\" \"%s\" && (test -d \"ProjectZomboid.app/Contents/Java\" && cp -f \"%s\" \"ProjectZomboid.app/Contents/Java/%s\" || true) && (test -d \"ProjectZomboid.app/Contents/MacOS\" && cp -f \"%s\" \"ProjectZomboid.app/Contents/MacOS/%s\" || true) && rm -f \"%s\"",
                    newNative.getAbsolutePath(), currentNative.getAbsolutePath(),
                    newNative.getAbsolutePath(), nativeFileName,
                    newNative.getAbsolutePath(), nativeFileName,
                    newNative.getAbsolutePath()
                ) : "";

                String shUpdater = String.format(
                    "while kill -0 %d 2>/dev/null; do sleep 0.2; done; sleep 0.5 && mv -f \"%s\" \"%s\"%s%s && osascript -e 'display notification \"PZO Engine & Native Governor have been updated to v%s! Please restart Project Zomboid.\" with title \"Update Complete\"'",
                    pid, newJar.getAbsolutePath(), currentJar.getAbsolutePath(), macNativeUpdate, macJsonUpdate, latestVersion
                );
                new ProcessBuilder("bash", "-c", shUpdater).start();
            } else {
                String linuxJsonUpdate = hasNewJson ? String.format(
                    " && (test -f \"%s\" && mv -f \"%s\" \"%s\" || true)",
                    newJson.getAbsolutePath(), newJson.getAbsolutePath(), currentJson.getAbsolutePath()
                ) : "";

                String linuxNativeUpdate = hasNewNative ? String.format(
                    " && cp -f \"%s\" \"%s\" && (test -d \"linux64\" && cp -f \"%s\" \"linux64/%s\" || true) && (test -d \"natives\" && cp -f \"%s\" \"natives/%s\" || true) && rm -f \"%s\"",
                    newNative.getAbsolutePath(), currentNative.getAbsolutePath(),
                    newNative.getAbsolutePath(), nativeFileName,
                    newNative.getAbsolutePath(), nativeFileName,
                    newNative.getAbsolutePath()
                ) : "";

                String shUpdater = String.format(
                    "while kill -0 %d 2>/dev/null; do sleep 0.2; done; sleep 0.5 && mv -f \"%s\" \"%s\"%s%s && (kdialog --msgbox \"PZO Engine & Native Governor have been updated to v%s!\\n\\nPlease restart Project Zomboid.\" || zenity --info --text=\"PZO Engine & Native Governor have been updated to v%s!\\n\\nPlease restart Project Zomboid.\" || notify-send \"PZO Engine Updated\" \"Please restart Project Zomboid.\")",
                    pid, newJar.getAbsolutePath(), currentJar.getAbsolutePath(), linuxNativeUpdate, linuxJsonUpdate, latestVersion, latestVersion
                );
                new ProcessBuilder("bash", "-c", shUpdater).start();
            }

            PZOLogger.info("Exiting game process to allow atomic file replacement...");
            System.exit(0);

        } catch (Throwable t) {
            PZOLogger.error("Auto-update failed: " + t.getMessage(), t);
            showNoticePopup("Update Notice", "Download error: " + t.getMessage() + "\nPlease update manually using install.bat / pzo_optimizer.sh.");
        }
    }

    private static boolean downloadFileWithRedirects(String initialUrl, File targetFile) {
        String currentUrl = initialUrl;
        int maxRedirects = 7;
        for (int i = 0; i < maxRedirects; i++) {
            HttpURLConnection conn = null;
            try {
                URL url = new URL(currentUrl);
                conn = (HttpURLConnection) url.openConnection();
                conn.setRequestProperty("User-Agent", "PZO-UpdateClient");
                conn.setRequestProperty("Accept", "*/*");
                conn.setConnectTimeout(10000);
                conn.setReadTimeout(60000);
                conn.setInstanceFollowRedirects(false);

                int code = conn.getResponseCode();
                if (code == HttpURLConnection.HTTP_MOVED_PERM || code == HttpURLConnection.HTTP_MOVED_TEMP
                    || code == HttpURLConnection.HTTP_SEE_OTHER || code == 307 || code == 308) {
                    String location = conn.getHeaderField("Location");
                    if (location != null && !location.isEmpty()) {
                        URL base = new URL(currentUrl);
                        URL next = new URL(base, location);
                        currentUrl = next.toExternalForm();
                        conn.disconnect();
                        continue;
                    }
                }

                if (code == HttpURLConnection.HTTP_OK) {
                    try (InputStream in = conn.getInputStream();
                         FileOutputStream out = new FileOutputStream(targetFile)) {
                        byte[] buffer = new byte[32768];
                        int bytesRead;
                        while ((bytesRead = in.read(buffer)) != -1) {
                            out.write(buffer, 0, bytesRead);
                        }
                        out.flush();
                    }
                    return targetFile.exists() && targetFile.length() > 0;
                } else {
                    PZOLogger.warn("Download HTTP status " + code + " from: " + currentUrl);
                    return false;
                }
            } catch (Throwable t) {
                PZOLogger.warn("Download attempt error for " + currentUrl + ": " + t.getMessage());
                return false;
            } finally {
                if (conn != null) {
                    try { conn.disconnect(); } catch (Throwable ignored) {}
                }
            }
        }
        return false;
    }

    private static void showNoticePopup(String title, String message) {
        try {
            String os = System.getProperty("os.name", "").toLowerCase();
            if (os.contains("win")) {
                showWindowsNotice(title, message);
            } else if (os.contains("mac")) {
                String script = String.format(
                    "display dialog \"%s\" with title \"%s\" buttons {\"OK\"} default button \"OK\"",
                    message.replace("\n", "\\n"), title
                );
                runDialogProcess(new ProcessBuilder("osascript", "-e", script), null);
            } else {
                runDialogProcess(new ProcessBuilder("zenity", "--info", "--title=" + title, "--text=" + message), null);
            }
        } catch (Throwable ignored) {}
    }

    /**
     * Asks whether a third-party Java mod jar may run. "ALLOW", "BLOCK" or "SKIP"; anything unclear counts as "SKIP".
     */
    public static String promptJavaModApproval(String modName, String workshopId, String jarPath, String sha256) {
        String text = "A Workshop mod wants to run Java code.\n\n"
            + "Java mods are not sandboxed like Lua mods: they run with full access to your PC. "
            + "Only allow mods from authors you trust.\n\n"
            + "Mod: " + modName + "\n"
            + "Workshop ID: " + (workshopId != null ? workshopId : "none (local mod)") + "\n"
            + "File: " + jarPath + "\n"
            + "SHA-256: " + sha256 + "\n\n"
            + "PZO will ask again if this file changes.";
        String os = System.getProperty("os.name", "").toLowerCase();
        try {
            if (os.contains("win")) return showWindowsJavaModDialog(text);
            if (os.contains("mac")) return showMacJavaModDialog(text);
            return showLinuxJavaModDialog(text);
        } catch (Throwable t) {
            PZOLogger.error("Java mod approval dialog error: " + t.getMessage(), t);
        }
        return "SKIP";
    }

    // The message goes in an environment variable so mod names and paths never get parsed as script. A process that
    // outlives the timeout (AMSI scan, policy block, invisible zenity) is killed and reported as "-1:", which every
    // caller treats as skip.
    private static String runDialogProcess(ProcessBuilder pb, String text) throws Exception {
        if (text != null) pb.environment().put("PZO_DIALOG_TEXT", text);
        pb.environment().put("PZO_FG_SRC", PS_FOREGROUND_SRC);
        pb.redirectError(ProcessBuilder.Redirect.DISCARD);
        Process p = pb.start();
        AtomicReference<String> last = new AtomicReference<>();
        Thread reader = new Thread(() -> {
            try (BufferedReader r = new BufferedReader(new InputStreamReader(p.getInputStream()))) {
                String line;
                while ((line = r.readLine()) != null) {
                    if (!line.trim().isEmpty()) last.set(line.trim());
                }
            } catch (IOException ignored) {}
        }, "PZO-DialogReader");
        reader.setDaemon(true);
        reader.start();
        if (!p.waitFor(DIALOG_PROCESS_TIMEOUT_SEC, TimeUnit.SECONDS)) {
            PZOLogger.warn("Startup dialog did not close within " + DIALOG_PROCESS_TIMEOUT_SEC + "s; killing it and continuing launch.");
            p.destroyForcibly();
            return "-1:";
        }
        reader.join(2000);
        String out = last.get();
        return p.exitValue() + ":" + (out != null ? out : "");
    }

    // Title and message go in environment variables so neither gets parsed as script
    private static void showWindowsNotice(String title, String text) throws Exception {
        String psCode =
            "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms');" +
            "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing');" +
            "$f=New-Object Windows.Forms.Form;$f.Text=$env:PZO_DIALOG_TITLE;" +
            "$f.Size=New-Object Drawing.Size(620,430);" +
            "$f.StartPosition='CenterScreen';$f.FormBorderStyle='FixedDialog';" +
            "$f.MaximizeBox=$false;$f.MinimizeBox=$false;" + PS_FORM_GUARDS +
            "$f.BackColor=[Drawing.Color]::FromArgb(30,30,30);$f.ForeColor=[Drawing.Color]::White;" +
            "$t=New-Object Windows.Forms.Label;$t.Text=('[!] ' + $env:PZO_DIALOG_TITLE);" +
            "$t.Font=New-Object Drawing.Font('Segoe UI',12,[Drawing.FontStyle]::Bold);" +
            "$t.ForeColor=[Drawing.Color]::FromArgb(255,185,50);" +
            "$t.Location=New-Object Drawing.Point(20,15);$t.Size=New-Object Drawing.Size(570,25);$f.Controls.Add($t);" +
            "$i=New-Object Windows.Forms.TextBox;$i.Multiline=$true;$i.ReadOnly=$true;$i.BorderStyle='None';" +
            "$i.Text=($env:PZO_DIALOG_TEXT -replace '\\n',[Environment]::NewLine);" +
            "$i.Font=New-Object Drawing.Font('Segoe UI',9.5);" +
            "$i.BackColor=[Drawing.Color]::FromArgb(30,30,30);$i.ForeColor=[Drawing.Color]::FromArgb(220,220,220);" +
            "$i.Location=New-Object Drawing.Point(20,48);$i.Size=New-Object Drawing.Size(570,280);$f.Controls.Add($i);" +
            "$ok=New-Object Windows.Forms.Button;$ok.Text='OK';" +
            "$ok.Font=New-Object Drawing.Font('Segoe UI',9,[Drawing.FontStyle]::Bold);$ok.BackColor=[Drawing.Color]::FromArgb(65,65,65);$ok.ForeColor=[Drawing.Color]::White;$ok.FlatStyle='Flat';" +
            "$ok.Location=New-Object Drawing.Point(465,342);$ok.Size=New-Object Drawing.Size(125,32);$ok.DialogResult=[Windows.Forms.DialogResult]::OK;$f.Controls.Add($ok);" +
            "$f.AcceptButton=$ok;$f.CancelButton=$ok;$f.ActiveControl=$ok;[void]$f.ShowDialog()";
        ProcessBuilder pb = new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", psCode);
        pb.environment().put("PZO_DIALOG_TITLE", title);
        runDialogProcess(pb, text);
    }

    // No double quotes in the script, Java doesn't escape them when it builds the Windows command line
    private static String showWindowsJavaModDialog(String text) throws Exception {
        String psCode =
            "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Windows.Forms');" +
            "[void][System.Reflection.Assembly]::LoadWithPartialName('System.Drawing');" +
            "$f=New-Object Windows.Forms.Form;" +
            "$f.Text='Project Zomboid Optimiser - Java Mod Approval';" +
            "$f.Size=New-Object Drawing.Size(620,380);" +
            "$f.StartPosition='CenterScreen';$f.FormBorderStyle='FixedDialog';" +
            "$f.MaximizeBox=$false;$f.MinimizeBox=$false;" + PS_FORM_GUARDS +
            "$f.BackColor=[Drawing.Color]::FromArgb(30,30,30);$f.ForeColor=[Drawing.Color]::White;" +
            "$t=New-Object Windows.Forms.Label;$t.Text='[!] Java Mod Requires Approval';" +
            "$t.Font=New-Object Drawing.Font('Segoe UI',12,[Drawing.FontStyle]::Bold);" +
            "$t.ForeColor=[Drawing.Color]::FromArgb(255,185,50);" +
            "$t.Location=New-Object Drawing.Point(20,15);$t.Size=New-Object Drawing.Size(570,25);$f.Controls.Add($t);" +
            "$i=New-Object Windows.Forms.TextBox;$i.Multiline=$true;$i.ReadOnly=$true;$i.BorderStyle='None';" +
            "$i.Text=($env:PZO_DIALOG_TEXT -replace '\\n',[Environment]::NewLine);" +
            "$i.Font=New-Object Drawing.Font('Segoe UI',9.5);" +
            "$i.BackColor=[Drawing.Color]::FromArgb(30,30,30);$i.ForeColor=[Drawing.Color]::FromArgb(220,220,220);" +
            "$i.Location=New-Object Drawing.Point(20,48);$i.Size=New-Object Drawing.Size(570,230);$f.Controls.Add($i);" +
            "$ba=New-Object Windows.Forms.Button;$ba.Text='Allow';" +
            "$ba.Font=New-Object Drawing.Font('Segoe UI',9,[Drawing.FontStyle]::Bold);$ba.BackColor=[Drawing.Color]::FromArgb(40,167,69);$ba.ForeColor=[Drawing.Color]::White;$ba.FlatStyle='Flat';" +
            "$ba.Location=New-Object Drawing.Point(465,292);$ba.Size=New-Object Drawing.Size(125,32);$ba.DialogResult=[Windows.Forms.DialogResult]::Yes;$f.Controls.Add($ba);" +
            "$bs=New-Object Windows.Forms.Button;$bs.Text='Skip this launch';" +
            "$bs.Font=New-Object Drawing.Font('Segoe UI',9);$bs.BackColor=[Drawing.Color]::FromArgb(65,65,65);$bs.ForeColor=[Drawing.Color]::White;$bs.FlatStyle='Flat';" +
            "$bs.Location=New-Object Drawing.Point(330,292);$bs.Size=New-Object Drawing.Size(125,32);$bs.DialogResult=[Windows.Forms.DialogResult]::No;$f.Controls.Add($bs);" +
            "$bb=New-Object Windows.Forms.Button;$bb.Text='Always block';" +
            "$bb.Font=New-Object Drawing.Font('Segoe UI',9);$bb.BackColor=[Drawing.Color]::FromArgb(150,45,45);$bb.ForeColor=[Drawing.Color]::White;$bb.FlatStyle='Flat';" +
            "$bb.Location=New-Object Drawing.Point(195,292);$bb.Size=New-Object Drawing.Size(125,32);$bb.DialogResult=[Windows.Forms.DialogResult]::Abort;$f.Controls.Add($bb);" +
            "$f.AcceptButton=$bs;$f.CancelButton=$bs;$f.ActiveControl=$bs;$r=$f.ShowDialog();" +
            "if($r -eq [Windows.Forms.DialogResult]::Yes){Write-Output 'ALLOW'}elseif($r -eq [Windows.Forms.DialogResult]::Abort){Write-Output 'BLOCK'}else{Write-Output 'SKIP'}";
        String out = runDialogProcess(new ProcessBuilder("powershell.exe", "-NoProfile", "-NonInteractive", "-WindowStyle", "Hidden", "-Command", psCode), text);
        if (out.endsWith(":ALLOW")) return "ALLOW";
        if (out.endsWith(":BLOCK")) return "BLOCK";
        return "SKIP";
    }

    private static String showMacJavaModDialog(String text) throws Exception {
        String script =
            "set msg to system attribute \"PZO_DIALOG_TEXT\"\n" +
            "set r to button returned of (display dialog msg with title \"PZO Engine - Java Mod Approval\" " +
            "buttons {\"Always Block\", \"Skip\", \"Allow\"} default button \"Skip\" cancel button \"Skip\" with icon caution)\n" +
            "return r";
        String out = runDialogProcess(new ProcessBuilder("osascript", "-e", script), text);
        if (out.endsWith(":Allow")) return "ALLOW";
        if (out.endsWith(":Always Block")) return "BLOCK";
        return "SKIP";
    }

    private static String showLinuxJavaModDialog(String text) {
        try {
            // zenity --text takes Pango markup, so escape it. Exit 0 is Allow, the extra button prints its label
            String markup = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
            String out = runDialogProcess(new ProcessBuilder("zenity", "--question", "--default-cancel", "--width=560",
                "--title=PZO Engine - Java Mod Approval", "--text=" + markup,
                "--ok-label=Allow", "--cancel-label=Skip this launch", "--extra-button=Always block"), text);
            if (out.endsWith(":Always block")) return "BLOCK";
            if (out.startsWith("0:")) return "ALLOW";
            return "SKIP";
        } catch (Throwable ignored) {}

        try {
            String out = runDialogProcess(new ProcessBuilder("kdialog", "--title", "PZO Engine - Java Mod Approval",
                "--warningyesnocancel", text, "--yes-label", "Allow", "--no-label", "Always block", "--cancel-label", "Skip this launch"), text);
            if (out.startsWith("0:")) return "ALLOW";
            if (out.startsWith("1:")) return "BLOCK";
        } catch (Throwable ignored) {}

        PZOLogger.warn("[JavaModLoader] No dialog tool (zenity/kdialog) available to ask about a Java mod; skipping it for this launch.");
        return "SKIP";
    }

    /** Blocking OK-only warning. The title has to be a fixed string; the message goes through PZO_DIALOG_TEXT. */
    public static void showWarningNotice(String title, String text) {
        String os = System.getProperty("os.name", "").toLowerCase();
        try {
            if (os.contains("win")) {
                showWindowsNotice(title, text);
                return;
            }
            if (os.contains("mac")) {
                String script =
                    "set msg to system attribute \"PZO_DIALOG_TEXT\"\n" +
                    "display dialog msg with title \"" + title.replace("\"", "") + "\" buttons {\"OK\"} default button \"OK\" with icon caution";
                runDialogProcess(new ProcessBuilder("osascript", "-e", script), text);
                return;
            }
        } catch (Throwable t) {
            PZOLogger.warn("Warning dialog error: " + t.getMessage());
            return;
        }

        try {
            String markup = text.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;");
            runDialogProcess(new ProcessBuilder("zenity", "--warning", "--width=560", "--title=" + title, "--text=" + markup), text);
            return;
        } catch (Throwable ignored) {}
        try {
            runDialogProcess(new ProcessBuilder("kdialog", "--title", title, "--sorry", text), text);
        } catch (Throwable ignored) {
            PZOLogger.warn("No dialog tool (zenity/kdialog) available to show: " + title);
        }
    }

    private static boolean isVersionIgnored(String version) {
        return PZOConfig.isVersionIgnored(version);
    }

    private static void setIgnoredVersion(String version) {
        PZOConfig.setIgnoredVersion(version);
    }
}
